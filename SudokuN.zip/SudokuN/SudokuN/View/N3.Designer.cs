﻿namespace SudokuN.View
{
    partial class N3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl33 = new System.Windows.Forms.TextBox();
            this.lbl32 = new System.Windows.Forms.TextBox();
            this.lbl31 = new System.Windows.Forms.TextBox();
            this.lbl23 = new System.Windows.Forms.TextBox();
            this.lbl22 = new System.Windows.Forms.TextBox();
            this.lbl21 = new System.Windows.Forms.TextBox();
            this.lbl13 = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.TextBox();
            this.lbl11 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblBack = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblClear = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.Check = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl33
            // 
            this.lbl33.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl33.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.ForeColor = System.Drawing.Color.White;
            this.lbl33.Location = new System.Drawing.Point(380, 175);
            this.lbl33.Multiline = true;
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(44, 40);
            this.lbl33.TabIndex = 295;
            this.lbl33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl32
            // 
            this.lbl32.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl32.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.ForeColor = System.Drawing.Color.White;
            this.lbl32.Location = new System.Drawing.Point(330, 175);
            this.lbl32.Multiline = true;
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(44, 40);
            this.lbl32.TabIndex = 294;
            this.lbl32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl31
            // 
            this.lbl31.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl31.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.ForeColor = System.Drawing.Color.White;
            this.lbl31.Location = new System.Drawing.Point(280, 175);
            this.lbl31.Multiline = true;
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(44, 40);
            this.lbl31.TabIndex = 293;
            this.lbl31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl23
            // 
            this.lbl23.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl23.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.ForeColor = System.Drawing.Color.White;
            this.lbl23.Location = new System.Drawing.Point(380, 129);
            this.lbl23.Multiline = true;
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(44, 40);
            this.lbl23.TabIndex = 292;
            this.lbl23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl22
            // 
            this.lbl22.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl22.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.ForeColor = System.Drawing.Color.White;
            this.lbl22.Location = new System.Drawing.Point(330, 129);
            this.lbl22.Multiline = true;
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(44, 40);
            this.lbl22.TabIndex = 291;
            this.lbl22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl21
            // 
            this.lbl21.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl21.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.ForeColor = System.Drawing.Color.White;
            this.lbl21.Location = new System.Drawing.Point(280, 129);
            this.lbl21.Multiline = true;
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(44, 40);
            this.lbl21.TabIndex = 290;
            this.lbl21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl13
            // 
            this.lbl13.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl13.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.ForeColor = System.Drawing.Color.White;
            this.lbl13.Location = new System.Drawing.Point(380, 83);
            this.lbl13.Multiline = true;
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(44, 40);
            this.lbl13.TabIndex = 289;
            this.lbl13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl12.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.ForeColor = System.Drawing.Color.White;
            this.lbl12.Location = new System.Drawing.Point(330, 83);
            this.lbl12.Multiline = true;
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(44, 40);
            this.lbl12.TabIndex = 288;
            this.lbl12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl11.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.ForeColor = System.Drawing.Color.White;
            this.lbl11.Location = new System.Drawing.Point(280, 83);
            this.lbl11.Multiline = true;
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(44, 40);
            this.lbl11.TabIndex = 287;
            this.lbl11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(457, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 79);
            this.label1.TabIndex = 853;
            this.label1.Text = "3x3";
            // 
            // lblBack
            // 
            this.lblBack.AutoSize = true;
            this.lblBack.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBack.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBack.ForeColor = System.Drawing.Color.Crimson;
            this.lblBack.Location = new System.Drawing.Point(27, 1);
            this.lblBack.Name = "lblBack";
            this.lblBack.Size = new System.Drawing.Size(120, 23);
            this.lblBack.TabIndex = 873;
            this.lblBack.Text = "Back Menu";
            this.lblBack.Click += new System.EventHandler(this.btnBack_Click);
            this.lblBack.MouseLeave += new System.EventHandler(this.lblBack_MouseLeave);
            this.lblBack.MouseHover += new System.EventHandler(this.lblBack_MouseHover);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(112, 357);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(487, 13);
            this.label5.TabIndex = 876;
            this.label5.Text = "________________________________________________________________________________";
            // 
            // lblClear
            // 
            this.lblClear.AutoSize = true;
            this.lblClear.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblClear.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClear.ForeColor = System.Drawing.Color.Crimson;
            this.lblClear.Location = new System.Drawing.Point(410, 345);
            this.lblClear.Name = "lblClear";
            this.lblClear.Size = new System.Drawing.Size(64, 23);
            this.lblClear.TabIndex = 878;
            this.lblClear.Text = "Clear";
            this.lblClear.Click += new System.EventHandler(this.btnClear_Click);
            this.lblClear.MouseLeave += new System.EventHandler(this.lblClear_MouseLeave);
            this.lblClear.MouseHover += new System.EventHandler(this.lblClear_MouseHover);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResult.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.ForeColor = System.Drawing.Color.Crimson;
            this.lblResult.Location = new System.Drawing.Point(294, 345);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(74, 23);
            this.lblResult.TabIndex = 877;
            this.lblResult.Text = "Result";
            this.lblResult.Click += new System.EventHandler(this.btnGo_Click);
            this.lblResult.MouseLeave += new System.EventHandler(this.lblResult_MouseLeave);
            this.lblResult.MouseHover += new System.EventHandler(this.lblResult_MouseHover);
            // 
            // Check
            // 
            this.Check.AutoSize = true;
            this.Check.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Check.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check.ForeColor = System.Drawing.Color.Crimson;
            this.Check.Location = new System.Drawing.Point(179, 343);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(70, 23);
            this.Check.TabIndex = 879;
            this.Check.Text = "Check";
            this.Check.Click += new System.EventHandler(this.Check_Click);
            // 
            // N3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::SudokuN.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(706, 407);
            this.Controls.Add(this.Check);
            this.Controls.Add(this.lblClear);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl33);
            this.Controls.Add(this.lbl32);
            this.Controls.Add(this.lbl31);
            this.Controls.Add(this.lbl23);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximumSize = new System.Drawing.Size(722, 446);
            this.MinimumSize = new System.Drawing.Size(722, 446);
            this.Name = "N3";
            this.Text = "N3";
            this.Load += new System.EventHandler(this.N3_Load);
            this.Click += new System.EventHandler(this.btnClear_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox lbl33;
        private System.Windows.Forms.TextBox lbl32;
        private System.Windows.Forms.TextBox lbl31;
        private System.Windows.Forms.TextBox lbl23;
        private System.Windows.Forms.TextBox lbl22;
        private System.Windows.Forms.TextBox lbl21;
        private System.Windows.Forms.TextBox lbl13;
        private System.Windows.Forms.TextBox lbl12;
        private System.Windows.Forms.TextBox lbl11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblBack;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblClear;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label Check;
    }
}