﻿namespace SudokuN.View
{
    partial class N16
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl1212 = new System.Windows.Forms.TextBox();
            this.lbl1211 = new System.Windows.Forms.TextBox();
            this.lbl1210 = new System.Windows.Forms.TextBox();
            this.lbl1209 = new System.Windows.Forms.TextBox();
            this.lbl1208 = new System.Windows.Forms.TextBox();
            this.lbl1207 = new System.Windows.Forms.TextBox();
            this.lbl1206 = new System.Windows.Forms.TextBox();
            this.lbl1205 = new System.Windows.Forms.TextBox();
            this.lbl1204 = new System.Windows.Forms.TextBox();
            this.lbl1203 = new System.Windows.Forms.TextBox();
            this.lbl1202 = new System.Windows.Forms.TextBox();
            this.lbl1201 = new System.Windows.Forms.TextBox();
            this.lbl1112 = new System.Windows.Forms.TextBox();
            this.lbl1012 = new System.Windows.Forms.TextBox();
            this.lbl0912 = new System.Windows.Forms.TextBox();
            this.lbl0812 = new System.Windows.Forms.TextBox();
            this.lbl0712 = new System.Windows.Forms.TextBox();
            this.lbl0612 = new System.Windows.Forms.TextBox();
            this.lbl0512 = new System.Windows.Forms.TextBox();
            this.lbl0412 = new System.Windows.Forms.TextBox();
            this.lbl0312 = new System.Windows.Forms.TextBox();
            this.lbl0212 = new System.Windows.Forms.TextBox();
            this.lbl0112 = new System.Windows.Forms.TextBox();
            this.lbl1111 = new System.Windows.Forms.TextBox();
            this.lbl1011 = new System.Windows.Forms.TextBox();
            this.lbl0911 = new System.Windows.Forms.TextBox();
            this.lbl0811 = new System.Windows.Forms.TextBox();
            this.lbl0711 = new System.Windows.Forms.TextBox();
            this.lbl0611 = new System.Windows.Forms.TextBox();
            this.lbl0511 = new System.Windows.Forms.TextBox();
            this.lbl0411 = new System.Windows.Forms.TextBox();
            this.lbl0311 = new System.Windows.Forms.TextBox();
            this.lbl0211 = new System.Windows.Forms.TextBox();
            this.lbl0111 = new System.Windows.Forms.TextBox();
            this.lbl1110 = new System.Windows.Forms.TextBox();
            this.lbl1109 = new System.Windows.Forms.TextBox();
            this.lbl1108 = new System.Windows.Forms.TextBox();
            this.lbl1107 = new System.Windows.Forms.TextBox();
            this.lbl1106 = new System.Windows.Forms.TextBox();
            this.lbl1105 = new System.Windows.Forms.TextBox();
            this.lbl1104 = new System.Windows.Forms.TextBox();
            this.lbl1103 = new System.Windows.Forms.TextBox();
            this.lbl1102 = new System.Windows.Forms.TextBox();
            this.lbl1101 = new System.Windows.Forms.TextBox();
            this.lbl1010 = new System.Windows.Forms.TextBox();
            this.lbl1009 = new System.Windows.Forms.TextBox();
            this.lbl1008 = new System.Windows.Forms.TextBox();
            this.lbl1007 = new System.Windows.Forms.TextBox();
            this.lbl1006 = new System.Windows.Forms.TextBox();
            this.lbl1005 = new System.Windows.Forms.TextBox();
            this.lbl1004 = new System.Windows.Forms.TextBox();
            this.lbl1003 = new System.Windows.Forms.TextBox();
            this.lbl1002 = new System.Windows.Forms.TextBox();
            this.lbl1001 = new System.Windows.Forms.TextBox();
            this.lbl0910 = new System.Windows.Forms.TextBox();
            this.lbl0909 = new System.Windows.Forms.TextBox();
            this.lbl0908 = new System.Windows.Forms.TextBox();
            this.lbl0907 = new System.Windows.Forms.TextBox();
            this.lbl0906 = new System.Windows.Forms.TextBox();
            this.lbl0905 = new System.Windows.Forms.TextBox();
            this.lbl0904 = new System.Windows.Forms.TextBox();
            this.lbl0903 = new System.Windows.Forms.TextBox();
            this.lbl0902 = new System.Windows.Forms.TextBox();
            this.lbl0901 = new System.Windows.Forms.TextBox();
            this.lbl0810 = new System.Windows.Forms.TextBox();
            this.lbl0710 = new System.Windows.Forms.TextBox();
            this.lbl0610 = new System.Windows.Forms.TextBox();
            this.lbl0510 = new System.Windows.Forms.TextBox();
            this.lbl0410 = new System.Windows.Forms.TextBox();
            this.lbl0310 = new System.Windows.Forms.TextBox();
            this.lbl0210 = new System.Windows.Forms.TextBox();
            this.lbl0110 = new System.Windows.Forms.TextBox();
            this.lbl0809 = new System.Windows.Forms.TextBox();
            this.lbl0709 = new System.Windows.Forms.TextBox();
            this.lbl0609 = new System.Windows.Forms.TextBox();
            this.lbl0509 = new System.Windows.Forms.TextBox();
            this.lbl0409 = new System.Windows.Forms.TextBox();
            this.lbl0309 = new System.Windows.Forms.TextBox();
            this.lbl0209 = new System.Windows.Forms.TextBox();
            this.lbl0109 = new System.Windows.Forms.TextBox();
            this.lbl0808 = new System.Windows.Forms.TextBox();
            this.lbl0807 = new System.Windows.Forms.TextBox();
            this.lbl0806 = new System.Windows.Forms.TextBox();
            this.lbl0805 = new System.Windows.Forms.TextBox();
            this.lbl0708 = new System.Windows.Forms.TextBox();
            this.lbl0707 = new System.Windows.Forms.TextBox();
            this.lbl0706 = new System.Windows.Forms.TextBox();
            this.lbl0705 = new System.Windows.Forms.TextBox();
            this.lbl0804 = new System.Windows.Forms.TextBox();
            this.lbl0803 = new System.Windows.Forms.TextBox();
            this.lbl0802 = new System.Windows.Forms.TextBox();
            this.lbl0801 = new System.Windows.Forms.TextBox();
            this.lbl0704 = new System.Windows.Forms.TextBox();
            this.lbl0703 = new System.Windows.Forms.TextBox();
            this.lbl0702 = new System.Windows.Forms.TextBox();
            this.lbl0701 = new System.Windows.Forms.TextBox();
            this.lbl0608 = new System.Windows.Forms.TextBox();
            this.lbl0607 = new System.Windows.Forms.TextBox();
            this.lbl0606 = new System.Windows.Forms.TextBox();
            this.lbl0605 = new System.Windows.Forms.TextBox();
            this.lbl0508 = new System.Windows.Forms.TextBox();
            this.lbl0507 = new System.Windows.Forms.TextBox();
            this.lbl0506 = new System.Windows.Forms.TextBox();
            this.lbl0505 = new System.Windows.Forms.TextBox();
            this.lbl0408 = new System.Windows.Forms.TextBox();
            this.lbl0407 = new System.Windows.Forms.TextBox();
            this.lbl0406 = new System.Windows.Forms.TextBox();
            this.lbl0405 = new System.Windows.Forms.TextBox();
            this.lbl0308 = new System.Windows.Forms.TextBox();
            this.lbl0307 = new System.Windows.Forms.TextBox();
            this.lbl0306 = new System.Windows.Forms.TextBox();
            this.lbl0305 = new System.Windows.Forms.TextBox();
            this.lbl0208 = new System.Windows.Forms.TextBox();
            this.lbl0207 = new System.Windows.Forms.TextBox();
            this.lbl0206 = new System.Windows.Forms.TextBox();
            this.lbl0205 = new System.Windows.Forms.TextBox();
            this.lbl0108 = new System.Windows.Forms.TextBox();
            this.lbl0107 = new System.Windows.Forms.TextBox();
            this.lbl0106 = new System.Windows.Forms.TextBox();
            this.lbl0105 = new System.Windows.Forms.TextBox();
            this.lbl0604 = new System.Windows.Forms.TextBox();
            this.lbl0603 = new System.Windows.Forms.TextBox();
            this.lbl0602 = new System.Windows.Forms.TextBox();
            this.lbl0601 = new System.Windows.Forms.TextBox();
            this.lbl0504 = new System.Windows.Forms.TextBox();
            this.lbl0503 = new System.Windows.Forms.TextBox();
            this.lbl0502 = new System.Windows.Forms.TextBox();
            this.lbl0501 = new System.Windows.Forms.TextBox();
            this.lbl0404 = new System.Windows.Forms.TextBox();
            this.lbl0403 = new System.Windows.Forms.TextBox();
            this.lbl0402 = new System.Windows.Forms.TextBox();
            this.lbl0401 = new System.Windows.Forms.TextBox();
            this.lbl0304 = new System.Windows.Forms.TextBox();
            this.lbl0303 = new System.Windows.Forms.TextBox();
            this.lbl0302 = new System.Windows.Forms.TextBox();
            this.lbl0301 = new System.Windows.Forms.TextBox();
            this.lbl0204 = new System.Windows.Forms.TextBox();
            this.lbl0203 = new System.Windows.Forms.TextBox();
            this.lbl0202 = new System.Windows.Forms.TextBox();
            this.lbl0201 = new System.Windows.Forms.TextBox();
            this.lbl0104 = new System.Windows.Forms.TextBox();
            this.lbl0103 = new System.Windows.Forms.TextBox();
            this.lbl0102 = new System.Windows.Forms.TextBox();
            this.lbl0101 = new System.Windows.Forms.TextBox();
            this.lbl1216 = new System.Windows.Forms.TextBox();
            this.lbl1215 = new System.Windows.Forms.TextBox();
            this.lbl1214 = new System.Windows.Forms.TextBox();
            this.lbl1213 = new System.Windows.Forms.TextBox();
            this.lbl1116 = new System.Windows.Forms.TextBox();
            this.lbl1016 = new System.Windows.Forms.TextBox();
            this.lbl0916 = new System.Windows.Forms.TextBox();
            this.lbl0816 = new System.Windows.Forms.TextBox();
            this.lbl0716 = new System.Windows.Forms.TextBox();
            this.lbl0616 = new System.Windows.Forms.TextBox();
            this.lbl0516 = new System.Windows.Forms.TextBox();
            this.lbl0416 = new System.Windows.Forms.TextBox();
            this.lbl0316 = new System.Windows.Forms.TextBox();
            this.lbl0216 = new System.Windows.Forms.TextBox();
            this.lbl0116 = new System.Windows.Forms.TextBox();
            this.lbl1115 = new System.Windows.Forms.TextBox();
            this.lbl1015 = new System.Windows.Forms.TextBox();
            this.lbl0915 = new System.Windows.Forms.TextBox();
            this.lbl0815 = new System.Windows.Forms.TextBox();
            this.lbl0715 = new System.Windows.Forms.TextBox();
            this.lbl0615 = new System.Windows.Forms.TextBox();
            this.lbl0515 = new System.Windows.Forms.TextBox();
            this.lbl0415 = new System.Windows.Forms.TextBox();
            this.lbl0315 = new System.Windows.Forms.TextBox();
            this.lbl0215 = new System.Windows.Forms.TextBox();
            this.lbl0115 = new System.Windows.Forms.TextBox();
            this.lbl1114 = new System.Windows.Forms.TextBox();
            this.lbl1113 = new System.Windows.Forms.TextBox();
            this.lbl1014 = new System.Windows.Forms.TextBox();
            this.lbl1013 = new System.Windows.Forms.TextBox();
            this.lbl0914 = new System.Windows.Forms.TextBox();
            this.lbl0913 = new System.Windows.Forms.TextBox();
            this.lbl0814 = new System.Windows.Forms.TextBox();
            this.lbl0714 = new System.Windows.Forms.TextBox();
            this.lbl0614 = new System.Windows.Forms.TextBox();
            this.lbl0514 = new System.Windows.Forms.TextBox();
            this.lbl0414 = new System.Windows.Forms.TextBox();
            this.lbl0314 = new System.Windows.Forms.TextBox();
            this.lbl0214 = new System.Windows.Forms.TextBox();
            this.lbl0114 = new System.Windows.Forms.TextBox();
            this.lbl0813 = new System.Windows.Forms.TextBox();
            this.lbl0713 = new System.Windows.Forms.TextBox();
            this.lbl0613 = new System.Windows.Forms.TextBox();
            this.lbl0513 = new System.Windows.Forms.TextBox();
            this.lbl0413 = new System.Windows.Forms.TextBox();
            this.lbl0313 = new System.Windows.Forms.TextBox();
            this.lbl0213 = new System.Windows.Forms.TextBox();
            this.lbl0113 = new System.Windows.Forms.TextBox();
            this.lbl1516 = new System.Windows.Forms.TextBox();
            this.lbl1515 = new System.Windows.Forms.TextBox();
            this.lbl1514 = new System.Windows.Forms.TextBox();
            this.lbl1513 = new System.Windows.Forms.TextBox();
            this.lbl1416 = new System.Windows.Forms.TextBox();
            this.lbl1316 = new System.Windows.Forms.TextBox();
            this.lbl1415 = new System.Windows.Forms.TextBox();
            this.lbl1315 = new System.Windows.Forms.TextBox();
            this.lbl1414 = new System.Windows.Forms.TextBox();
            this.lbl1413 = new System.Windows.Forms.TextBox();
            this.lbl1314 = new System.Windows.Forms.TextBox();
            this.lbl1313 = new System.Windows.Forms.TextBox();
            this.lbl1512 = new System.Windows.Forms.TextBox();
            this.lbl1511 = new System.Windows.Forms.TextBox();
            this.lbl1510 = new System.Windows.Forms.TextBox();
            this.lbl1509 = new System.Windows.Forms.TextBox();
            this.lbl1508 = new System.Windows.Forms.TextBox();
            this.lbl1507 = new System.Windows.Forms.TextBox();
            this.lbl1506 = new System.Windows.Forms.TextBox();
            this.lbl1505 = new System.Windows.Forms.TextBox();
            this.lbl1504 = new System.Windows.Forms.TextBox();
            this.lbl1503 = new System.Windows.Forms.TextBox();
            this.lbl1502 = new System.Windows.Forms.TextBox();
            this.lbl1501 = new System.Windows.Forms.TextBox();
            this.lbl1412 = new System.Windows.Forms.TextBox();
            this.lbl1312 = new System.Windows.Forms.TextBox();
            this.lbl1411 = new System.Windows.Forms.TextBox();
            this.lbl1311 = new System.Windows.Forms.TextBox();
            this.lbl1410 = new System.Windows.Forms.TextBox();
            this.lbl1409 = new System.Windows.Forms.TextBox();
            this.lbl1408 = new System.Windows.Forms.TextBox();
            this.lbl1407 = new System.Windows.Forms.TextBox();
            this.lbl1406 = new System.Windows.Forms.TextBox();
            this.lbl1405 = new System.Windows.Forms.TextBox();
            this.lbl1404 = new System.Windows.Forms.TextBox();
            this.lbl1403 = new System.Windows.Forms.TextBox();
            this.lbl1402 = new System.Windows.Forms.TextBox();
            this.lbl1401 = new System.Windows.Forms.TextBox();
            this.lbl1310 = new System.Windows.Forms.TextBox();
            this.lbl1309 = new System.Windows.Forms.TextBox();
            this.lbl1308 = new System.Windows.Forms.TextBox();
            this.lbl1307 = new System.Windows.Forms.TextBox();
            this.lbl1306 = new System.Windows.Forms.TextBox();
            this.lbl1305 = new System.Windows.Forms.TextBox();
            this.lbl1304 = new System.Windows.Forms.TextBox();
            this.lbl1303 = new System.Windows.Forms.TextBox();
            this.lbl1302 = new System.Windows.Forms.TextBox();
            this.lbl1301 = new System.Windows.Forms.TextBox();
            this.lbl1616 = new System.Windows.Forms.TextBox();
            this.lbl1615 = new System.Windows.Forms.TextBox();
            this.lbl1614 = new System.Windows.Forms.TextBox();
            this.lbl1613 = new System.Windows.Forms.TextBox();
            this.lbl1612 = new System.Windows.Forms.TextBox();
            this.lbl1611 = new System.Windows.Forms.TextBox();
            this.lbl1610 = new System.Windows.Forms.TextBox();
            this.lbl1609 = new System.Windows.Forms.TextBox();
            this.lbl1608 = new System.Windows.Forms.TextBox();
            this.lbl1607 = new System.Windows.Forms.TextBox();
            this.lbl1606 = new System.Windows.Forms.TextBox();
            this.lbl1605 = new System.Windows.Forms.TextBox();
            this.lbl1604 = new System.Windows.Forms.TextBox();
            this.lbl1603 = new System.Windows.Forms.TextBox();
            this.lbl1602 = new System.Windows.Forms.TextBox();
            this.lbl1601 = new System.Windows.Forms.TextBox();
            this.lblClear = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblBack = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Check = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MintCream;
            this.label1.Location = new System.Drawing.Point(751, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 39);
            this.label1.TabIndex = 1018;
            this.label1.Text = "Supper";
            // 
            // lbl1212
            // 
            this.lbl1212.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1212.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1212.ForeColor = System.Drawing.Color.White;
            this.lbl1212.Location = new System.Drawing.Point(549, 438);
            this.lbl1212.Multiline = true;
            this.lbl1212.Name = "lbl1212";
            this.lbl1212.Size = new System.Drawing.Size(30, 30);
            this.lbl1212.TabIndex = 1016;
            this.lbl1212.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1211
            // 
            this.lbl1211.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1211.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1211.ForeColor = System.Drawing.Color.White;
            this.lbl1211.Location = new System.Drawing.Point(513, 438);
            this.lbl1211.Multiline = true;
            this.lbl1211.Name = "lbl1211";
            this.lbl1211.Size = new System.Drawing.Size(30, 30);
            this.lbl1211.TabIndex = 1015;
            this.lbl1211.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1210
            // 
            this.lbl1210.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1210.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1210.ForeColor = System.Drawing.Color.White;
            this.lbl1210.Location = new System.Drawing.Point(477, 438);
            this.lbl1210.Multiline = true;
            this.lbl1210.Name = "lbl1210";
            this.lbl1210.Size = new System.Drawing.Size(30, 30);
            this.lbl1210.TabIndex = 1014;
            this.lbl1210.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1209
            // 
            this.lbl1209.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1209.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1209.ForeColor = System.Drawing.Color.White;
            this.lbl1209.Location = new System.Drawing.Point(441, 438);
            this.lbl1209.Multiline = true;
            this.lbl1209.Name = "lbl1209";
            this.lbl1209.Size = new System.Drawing.Size(30, 30);
            this.lbl1209.TabIndex = 1013;
            this.lbl1209.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1208
            // 
            this.lbl1208.BackColor = System.Drawing.Color.Crimson;
            this.lbl1208.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1208.ForeColor = System.Drawing.Color.White;
            this.lbl1208.Location = new System.Drawing.Point(405, 438);
            this.lbl1208.Multiline = true;
            this.lbl1208.Name = "lbl1208";
            this.lbl1208.Size = new System.Drawing.Size(30, 30);
            this.lbl1208.TabIndex = 1012;
            this.lbl1208.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1207
            // 
            this.lbl1207.BackColor = System.Drawing.Color.Crimson;
            this.lbl1207.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1207.ForeColor = System.Drawing.Color.White;
            this.lbl1207.Location = new System.Drawing.Point(369, 438);
            this.lbl1207.Multiline = true;
            this.lbl1207.Name = "lbl1207";
            this.lbl1207.Size = new System.Drawing.Size(30, 30);
            this.lbl1207.TabIndex = 1011;
            this.lbl1207.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1206
            // 
            this.lbl1206.BackColor = System.Drawing.Color.Crimson;
            this.lbl1206.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1206.ForeColor = System.Drawing.Color.White;
            this.lbl1206.Location = new System.Drawing.Point(333, 438);
            this.lbl1206.Multiline = true;
            this.lbl1206.Name = "lbl1206";
            this.lbl1206.Size = new System.Drawing.Size(30, 30);
            this.lbl1206.TabIndex = 1010;
            this.lbl1206.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1205
            // 
            this.lbl1205.BackColor = System.Drawing.Color.Crimson;
            this.lbl1205.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1205.ForeColor = System.Drawing.Color.White;
            this.lbl1205.Location = new System.Drawing.Point(297, 438);
            this.lbl1205.Multiline = true;
            this.lbl1205.Name = "lbl1205";
            this.lbl1205.Size = new System.Drawing.Size(30, 30);
            this.lbl1205.TabIndex = 1009;
            this.lbl1205.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1204
            // 
            this.lbl1204.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1204.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1204.ForeColor = System.Drawing.Color.White;
            this.lbl1204.Location = new System.Drawing.Point(261, 438);
            this.lbl1204.Multiline = true;
            this.lbl1204.Name = "lbl1204";
            this.lbl1204.Size = new System.Drawing.Size(30, 30);
            this.lbl1204.TabIndex = 1008;
            this.lbl1204.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1203
            // 
            this.lbl1203.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1203.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1203.ForeColor = System.Drawing.Color.White;
            this.lbl1203.Location = new System.Drawing.Point(225, 438);
            this.lbl1203.Multiline = true;
            this.lbl1203.Name = "lbl1203";
            this.lbl1203.Size = new System.Drawing.Size(30, 30);
            this.lbl1203.TabIndex = 1007;
            this.lbl1203.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1202
            // 
            this.lbl1202.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1202.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1202.ForeColor = System.Drawing.Color.White;
            this.lbl1202.Location = new System.Drawing.Point(189, 438);
            this.lbl1202.Multiline = true;
            this.lbl1202.Name = "lbl1202";
            this.lbl1202.Size = new System.Drawing.Size(30, 30);
            this.lbl1202.TabIndex = 1006;
            this.lbl1202.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1201
            // 
            this.lbl1201.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1201.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1201.ForeColor = System.Drawing.Color.White;
            this.lbl1201.Location = new System.Drawing.Point(153, 438);
            this.lbl1201.Multiline = true;
            this.lbl1201.Name = "lbl1201";
            this.lbl1201.Size = new System.Drawing.Size(30, 30);
            this.lbl1201.TabIndex = 1005;
            this.lbl1201.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1112
            // 
            this.lbl1112.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1112.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1112.ForeColor = System.Drawing.Color.White;
            this.lbl1112.Location = new System.Drawing.Point(549, 402);
            this.lbl1112.Multiline = true;
            this.lbl1112.Name = "lbl1112";
            this.lbl1112.Size = new System.Drawing.Size(30, 30);
            this.lbl1112.TabIndex = 1004;
            this.lbl1112.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1012
            // 
            this.lbl1012.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1012.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1012.ForeColor = System.Drawing.Color.White;
            this.lbl1012.Location = new System.Drawing.Point(549, 366);
            this.lbl1012.Multiline = true;
            this.lbl1012.Name = "lbl1012";
            this.lbl1012.Size = new System.Drawing.Size(30, 30);
            this.lbl1012.TabIndex = 1003;
            this.lbl1012.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0912
            // 
            this.lbl0912.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl0912.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0912.ForeColor = System.Drawing.Color.White;
            this.lbl0912.Location = new System.Drawing.Point(549, 330);
            this.lbl0912.Multiline = true;
            this.lbl0912.Name = "lbl0912";
            this.lbl0912.Size = new System.Drawing.Size(30, 30);
            this.lbl0912.TabIndex = 1002;
            this.lbl0912.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0812
            // 
            this.lbl0812.BackColor = System.Drawing.Color.Teal;
            this.lbl0812.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0812.ForeColor = System.Drawing.Color.White;
            this.lbl0812.Location = new System.Drawing.Point(549, 294);
            this.lbl0812.Multiline = true;
            this.lbl0812.Name = "lbl0812";
            this.lbl0812.Size = new System.Drawing.Size(30, 30);
            this.lbl0812.TabIndex = 1001;
            this.lbl0812.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0712
            // 
            this.lbl0712.BackColor = System.Drawing.Color.Teal;
            this.lbl0712.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0712.ForeColor = System.Drawing.Color.White;
            this.lbl0712.Location = new System.Drawing.Point(549, 258);
            this.lbl0712.Multiline = true;
            this.lbl0712.Name = "lbl0712";
            this.lbl0712.Size = new System.Drawing.Size(30, 30);
            this.lbl0712.TabIndex = 1000;
            this.lbl0712.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0612
            // 
            this.lbl0612.BackColor = System.Drawing.Color.Teal;
            this.lbl0612.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0612.ForeColor = System.Drawing.Color.White;
            this.lbl0612.Location = new System.Drawing.Point(549, 222);
            this.lbl0612.Multiline = true;
            this.lbl0612.Name = "lbl0612";
            this.lbl0612.Size = new System.Drawing.Size(30, 30);
            this.lbl0612.TabIndex = 999;
            this.lbl0612.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0512
            // 
            this.lbl0512.BackColor = System.Drawing.Color.Teal;
            this.lbl0512.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0512.ForeColor = System.Drawing.Color.White;
            this.lbl0512.Location = new System.Drawing.Point(549, 186);
            this.lbl0512.Multiline = true;
            this.lbl0512.Name = "lbl0512";
            this.lbl0512.Size = new System.Drawing.Size(30, 30);
            this.lbl0512.TabIndex = 998;
            this.lbl0512.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0412
            // 
            this.lbl0412.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0412.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0412.ForeColor = System.Drawing.Color.White;
            this.lbl0412.Location = new System.Drawing.Point(549, 150);
            this.lbl0412.Multiline = true;
            this.lbl0412.Name = "lbl0412";
            this.lbl0412.Size = new System.Drawing.Size(30, 30);
            this.lbl0412.TabIndex = 997;
            this.lbl0412.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0312
            // 
            this.lbl0312.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0312.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0312.ForeColor = System.Drawing.Color.White;
            this.lbl0312.Location = new System.Drawing.Point(549, 114);
            this.lbl0312.Multiline = true;
            this.lbl0312.Name = "lbl0312";
            this.lbl0312.Size = new System.Drawing.Size(30, 30);
            this.lbl0312.TabIndex = 996;
            this.lbl0312.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0212
            // 
            this.lbl0212.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0212.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0212.ForeColor = System.Drawing.Color.White;
            this.lbl0212.Location = new System.Drawing.Point(549, 78);
            this.lbl0212.Multiline = true;
            this.lbl0212.Name = "lbl0212";
            this.lbl0212.Size = new System.Drawing.Size(30, 30);
            this.lbl0212.TabIndex = 995;
            this.lbl0212.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0112
            // 
            this.lbl0112.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0112.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0112.ForeColor = System.Drawing.Color.White;
            this.lbl0112.Location = new System.Drawing.Point(549, 42);
            this.lbl0112.Multiline = true;
            this.lbl0112.Name = "lbl0112";
            this.lbl0112.Size = new System.Drawing.Size(30, 30);
            this.lbl0112.TabIndex = 994;
            this.lbl0112.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1111
            // 
            this.lbl1111.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1111.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1111.ForeColor = System.Drawing.Color.White;
            this.lbl1111.Location = new System.Drawing.Point(513, 402);
            this.lbl1111.Multiline = true;
            this.lbl1111.Name = "lbl1111";
            this.lbl1111.Size = new System.Drawing.Size(30, 30);
            this.lbl1111.TabIndex = 993;
            this.lbl1111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1011
            // 
            this.lbl1011.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1011.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1011.ForeColor = System.Drawing.Color.White;
            this.lbl1011.Location = new System.Drawing.Point(513, 366);
            this.lbl1011.Multiline = true;
            this.lbl1011.Name = "lbl1011";
            this.lbl1011.Size = new System.Drawing.Size(30, 30);
            this.lbl1011.TabIndex = 992;
            this.lbl1011.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0911
            // 
            this.lbl0911.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl0911.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0911.ForeColor = System.Drawing.Color.White;
            this.lbl0911.Location = new System.Drawing.Point(513, 330);
            this.lbl0911.Multiline = true;
            this.lbl0911.Name = "lbl0911";
            this.lbl0911.Size = new System.Drawing.Size(30, 30);
            this.lbl0911.TabIndex = 991;
            this.lbl0911.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0811
            // 
            this.lbl0811.BackColor = System.Drawing.Color.Teal;
            this.lbl0811.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0811.ForeColor = System.Drawing.Color.White;
            this.lbl0811.Location = new System.Drawing.Point(513, 294);
            this.lbl0811.Multiline = true;
            this.lbl0811.Name = "lbl0811";
            this.lbl0811.Size = new System.Drawing.Size(30, 30);
            this.lbl0811.TabIndex = 990;
            this.lbl0811.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0711
            // 
            this.lbl0711.BackColor = System.Drawing.Color.Teal;
            this.lbl0711.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0711.ForeColor = System.Drawing.Color.White;
            this.lbl0711.Location = new System.Drawing.Point(513, 258);
            this.lbl0711.Multiline = true;
            this.lbl0711.Name = "lbl0711";
            this.lbl0711.Size = new System.Drawing.Size(30, 30);
            this.lbl0711.TabIndex = 989;
            this.lbl0711.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0611
            // 
            this.lbl0611.BackColor = System.Drawing.Color.Teal;
            this.lbl0611.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0611.ForeColor = System.Drawing.Color.White;
            this.lbl0611.Location = new System.Drawing.Point(513, 222);
            this.lbl0611.Multiline = true;
            this.lbl0611.Name = "lbl0611";
            this.lbl0611.Size = new System.Drawing.Size(30, 30);
            this.lbl0611.TabIndex = 988;
            this.lbl0611.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0511
            // 
            this.lbl0511.BackColor = System.Drawing.Color.Teal;
            this.lbl0511.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0511.ForeColor = System.Drawing.Color.White;
            this.lbl0511.Location = new System.Drawing.Point(513, 186);
            this.lbl0511.Multiline = true;
            this.lbl0511.Name = "lbl0511";
            this.lbl0511.Size = new System.Drawing.Size(30, 30);
            this.lbl0511.TabIndex = 987;
            this.lbl0511.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0411
            // 
            this.lbl0411.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0411.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0411.ForeColor = System.Drawing.Color.White;
            this.lbl0411.Location = new System.Drawing.Point(513, 150);
            this.lbl0411.Multiline = true;
            this.lbl0411.Name = "lbl0411";
            this.lbl0411.Size = new System.Drawing.Size(30, 30);
            this.lbl0411.TabIndex = 986;
            this.lbl0411.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0311
            // 
            this.lbl0311.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0311.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0311.ForeColor = System.Drawing.Color.White;
            this.lbl0311.Location = new System.Drawing.Point(513, 114);
            this.lbl0311.Multiline = true;
            this.lbl0311.Name = "lbl0311";
            this.lbl0311.Size = new System.Drawing.Size(30, 30);
            this.lbl0311.TabIndex = 985;
            this.lbl0311.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0211
            // 
            this.lbl0211.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0211.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0211.ForeColor = System.Drawing.Color.White;
            this.lbl0211.Location = new System.Drawing.Point(513, 78);
            this.lbl0211.Multiline = true;
            this.lbl0211.Name = "lbl0211";
            this.lbl0211.Size = new System.Drawing.Size(30, 30);
            this.lbl0211.TabIndex = 984;
            this.lbl0211.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0111
            // 
            this.lbl0111.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0111.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0111.ForeColor = System.Drawing.Color.White;
            this.lbl0111.Location = new System.Drawing.Point(513, 42);
            this.lbl0111.Multiline = true;
            this.lbl0111.Name = "lbl0111";
            this.lbl0111.Size = new System.Drawing.Size(30, 30);
            this.lbl0111.TabIndex = 983;
            this.lbl0111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1110
            // 
            this.lbl1110.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1110.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1110.ForeColor = System.Drawing.Color.White;
            this.lbl1110.Location = new System.Drawing.Point(477, 402);
            this.lbl1110.Multiline = true;
            this.lbl1110.Name = "lbl1110";
            this.lbl1110.Size = new System.Drawing.Size(30, 30);
            this.lbl1110.TabIndex = 982;
            this.lbl1110.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1109
            // 
            this.lbl1109.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1109.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1109.ForeColor = System.Drawing.Color.White;
            this.lbl1109.Location = new System.Drawing.Point(441, 402);
            this.lbl1109.Multiline = true;
            this.lbl1109.Name = "lbl1109";
            this.lbl1109.Size = new System.Drawing.Size(30, 30);
            this.lbl1109.TabIndex = 981;
            this.lbl1109.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1108
            // 
            this.lbl1108.BackColor = System.Drawing.Color.Crimson;
            this.lbl1108.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1108.ForeColor = System.Drawing.Color.White;
            this.lbl1108.Location = new System.Drawing.Point(405, 402);
            this.lbl1108.Multiline = true;
            this.lbl1108.Name = "lbl1108";
            this.lbl1108.Size = new System.Drawing.Size(30, 30);
            this.lbl1108.TabIndex = 980;
            this.lbl1108.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1107
            // 
            this.lbl1107.BackColor = System.Drawing.Color.Crimson;
            this.lbl1107.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1107.ForeColor = System.Drawing.Color.White;
            this.lbl1107.Location = new System.Drawing.Point(369, 402);
            this.lbl1107.Multiline = true;
            this.lbl1107.Name = "lbl1107";
            this.lbl1107.Size = new System.Drawing.Size(30, 30);
            this.lbl1107.TabIndex = 979;
            this.lbl1107.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1106
            // 
            this.lbl1106.BackColor = System.Drawing.Color.Crimson;
            this.lbl1106.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1106.ForeColor = System.Drawing.Color.White;
            this.lbl1106.Location = new System.Drawing.Point(333, 402);
            this.lbl1106.Multiline = true;
            this.lbl1106.Name = "lbl1106";
            this.lbl1106.Size = new System.Drawing.Size(30, 30);
            this.lbl1106.TabIndex = 978;
            this.lbl1106.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1105
            // 
            this.lbl1105.BackColor = System.Drawing.Color.Crimson;
            this.lbl1105.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1105.ForeColor = System.Drawing.Color.White;
            this.lbl1105.Location = new System.Drawing.Point(297, 402);
            this.lbl1105.Multiline = true;
            this.lbl1105.Name = "lbl1105";
            this.lbl1105.Size = new System.Drawing.Size(30, 30);
            this.lbl1105.TabIndex = 977;
            this.lbl1105.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1104
            // 
            this.lbl1104.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1104.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1104.ForeColor = System.Drawing.Color.White;
            this.lbl1104.Location = new System.Drawing.Point(261, 402);
            this.lbl1104.Multiline = true;
            this.lbl1104.Name = "lbl1104";
            this.lbl1104.Size = new System.Drawing.Size(30, 30);
            this.lbl1104.TabIndex = 976;
            this.lbl1104.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1103
            // 
            this.lbl1103.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1103.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1103.ForeColor = System.Drawing.Color.White;
            this.lbl1103.Location = new System.Drawing.Point(225, 402);
            this.lbl1103.Multiline = true;
            this.lbl1103.Name = "lbl1103";
            this.lbl1103.Size = new System.Drawing.Size(30, 30);
            this.lbl1103.TabIndex = 975;
            this.lbl1103.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1102
            // 
            this.lbl1102.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1102.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1102.ForeColor = System.Drawing.Color.White;
            this.lbl1102.Location = new System.Drawing.Point(189, 402);
            this.lbl1102.Multiline = true;
            this.lbl1102.Name = "lbl1102";
            this.lbl1102.Size = new System.Drawing.Size(30, 30);
            this.lbl1102.TabIndex = 974;
            this.lbl1102.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1101
            // 
            this.lbl1101.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1101.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1101.ForeColor = System.Drawing.Color.White;
            this.lbl1101.Location = new System.Drawing.Point(153, 402);
            this.lbl1101.Multiline = true;
            this.lbl1101.Name = "lbl1101";
            this.lbl1101.Size = new System.Drawing.Size(30, 30);
            this.lbl1101.TabIndex = 973;
            this.lbl1101.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1010
            // 
            this.lbl1010.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1010.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1010.ForeColor = System.Drawing.Color.White;
            this.lbl1010.Location = new System.Drawing.Point(477, 366);
            this.lbl1010.Multiline = true;
            this.lbl1010.Name = "lbl1010";
            this.lbl1010.Size = new System.Drawing.Size(30, 30);
            this.lbl1010.TabIndex = 972;
            this.lbl1010.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1009
            // 
            this.lbl1009.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1009.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1009.ForeColor = System.Drawing.Color.White;
            this.lbl1009.Location = new System.Drawing.Point(441, 366);
            this.lbl1009.Multiline = true;
            this.lbl1009.Name = "lbl1009";
            this.lbl1009.Size = new System.Drawing.Size(30, 30);
            this.lbl1009.TabIndex = 971;
            this.lbl1009.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1008
            // 
            this.lbl1008.BackColor = System.Drawing.Color.Crimson;
            this.lbl1008.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1008.ForeColor = System.Drawing.Color.White;
            this.lbl1008.Location = new System.Drawing.Point(405, 366);
            this.lbl1008.Multiline = true;
            this.lbl1008.Name = "lbl1008";
            this.lbl1008.Size = new System.Drawing.Size(30, 30);
            this.lbl1008.TabIndex = 970;
            this.lbl1008.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1007
            // 
            this.lbl1007.BackColor = System.Drawing.Color.Crimson;
            this.lbl1007.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1007.ForeColor = System.Drawing.Color.White;
            this.lbl1007.Location = new System.Drawing.Point(369, 366);
            this.lbl1007.Multiline = true;
            this.lbl1007.Name = "lbl1007";
            this.lbl1007.Size = new System.Drawing.Size(30, 30);
            this.lbl1007.TabIndex = 969;
            this.lbl1007.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1006
            // 
            this.lbl1006.BackColor = System.Drawing.Color.Crimson;
            this.lbl1006.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1006.ForeColor = System.Drawing.Color.White;
            this.lbl1006.Location = new System.Drawing.Point(333, 366);
            this.lbl1006.Multiline = true;
            this.lbl1006.Name = "lbl1006";
            this.lbl1006.Size = new System.Drawing.Size(30, 30);
            this.lbl1006.TabIndex = 968;
            this.lbl1006.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1005
            // 
            this.lbl1005.BackColor = System.Drawing.Color.Crimson;
            this.lbl1005.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1005.ForeColor = System.Drawing.Color.White;
            this.lbl1005.Location = new System.Drawing.Point(297, 366);
            this.lbl1005.Multiline = true;
            this.lbl1005.Name = "lbl1005";
            this.lbl1005.Size = new System.Drawing.Size(30, 30);
            this.lbl1005.TabIndex = 967;
            this.lbl1005.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1004
            // 
            this.lbl1004.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1004.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1004.ForeColor = System.Drawing.Color.White;
            this.lbl1004.Location = new System.Drawing.Point(261, 366);
            this.lbl1004.Multiline = true;
            this.lbl1004.Name = "lbl1004";
            this.lbl1004.Size = new System.Drawing.Size(30, 30);
            this.lbl1004.TabIndex = 966;
            this.lbl1004.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1003
            // 
            this.lbl1003.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1003.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1003.ForeColor = System.Drawing.Color.White;
            this.lbl1003.Location = new System.Drawing.Point(225, 366);
            this.lbl1003.Multiline = true;
            this.lbl1003.Name = "lbl1003";
            this.lbl1003.Size = new System.Drawing.Size(30, 30);
            this.lbl1003.TabIndex = 965;
            this.lbl1003.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1002
            // 
            this.lbl1002.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1002.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1002.ForeColor = System.Drawing.Color.White;
            this.lbl1002.Location = new System.Drawing.Point(189, 366);
            this.lbl1002.Multiline = true;
            this.lbl1002.Name = "lbl1002";
            this.lbl1002.Size = new System.Drawing.Size(30, 30);
            this.lbl1002.TabIndex = 964;
            this.lbl1002.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1001
            // 
            this.lbl1001.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl1001.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1001.ForeColor = System.Drawing.Color.White;
            this.lbl1001.Location = new System.Drawing.Point(153, 366);
            this.lbl1001.Multiline = true;
            this.lbl1001.Name = "lbl1001";
            this.lbl1001.Size = new System.Drawing.Size(30, 30);
            this.lbl1001.TabIndex = 963;
            this.lbl1001.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0910
            // 
            this.lbl0910.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl0910.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0910.ForeColor = System.Drawing.Color.White;
            this.lbl0910.Location = new System.Drawing.Point(477, 330);
            this.lbl0910.Multiline = true;
            this.lbl0910.Name = "lbl0910";
            this.lbl0910.Size = new System.Drawing.Size(30, 30);
            this.lbl0910.TabIndex = 962;
            this.lbl0910.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0909
            // 
            this.lbl0909.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl0909.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0909.ForeColor = System.Drawing.Color.White;
            this.lbl0909.Location = new System.Drawing.Point(441, 330);
            this.lbl0909.Multiline = true;
            this.lbl0909.Name = "lbl0909";
            this.lbl0909.Size = new System.Drawing.Size(30, 30);
            this.lbl0909.TabIndex = 961;
            this.lbl0909.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0908
            // 
            this.lbl0908.BackColor = System.Drawing.Color.Crimson;
            this.lbl0908.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0908.ForeColor = System.Drawing.Color.White;
            this.lbl0908.Location = new System.Drawing.Point(405, 330);
            this.lbl0908.Multiline = true;
            this.lbl0908.Name = "lbl0908";
            this.lbl0908.Size = new System.Drawing.Size(30, 30);
            this.lbl0908.TabIndex = 960;
            this.lbl0908.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0907
            // 
            this.lbl0907.BackColor = System.Drawing.Color.Crimson;
            this.lbl0907.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0907.ForeColor = System.Drawing.Color.White;
            this.lbl0907.Location = new System.Drawing.Point(369, 330);
            this.lbl0907.Multiline = true;
            this.lbl0907.Name = "lbl0907";
            this.lbl0907.Size = new System.Drawing.Size(30, 30);
            this.lbl0907.TabIndex = 959;
            this.lbl0907.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0906
            // 
            this.lbl0906.BackColor = System.Drawing.Color.Crimson;
            this.lbl0906.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0906.ForeColor = System.Drawing.Color.White;
            this.lbl0906.Location = new System.Drawing.Point(333, 330);
            this.lbl0906.Multiline = true;
            this.lbl0906.Name = "lbl0906";
            this.lbl0906.Size = new System.Drawing.Size(30, 30);
            this.lbl0906.TabIndex = 958;
            this.lbl0906.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0905
            // 
            this.lbl0905.BackColor = System.Drawing.Color.Crimson;
            this.lbl0905.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0905.ForeColor = System.Drawing.Color.White;
            this.lbl0905.Location = new System.Drawing.Point(297, 330);
            this.lbl0905.Multiline = true;
            this.lbl0905.Name = "lbl0905";
            this.lbl0905.Size = new System.Drawing.Size(30, 30);
            this.lbl0905.TabIndex = 957;
            this.lbl0905.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0904
            // 
            this.lbl0904.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl0904.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0904.ForeColor = System.Drawing.Color.White;
            this.lbl0904.Location = new System.Drawing.Point(261, 330);
            this.lbl0904.Multiline = true;
            this.lbl0904.Name = "lbl0904";
            this.lbl0904.Size = new System.Drawing.Size(30, 30);
            this.lbl0904.TabIndex = 956;
            this.lbl0904.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0903
            // 
            this.lbl0903.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl0903.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0903.ForeColor = System.Drawing.Color.White;
            this.lbl0903.Location = new System.Drawing.Point(225, 330);
            this.lbl0903.Multiline = true;
            this.lbl0903.Name = "lbl0903";
            this.lbl0903.Size = new System.Drawing.Size(30, 30);
            this.lbl0903.TabIndex = 955;
            this.lbl0903.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0902
            // 
            this.lbl0902.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl0902.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0902.ForeColor = System.Drawing.Color.White;
            this.lbl0902.Location = new System.Drawing.Point(189, 330);
            this.lbl0902.Multiline = true;
            this.lbl0902.Name = "lbl0902";
            this.lbl0902.Size = new System.Drawing.Size(30, 30);
            this.lbl0902.TabIndex = 954;
            this.lbl0902.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0901
            // 
            this.lbl0901.BackColor = System.Drawing.Color.MediumVioletRed;
            this.lbl0901.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0901.ForeColor = System.Drawing.Color.White;
            this.lbl0901.Location = new System.Drawing.Point(153, 330);
            this.lbl0901.Multiline = true;
            this.lbl0901.Name = "lbl0901";
            this.lbl0901.Size = new System.Drawing.Size(30, 30);
            this.lbl0901.TabIndex = 953;
            this.lbl0901.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0810
            // 
            this.lbl0810.BackColor = System.Drawing.Color.Teal;
            this.lbl0810.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0810.ForeColor = System.Drawing.Color.White;
            this.lbl0810.Location = new System.Drawing.Point(477, 294);
            this.lbl0810.Multiline = true;
            this.lbl0810.Name = "lbl0810";
            this.lbl0810.Size = new System.Drawing.Size(30, 30);
            this.lbl0810.TabIndex = 952;
            this.lbl0810.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0710
            // 
            this.lbl0710.BackColor = System.Drawing.Color.Teal;
            this.lbl0710.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0710.ForeColor = System.Drawing.Color.White;
            this.lbl0710.Location = new System.Drawing.Point(477, 258);
            this.lbl0710.Multiline = true;
            this.lbl0710.Name = "lbl0710";
            this.lbl0710.Size = new System.Drawing.Size(30, 30);
            this.lbl0710.TabIndex = 951;
            this.lbl0710.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0610
            // 
            this.lbl0610.BackColor = System.Drawing.Color.Teal;
            this.lbl0610.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0610.ForeColor = System.Drawing.Color.White;
            this.lbl0610.Location = new System.Drawing.Point(477, 222);
            this.lbl0610.Multiline = true;
            this.lbl0610.Name = "lbl0610";
            this.lbl0610.Size = new System.Drawing.Size(30, 30);
            this.lbl0610.TabIndex = 950;
            this.lbl0610.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0510
            // 
            this.lbl0510.BackColor = System.Drawing.Color.Teal;
            this.lbl0510.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0510.ForeColor = System.Drawing.Color.White;
            this.lbl0510.Location = new System.Drawing.Point(477, 186);
            this.lbl0510.Multiline = true;
            this.lbl0510.Name = "lbl0510";
            this.lbl0510.Size = new System.Drawing.Size(30, 30);
            this.lbl0510.TabIndex = 949;
            this.lbl0510.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0410
            // 
            this.lbl0410.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0410.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0410.ForeColor = System.Drawing.Color.White;
            this.lbl0410.Location = new System.Drawing.Point(477, 150);
            this.lbl0410.Multiline = true;
            this.lbl0410.Name = "lbl0410";
            this.lbl0410.Size = new System.Drawing.Size(30, 30);
            this.lbl0410.TabIndex = 948;
            this.lbl0410.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0310
            // 
            this.lbl0310.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0310.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0310.ForeColor = System.Drawing.Color.White;
            this.lbl0310.Location = new System.Drawing.Point(477, 114);
            this.lbl0310.Multiline = true;
            this.lbl0310.Name = "lbl0310";
            this.lbl0310.Size = new System.Drawing.Size(30, 30);
            this.lbl0310.TabIndex = 947;
            this.lbl0310.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0210
            // 
            this.lbl0210.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0210.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0210.ForeColor = System.Drawing.Color.White;
            this.lbl0210.Location = new System.Drawing.Point(477, 78);
            this.lbl0210.Multiline = true;
            this.lbl0210.Name = "lbl0210";
            this.lbl0210.Size = new System.Drawing.Size(30, 30);
            this.lbl0210.TabIndex = 946;
            this.lbl0210.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0110
            // 
            this.lbl0110.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0110.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0110.ForeColor = System.Drawing.Color.White;
            this.lbl0110.Location = new System.Drawing.Point(477, 42);
            this.lbl0110.Multiline = true;
            this.lbl0110.Name = "lbl0110";
            this.lbl0110.Size = new System.Drawing.Size(30, 30);
            this.lbl0110.TabIndex = 945;
            this.lbl0110.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0809
            // 
            this.lbl0809.BackColor = System.Drawing.Color.Teal;
            this.lbl0809.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0809.ForeColor = System.Drawing.Color.White;
            this.lbl0809.Location = new System.Drawing.Point(441, 294);
            this.lbl0809.Multiline = true;
            this.lbl0809.Name = "lbl0809";
            this.lbl0809.Size = new System.Drawing.Size(30, 30);
            this.lbl0809.TabIndex = 944;
            this.lbl0809.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0709
            // 
            this.lbl0709.BackColor = System.Drawing.Color.Teal;
            this.lbl0709.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0709.ForeColor = System.Drawing.Color.White;
            this.lbl0709.Location = new System.Drawing.Point(441, 258);
            this.lbl0709.Multiline = true;
            this.lbl0709.Name = "lbl0709";
            this.lbl0709.Size = new System.Drawing.Size(30, 30);
            this.lbl0709.TabIndex = 943;
            this.lbl0709.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0609
            // 
            this.lbl0609.BackColor = System.Drawing.Color.Teal;
            this.lbl0609.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0609.ForeColor = System.Drawing.Color.White;
            this.lbl0609.Location = new System.Drawing.Point(441, 222);
            this.lbl0609.Multiline = true;
            this.lbl0609.Name = "lbl0609";
            this.lbl0609.Size = new System.Drawing.Size(30, 30);
            this.lbl0609.TabIndex = 942;
            this.lbl0609.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0509
            // 
            this.lbl0509.BackColor = System.Drawing.Color.Teal;
            this.lbl0509.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0509.ForeColor = System.Drawing.Color.White;
            this.lbl0509.Location = new System.Drawing.Point(441, 186);
            this.lbl0509.Multiline = true;
            this.lbl0509.Name = "lbl0509";
            this.lbl0509.Size = new System.Drawing.Size(30, 30);
            this.lbl0509.TabIndex = 941;
            this.lbl0509.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0409
            // 
            this.lbl0409.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0409.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0409.ForeColor = System.Drawing.Color.White;
            this.lbl0409.Location = new System.Drawing.Point(441, 150);
            this.lbl0409.Multiline = true;
            this.lbl0409.Name = "lbl0409";
            this.lbl0409.Size = new System.Drawing.Size(30, 30);
            this.lbl0409.TabIndex = 940;
            this.lbl0409.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0309
            // 
            this.lbl0309.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0309.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0309.ForeColor = System.Drawing.Color.White;
            this.lbl0309.Location = new System.Drawing.Point(441, 114);
            this.lbl0309.Multiline = true;
            this.lbl0309.Name = "lbl0309";
            this.lbl0309.Size = new System.Drawing.Size(30, 30);
            this.lbl0309.TabIndex = 939;
            this.lbl0309.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0209
            // 
            this.lbl0209.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0209.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0209.ForeColor = System.Drawing.Color.White;
            this.lbl0209.Location = new System.Drawing.Point(441, 78);
            this.lbl0209.Multiline = true;
            this.lbl0209.Name = "lbl0209";
            this.lbl0209.Size = new System.Drawing.Size(30, 30);
            this.lbl0209.TabIndex = 938;
            this.lbl0209.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0109
            // 
            this.lbl0109.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl0109.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0109.ForeColor = System.Drawing.Color.White;
            this.lbl0109.Location = new System.Drawing.Point(441, 42);
            this.lbl0109.Multiline = true;
            this.lbl0109.Name = "lbl0109";
            this.lbl0109.Size = new System.Drawing.Size(30, 30);
            this.lbl0109.TabIndex = 937;
            this.lbl0109.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0808
            // 
            this.lbl0808.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0808.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0808.ForeColor = System.Drawing.Color.White;
            this.lbl0808.Location = new System.Drawing.Point(405, 294);
            this.lbl0808.Multiline = true;
            this.lbl0808.Name = "lbl0808";
            this.lbl0808.Size = new System.Drawing.Size(30, 30);
            this.lbl0808.TabIndex = 936;
            this.lbl0808.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0807
            // 
            this.lbl0807.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0807.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0807.ForeColor = System.Drawing.Color.White;
            this.lbl0807.Location = new System.Drawing.Point(369, 294);
            this.lbl0807.Multiline = true;
            this.lbl0807.Name = "lbl0807";
            this.lbl0807.Size = new System.Drawing.Size(30, 30);
            this.lbl0807.TabIndex = 935;
            this.lbl0807.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0806
            // 
            this.lbl0806.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0806.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0806.ForeColor = System.Drawing.Color.White;
            this.lbl0806.Location = new System.Drawing.Point(333, 294);
            this.lbl0806.Multiline = true;
            this.lbl0806.Name = "lbl0806";
            this.lbl0806.Size = new System.Drawing.Size(30, 30);
            this.lbl0806.TabIndex = 934;
            this.lbl0806.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0805
            // 
            this.lbl0805.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0805.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0805.ForeColor = System.Drawing.Color.White;
            this.lbl0805.Location = new System.Drawing.Point(297, 294);
            this.lbl0805.Multiline = true;
            this.lbl0805.Name = "lbl0805";
            this.lbl0805.Size = new System.Drawing.Size(30, 30);
            this.lbl0805.TabIndex = 933;
            this.lbl0805.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0708
            // 
            this.lbl0708.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0708.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0708.ForeColor = System.Drawing.Color.White;
            this.lbl0708.Location = new System.Drawing.Point(405, 258);
            this.lbl0708.Multiline = true;
            this.lbl0708.Name = "lbl0708";
            this.lbl0708.Size = new System.Drawing.Size(30, 30);
            this.lbl0708.TabIndex = 932;
            this.lbl0708.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0707
            // 
            this.lbl0707.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0707.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0707.ForeColor = System.Drawing.Color.White;
            this.lbl0707.Location = new System.Drawing.Point(369, 258);
            this.lbl0707.Multiline = true;
            this.lbl0707.Name = "lbl0707";
            this.lbl0707.Size = new System.Drawing.Size(30, 30);
            this.lbl0707.TabIndex = 931;
            this.lbl0707.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0706
            // 
            this.lbl0706.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0706.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0706.ForeColor = System.Drawing.Color.White;
            this.lbl0706.Location = new System.Drawing.Point(333, 258);
            this.lbl0706.Multiline = true;
            this.lbl0706.Name = "lbl0706";
            this.lbl0706.Size = new System.Drawing.Size(30, 30);
            this.lbl0706.TabIndex = 930;
            this.lbl0706.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0705
            // 
            this.lbl0705.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0705.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0705.ForeColor = System.Drawing.Color.White;
            this.lbl0705.Location = new System.Drawing.Point(297, 258);
            this.lbl0705.Multiline = true;
            this.lbl0705.Name = "lbl0705";
            this.lbl0705.Size = new System.Drawing.Size(30, 30);
            this.lbl0705.TabIndex = 929;
            this.lbl0705.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0804
            // 
            this.lbl0804.BackColor = System.Drawing.Color.Tomato;
            this.lbl0804.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0804.ForeColor = System.Drawing.Color.White;
            this.lbl0804.Location = new System.Drawing.Point(261, 294);
            this.lbl0804.Multiline = true;
            this.lbl0804.Name = "lbl0804";
            this.lbl0804.Size = new System.Drawing.Size(30, 30);
            this.lbl0804.TabIndex = 928;
            this.lbl0804.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0803
            // 
            this.lbl0803.BackColor = System.Drawing.Color.Tomato;
            this.lbl0803.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0803.ForeColor = System.Drawing.Color.White;
            this.lbl0803.Location = new System.Drawing.Point(225, 294);
            this.lbl0803.Multiline = true;
            this.lbl0803.Name = "lbl0803";
            this.lbl0803.Size = new System.Drawing.Size(30, 30);
            this.lbl0803.TabIndex = 927;
            this.lbl0803.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0802
            // 
            this.lbl0802.BackColor = System.Drawing.Color.Tomato;
            this.lbl0802.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0802.ForeColor = System.Drawing.Color.White;
            this.lbl0802.Location = new System.Drawing.Point(189, 294);
            this.lbl0802.Multiline = true;
            this.lbl0802.Name = "lbl0802";
            this.lbl0802.Size = new System.Drawing.Size(30, 30);
            this.lbl0802.TabIndex = 926;
            this.lbl0802.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0801
            // 
            this.lbl0801.BackColor = System.Drawing.Color.Tomato;
            this.lbl0801.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0801.ForeColor = System.Drawing.Color.White;
            this.lbl0801.Location = new System.Drawing.Point(153, 294);
            this.lbl0801.Multiline = true;
            this.lbl0801.Name = "lbl0801";
            this.lbl0801.Size = new System.Drawing.Size(30, 30);
            this.lbl0801.TabIndex = 925;
            this.lbl0801.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0704
            // 
            this.lbl0704.BackColor = System.Drawing.Color.Tomato;
            this.lbl0704.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0704.ForeColor = System.Drawing.Color.White;
            this.lbl0704.Location = new System.Drawing.Point(261, 258);
            this.lbl0704.Multiline = true;
            this.lbl0704.Name = "lbl0704";
            this.lbl0704.Size = new System.Drawing.Size(30, 30);
            this.lbl0704.TabIndex = 924;
            this.lbl0704.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0703
            // 
            this.lbl0703.BackColor = System.Drawing.Color.Tomato;
            this.lbl0703.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0703.ForeColor = System.Drawing.Color.White;
            this.lbl0703.Location = new System.Drawing.Point(225, 258);
            this.lbl0703.Multiline = true;
            this.lbl0703.Name = "lbl0703";
            this.lbl0703.Size = new System.Drawing.Size(30, 30);
            this.lbl0703.TabIndex = 923;
            this.lbl0703.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0702
            // 
            this.lbl0702.BackColor = System.Drawing.Color.Tomato;
            this.lbl0702.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0702.ForeColor = System.Drawing.Color.White;
            this.lbl0702.Location = new System.Drawing.Point(189, 258);
            this.lbl0702.Multiline = true;
            this.lbl0702.Name = "lbl0702";
            this.lbl0702.Size = new System.Drawing.Size(30, 30);
            this.lbl0702.TabIndex = 922;
            this.lbl0702.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0701
            // 
            this.lbl0701.BackColor = System.Drawing.Color.Tomato;
            this.lbl0701.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0701.ForeColor = System.Drawing.Color.White;
            this.lbl0701.Location = new System.Drawing.Point(153, 258);
            this.lbl0701.Multiline = true;
            this.lbl0701.Name = "lbl0701";
            this.lbl0701.Size = new System.Drawing.Size(30, 30);
            this.lbl0701.TabIndex = 921;
            this.lbl0701.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0608
            // 
            this.lbl0608.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0608.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0608.ForeColor = System.Drawing.Color.White;
            this.lbl0608.Location = new System.Drawing.Point(405, 222);
            this.lbl0608.Multiline = true;
            this.lbl0608.Name = "lbl0608";
            this.lbl0608.Size = new System.Drawing.Size(30, 30);
            this.lbl0608.TabIndex = 920;
            this.lbl0608.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0607
            // 
            this.lbl0607.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0607.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0607.ForeColor = System.Drawing.Color.White;
            this.lbl0607.Location = new System.Drawing.Point(369, 222);
            this.lbl0607.Multiline = true;
            this.lbl0607.Name = "lbl0607";
            this.lbl0607.Size = new System.Drawing.Size(30, 30);
            this.lbl0607.TabIndex = 919;
            this.lbl0607.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0606
            // 
            this.lbl0606.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0606.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0606.ForeColor = System.Drawing.Color.White;
            this.lbl0606.Location = new System.Drawing.Point(333, 222);
            this.lbl0606.Multiline = true;
            this.lbl0606.Name = "lbl0606";
            this.lbl0606.Size = new System.Drawing.Size(30, 30);
            this.lbl0606.TabIndex = 918;
            this.lbl0606.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0605
            // 
            this.lbl0605.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0605.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0605.ForeColor = System.Drawing.Color.White;
            this.lbl0605.Location = new System.Drawing.Point(297, 222);
            this.lbl0605.Multiline = true;
            this.lbl0605.Name = "lbl0605";
            this.lbl0605.Size = new System.Drawing.Size(30, 30);
            this.lbl0605.TabIndex = 917;
            this.lbl0605.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0508
            // 
            this.lbl0508.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0508.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0508.ForeColor = System.Drawing.Color.White;
            this.lbl0508.Location = new System.Drawing.Point(405, 186);
            this.lbl0508.Multiline = true;
            this.lbl0508.Name = "lbl0508";
            this.lbl0508.Size = new System.Drawing.Size(30, 30);
            this.lbl0508.TabIndex = 916;
            this.lbl0508.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0507
            // 
            this.lbl0507.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0507.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0507.ForeColor = System.Drawing.Color.White;
            this.lbl0507.Location = new System.Drawing.Point(369, 186);
            this.lbl0507.Multiline = true;
            this.lbl0507.Name = "lbl0507";
            this.lbl0507.Size = new System.Drawing.Size(30, 30);
            this.lbl0507.TabIndex = 915;
            this.lbl0507.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0506
            // 
            this.lbl0506.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0506.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0506.ForeColor = System.Drawing.Color.White;
            this.lbl0506.Location = new System.Drawing.Point(333, 186);
            this.lbl0506.Multiline = true;
            this.lbl0506.Name = "lbl0506";
            this.lbl0506.Size = new System.Drawing.Size(30, 30);
            this.lbl0506.TabIndex = 914;
            this.lbl0506.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0505
            // 
            this.lbl0505.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0505.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0505.ForeColor = System.Drawing.Color.White;
            this.lbl0505.Location = new System.Drawing.Point(297, 186);
            this.lbl0505.Multiline = true;
            this.lbl0505.Name = "lbl0505";
            this.lbl0505.Size = new System.Drawing.Size(30, 30);
            this.lbl0505.TabIndex = 913;
            this.lbl0505.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0408
            // 
            this.lbl0408.BackColor = System.Drawing.Color.Tan;
            this.lbl0408.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0408.ForeColor = System.Drawing.Color.White;
            this.lbl0408.Location = new System.Drawing.Point(405, 150);
            this.lbl0408.Multiline = true;
            this.lbl0408.Name = "lbl0408";
            this.lbl0408.Size = new System.Drawing.Size(30, 30);
            this.lbl0408.TabIndex = 912;
            this.lbl0408.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0407
            // 
            this.lbl0407.BackColor = System.Drawing.Color.Tan;
            this.lbl0407.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0407.ForeColor = System.Drawing.Color.White;
            this.lbl0407.Location = new System.Drawing.Point(369, 150);
            this.lbl0407.Multiline = true;
            this.lbl0407.Name = "lbl0407";
            this.lbl0407.Size = new System.Drawing.Size(30, 30);
            this.lbl0407.TabIndex = 911;
            this.lbl0407.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0406
            // 
            this.lbl0406.BackColor = System.Drawing.Color.Tan;
            this.lbl0406.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0406.ForeColor = System.Drawing.Color.White;
            this.lbl0406.Location = new System.Drawing.Point(333, 150);
            this.lbl0406.Multiline = true;
            this.lbl0406.Name = "lbl0406";
            this.lbl0406.Size = new System.Drawing.Size(30, 30);
            this.lbl0406.TabIndex = 910;
            this.lbl0406.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0405
            // 
            this.lbl0405.BackColor = System.Drawing.Color.Tan;
            this.lbl0405.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0405.ForeColor = System.Drawing.Color.White;
            this.lbl0405.Location = new System.Drawing.Point(297, 150);
            this.lbl0405.Multiline = true;
            this.lbl0405.Name = "lbl0405";
            this.lbl0405.Size = new System.Drawing.Size(30, 30);
            this.lbl0405.TabIndex = 909;
            this.lbl0405.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0308
            // 
            this.lbl0308.BackColor = System.Drawing.Color.Tan;
            this.lbl0308.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0308.ForeColor = System.Drawing.Color.White;
            this.lbl0308.Location = new System.Drawing.Point(405, 114);
            this.lbl0308.Multiline = true;
            this.lbl0308.Name = "lbl0308";
            this.lbl0308.Size = new System.Drawing.Size(30, 30);
            this.lbl0308.TabIndex = 908;
            this.lbl0308.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0307
            // 
            this.lbl0307.BackColor = System.Drawing.Color.Tan;
            this.lbl0307.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0307.ForeColor = System.Drawing.Color.White;
            this.lbl0307.Location = new System.Drawing.Point(369, 114);
            this.lbl0307.Multiline = true;
            this.lbl0307.Name = "lbl0307";
            this.lbl0307.Size = new System.Drawing.Size(30, 30);
            this.lbl0307.TabIndex = 907;
            this.lbl0307.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0306
            // 
            this.lbl0306.BackColor = System.Drawing.Color.Tan;
            this.lbl0306.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0306.ForeColor = System.Drawing.Color.White;
            this.lbl0306.Location = new System.Drawing.Point(333, 114);
            this.lbl0306.Multiline = true;
            this.lbl0306.Name = "lbl0306";
            this.lbl0306.Size = new System.Drawing.Size(30, 30);
            this.lbl0306.TabIndex = 906;
            this.lbl0306.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0305
            // 
            this.lbl0305.BackColor = System.Drawing.Color.Tan;
            this.lbl0305.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0305.ForeColor = System.Drawing.Color.White;
            this.lbl0305.Location = new System.Drawing.Point(297, 114);
            this.lbl0305.Multiline = true;
            this.lbl0305.Name = "lbl0305";
            this.lbl0305.Size = new System.Drawing.Size(30, 30);
            this.lbl0305.TabIndex = 905;
            this.lbl0305.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0208
            // 
            this.lbl0208.BackColor = System.Drawing.Color.Tan;
            this.lbl0208.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0208.ForeColor = System.Drawing.Color.White;
            this.lbl0208.Location = new System.Drawing.Point(405, 78);
            this.lbl0208.Multiline = true;
            this.lbl0208.Name = "lbl0208";
            this.lbl0208.Size = new System.Drawing.Size(30, 30);
            this.lbl0208.TabIndex = 904;
            this.lbl0208.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0207
            // 
            this.lbl0207.BackColor = System.Drawing.Color.Tan;
            this.lbl0207.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0207.ForeColor = System.Drawing.Color.White;
            this.lbl0207.Location = new System.Drawing.Point(369, 78);
            this.lbl0207.Multiline = true;
            this.lbl0207.Name = "lbl0207";
            this.lbl0207.Size = new System.Drawing.Size(30, 30);
            this.lbl0207.TabIndex = 903;
            this.lbl0207.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0206
            // 
            this.lbl0206.BackColor = System.Drawing.Color.Tan;
            this.lbl0206.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0206.ForeColor = System.Drawing.Color.White;
            this.lbl0206.Location = new System.Drawing.Point(333, 78);
            this.lbl0206.Multiline = true;
            this.lbl0206.Name = "lbl0206";
            this.lbl0206.Size = new System.Drawing.Size(30, 30);
            this.lbl0206.TabIndex = 902;
            this.lbl0206.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0205
            // 
            this.lbl0205.BackColor = System.Drawing.Color.Tan;
            this.lbl0205.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0205.ForeColor = System.Drawing.Color.White;
            this.lbl0205.Location = new System.Drawing.Point(297, 78);
            this.lbl0205.Multiline = true;
            this.lbl0205.Name = "lbl0205";
            this.lbl0205.Size = new System.Drawing.Size(30, 30);
            this.lbl0205.TabIndex = 901;
            this.lbl0205.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0108
            // 
            this.lbl0108.BackColor = System.Drawing.Color.Tan;
            this.lbl0108.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0108.ForeColor = System.Drawing.Color.White;
            this.lbl0108.Location = new System.Drawing.Point(405, 42);
            this.lbl0108.Multiline = true;
            this.lbl0108.Name = "lbl0108";
            this.lbl0108.Size = new System.Drawing.Size(30, 30);
            this.lbl0108.TabIndex = 900;
            this.lbl0108.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0107
            // 
            this.lbl0107.BackColor = System.Drawing.Color.Tan;
            this.lbl0107.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0107.ForeColor = System.Drawing.Color.White;
            this.lbl0107.Location = new System.Drawing.Point(369, 42);
            this.lbl0107.Multiline = true;
            this.lbl0107.Name = "lbl0107";
            this.lbl0107.Size = new System.Drawing.Size(30, 30);
            this.lbl0107.TabIndex = 899;
            this.lbl0107.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0106
            // 
            this.lbl0106.BackColor = System.Drawing.Color.Tan;
            this.lbl0106.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0106.ForeColor = System.Drawing.Color.White;
            this.lbl0106.Location = new System.Drawing.Point(333, 42);
            this.lbl0106.Multiline = true;
            this.lbl0106.Name = "lbl0106";
            this.lbl0106.Size = new System.Drawing.Size(30, 30);
            this.lbl0106.TabIndex = 898;
            this.lbl0106.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0105
            // 
            this.lbl0105.BackColor = System.Drawing.Color.Tan;
            this.lbl0105.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0105.ForeColor = System.Drawing.Color.White;
            this.lbl0105.Location = new System.Drawing.Point(297, 42);
            this.lbl0105.Multiline = true;
            this.lbl0105.Name = "lbl0105";
            this.lbl0105.Size = new System.Drawing.Size(30, 30);
            this.lbl0105.TabIndex = 897;
            this.lbl0105.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0604
            // 
            this.lbl0604.BackColor = System.Drawing.Color.Tomato;
            this.lbl0604.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0604.ForeColor = System.Drawing.Color.White;
            this.lbl0604.Location = new System.Drawing.Point(261, 222);
            this.lbl0604.Multiline = true;
            this.lbl0604.Name = "lbl0604";
            this.lbl0604.Size = new System.Drawing.Size(30, 30);
            this.lbl0604.TabIndex = 896;
            this.lbl0604.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0603
            // 
            this.lbl0603.BackColor = System.Drawing.Color.Tomato;
            this.lbl0603.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0603.ForeColor = System.Drawing.Color.White;
            this.lbl0603.Location = new System.Drawing.Point(225, 222);
            this.lbl0603.Multiline = true;
            this.lbl0603.Name = "lbl0603";
            this.lbl0603.Size = new System.Drawing.Size(30, 30);
            this.lbl0603.TabIndex = 895;
            this.lbl0603.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0602
            // 
            this.lbl0602.BackColor = System.Drawing.Color.Tomato;
            this.lbl0602.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0602.ForeColor = System.Drawing.Color.White;
            this.lbl0602.Location = new System.Drawing.Point(189, 222);
            this.lbl0602.Multiline = true;
            this.lbl0602.Name = "lbl0602";
            this.lbl0602.Size = new System.Drawing.Size(30, 30);
            this.lbl0602.TabIndex = 894;
            this.lbl0602.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0601
            // 
            this.lbl0601.BackColor = System.Drawing.Color.Tomato;
            this.lbl0601.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0601.ForeColor = System.Drawing.Color.White;
            this.lbl0601.Location = new System.Drawing.Point(153, 222);
            this.lbl0601.Multiline = true;
            this.lbl0601.Name = "lbl0601";
            this.lbl0601.Size = new System.Drawing.Size(30, 30);
            this.lbl0601.TabIndex = 893;
            this.lbl0601.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0504
            // 
            this.lbl0504.BackColor = System.Drawing.Color.Tomato;
            this.lbl0504.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0504.ForeColor = System.Drawing.Color.White;
            this.lbl0504.Location = new System.Drawing.Point(261, 186);
            this.lbl0504.Multiline = true;
            this.lbl0504.Name = "lbl0504";
            this.lbl0504.Size = new System.Drawing.Size(30, 30);
            this.lbl0504.TabIndex = 892;
            this.lbl0504.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0503
            // 
            this.lbl0503.BackColor = System.Drawing.Color.Tomato;
            this.lbl0503.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0503.ForeColor = System.Drawing.Color.White;
            this.lbl0503.Location = new System.Drawing.Point(225, 186);
            this.lbl0503.Multiline = true;
            this.lbl0503.Name = "lbl0503";
            this.lbl0503.Size = new System.Drawing.Size(30, 30);
            this.lbl0503.TabIndex = 891;
            this.lbl0503.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0502
            // 
            this.lbl0502.BackColor = System.Drawing.Color.Tomato;
            this.lbl0502.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0502.ForeColor = System.Drawing.Color.White;
            this.lbl0502.Location = new System.Drawing.Point(189, 186);
            this.lbl0502.Multiline = true;
            this.lbl0502.Name = "lbl0502";
            this.lbl0502.Size = new System.Drawing.Size(30, 30);
            this.lbl0502.TabIndex = 890;
            this.lbl0502.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0501
            // 
            this.lbl0501.BackColor = System.Drawing.Color.Tomato;
            this.lbl0501.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0501.ForeColor = System.Drawing.Color.White;
            this.lbl0501.Location = new System.Drawing.Point(153, 186);
            this.lbl0501.Multiline = true;
            this.lbl0501.Name = "lbl0501";
            this.lbl0501.Size = new System.Drawing.Size(30, 30);
            this.lbl0501.TabIndex = 889;
            this.lbl0501.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0404
            // 
            this.lbl0404.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0404.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0404.ForeColor = System.Drawing.Color.White;
            this.lbl0404.Location = new System.Drawing.Point(261, 150);
            this.lbl0404.Multiline = true;
            this.lbl0404.Name = "lbl0404";
            this.lbl0404.Size = new System.Drawing.Size(30, 30);
            this.lbl0404.TabIndex = 888;
            this.lbl0404.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0403
            // 
            this.lbl0403.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0403.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0403.ForeColor = System.Drawing.Color.White;
            this.lbl0403.Location = new System.Drawing.Point(225, 150);
            this.lbl0403.Multiline = true;
            this.lbl0403.Name = "lbl0403";
            this.lbl0403.Size = new System.Drawing.Size(30, 30);
            this.lbl0403.TabIndex = 887;
            this.lbl0403.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0402
            // 
            this.lbl0402.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0402.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0402.ForeColor = System.Drawing.Color.White;
            this.lbl0402.Location = new System.Drawing.Point(189, 150);
            this.lbl0402.Multiline = true;
            this.lbl0402.Name = "lbl0402";
            this.lbl0402.Size = new System.Drawing.Size(30, 30);
            this.lbl0402.TabIndex = 886;
            this.lbl0402.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0401
            // 
            this.lbl0401.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0401.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0401.ForeColor = System.Drawing.Color.White;
            this.lbl0401.Location = new System.Drawing.Point(153, 150);
            this.lbl0401.Multiline = true;
            this.lbl0401.Name = "lbl0401";
            this.lbl0401.Size = new System.Drawing.Size(30, 30);
            this.lbl0401.TabIndex = 885;
            this.lbl0401.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0304
            // 
            this.lbl0304.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0304.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0304.ForeColor = System.Drawing.Color.White;
            this.lbl0304.Location = new System.Drawing.Point(261, 114);
            this.lbl0304.Multiline = true;
            this.lbl0304.Name = "lbl0304";
            this.lbl0304.Size = new System.Drawing.Size(30, 30);
            this.lbl0304.TabIndex = 884;
            this.lbl0304.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0303
            // 
            this.lbl0303.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0303.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0303.ForeColor = System.Drawing.Color.White;
            this.lbl0303.Location = new System.Drawing.Point(225, 114);
            this.lbl0303.Multiline = true;
            this.lbl0303.Name = "lbl0303";
            this.lbl0303.Size = new System.Drawing.Size(30, 30);
            this.lbl0303.TabIndex = 883;
            this.lbl0303.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0302
            // 
            this.lbl0302.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0302.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0302.ForeColor = System.Drawing.Color.White;
            this.lbl0302.Location = new System.Drawing.Point(189, 114);
            this.lbl0302.Multiline = true;
            this.lbl0302.Name = "lbl0302";
            this.lbl0302.Size = new System.Drawing.Size(30, 30);
            this.lbl0302.TabIndex = 882;
            this.lbl0302.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0301
            // 
            this.lbl0301.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0301.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0301.ForeColor = System.Drawing.Color.White;
            this.lbl0301.Location = new System.Drawing.Point(153, 114);
            this.lbl0301.Multiline = true;
            this.lbl0301.Name = "lbl0301";
            this.lbl0301.Size = new System.Drawing.Size(30, 30);
            this.lbl0301.TabIndex = 881;
            this.lbl0301.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0204
            // 
            this.lbl0204.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0204.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0204.ForeColor = System.Drawing.Color.White;
            this.lbl0204.Location = new System.Drawing.Point(261, 78);
            this.lbl0204.Multiline = true;
            this.lbl0204.Name = "lbl0204";
            this.lbl0204.Size = new System.Drawing.Size(30, 30);
            this.lbl0204.TabIndex = 880;
            this.lbl0204.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0203
            // 
            this.lbl0203.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0203.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0203.ForeColor = System.Drawing.Color.White;
            this.lbl0203.Location = new System.Drawing.Point(225, 78);
            this.lbl0203.Multiline = true;
            this.lbl0203.Name = "lbl0203";
            this.lbl0203.Size = new System.Drawing.Size(30, 30);
            this.lbl0203.TabIndex = 879;
            this.lbl0203.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0202
            // 
            this.lbl0202.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0202.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0202.ForeColor = System.Drawing.Color.White;
            this.lbl0202.Location = new System.Drawing.Point(189, 78);
            this.lbl0202.Multiline = true;
            this.lbl0202.Name = "lbl0202";
            this.lbl0202.Size = new System.Drawing.Size(30, 30);
            this.lbl0202.TabIndex = 878;
            this.lbl0202.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0201
            // 
            this.lbl0201.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0201.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0201.ForeColor = System.Drawing.Color.White;
            this.lbl0201.Location = new System.Drawing.Point(153, 78);
            this.lbl0201.Multiline = true;
            this.lbl0201.Name = "lbl0201";
            this.lbl0201.Size = new System.Drawing.Size(30, 30);
            this.lbl0201.TabIndex = 877;
            this.lbl0201.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0104
            // 
            this.lbl0104.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0104.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0104.ForeColor = System.Drawing.Color.White;
            this.lbl0104.Location = new System.Drawing.Point(261, 42);
            this.lbl0104.Multiline = true;
            this.lbl0104.Name = "lbl0104";
            this.lbl0104.Size = new System.Drawing.Size(30, 30);
            this.lbl0104.TabIndex = 876;
            this.lbl0104.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0103
            // 
            this.lbl0103.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0103.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0103.ForeColor = System.Drawing.Color.White;
            this.lbl0103.Location = new System.Drawing.Point(225, 42);
            this.lbl0103.Multiline = true;
            this.lbl0103.Name = "lbl0103";
            this.lbl0103.Size = new System.Drawing.Size(30, 30);
            this.lbl0103.TabIndex = 875;
            this.lbl0103.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0102
            // 
            this.lbl0102.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0102.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0102.ForeColor = System.Drawing.Color.White;
            this.lbl0102.Location = new System.Drawing.Point(189, 42);
            this.lbl0102.Multiline = true;
            this.lbl0102.Name = "lbl0102";
            this.lbl0102.Size = new System.Drawing.Size(30, 30);
            this.lbl0102.TabIndex = 874;
            this.lbl0102.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0101
            // 
            this.lbl0101.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl0101.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0101.ForeColor = System.Drawing.Color.White;
            this.lbl0101.Location = new System.Drawing.Point(153, 42);
            this.lbl0101.Multiline = true;
            this.lbl0101.Name = "lbl0101";
            this.lbl0101.Size = new System.Drawing.Size(30, 30);
            this.lbl0101.TabIndex = 873;
            this.lbl0101.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1216
            // 
            this.lbl1216.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1216.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1216.ForeColor = System.Drawing.Color.White;
            this.lbl1216.Location = new System.Drawing.Point(693, 438);
            this.lbl1216.Multiline = true;
            this.lbl1216.Name = "lbl1216";
            this.lbl1216.Size = new System.Drawing.Size(30, 30);
            this.lbl1216.TabIndex = 1068;
            this.lbl1216.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1215
            // 
            this.lbl1215.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1215.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1215.ForeColor = System.Drawing.Color.White;
            this.lbl1215.Location = new System.Drawing.Point(657, 438);
            this.lbl1215.Multiline = true;
            this.lbl1215.Name = "lbl1215";
            this.lbl1215.Size = new System.Drawing.Size(30, 30);
            this.lbl1215.TabIndex = 1067;
            this.lbl1215.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1214
            // 
            this.lbl1214.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1214.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1214.ForeColor = System.Drawing.Color.White;
            this.lbl1214.Location = new System.Drawing.Point(621, 438);
            this.lbl1214.Multiline = true;
            this.lbl1214.Name = "lbl1214";
            this.lbl1214.Size = new System.Drawing.Size(30, 30);
            this.lbl1214.TabIndex = 1066;
            this.lbl1214.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1213
            // 
            this.lbl1213.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1213.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1213.ForeColor = System.Drawing.Color.White;
            this.lbl1213.Location = new System.Drawing.Point(585, 438);
            this.lbl1213.Multiline = true;
            this.lbl1213.Name = "lbl1213";
            this.lbl1213.Size = new System.Drawing.Size(30, 30);
            this.lbl1213.TabIndex = 1065;
            this.lbl1213.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1116
            // 
            this.lbl1116.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1116.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1116.ForeColor = System.Drawing.Color.White;
            this.lbl1116.Location = new System.Drawing.Point(693, 402);
            this.lbl1116.Multiline = true;
            this.lbl1116.Name = "lbl1116";
            this.lbl1116.Size = new System.Drawing.Size(30, 30);
            this.lbl1116.TabIndex = 1064;
            this.lbl1116.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1016
            // 
            this.lbl1016.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1016.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1016.ForeColor = System.Drawing.Color.White;
            this.lbl1016.Location = new System.Drawing.Point(693, 366);
            this.lbl1016.Multiline = true;
            this.lbl1016.Name = "lbl1016";
            this.lbl1016.Size = new System.Drawing.Size(30, 30);
            this.lbl1016.TabIndex = 1063;
            this.lbl1016.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0916
            // 
            this.lbl0916.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl0916.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0916.ForeColor = System.Drawing.Color.White;
            this.lbl0916.Location = new System.Drawing.Point(693, 330);
            this.lbl0916.Multiline = true;
            this.lbl0916.Name = "lbl0916";
            this.lbl0916.Size = new System.Drawing.Size(30, 30);
            this.lbl0916.TabIndex = 1062;
            this.lbl0916.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0816
            // 
            this.lbl0816.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0816.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0816.ForeColor = System.Drawing.Color.White;
            this.lbl0816.Location = new System.Drawing.Point(693, 294);
            this.lbl0816.Multiline = true;
            this.lbl0816.Name = "lbl0816";
            this.lbl0816.Size = new System.Drawing.Size(30, 30);
            this.lbl0816.TabIndex = 1061;
            this.lbl0816.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0716
            // 
            this.lbl0716.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0716.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0716.ForeColor = System.Drawing.Color.White;
            this.lbl0716.Location = new System.Drawing.Point(693, 258);
            this.lbl0716.Multiline = true;
            this.lbl0716.Name = "lbl0716";
            this.lbl0716.Size = new System.Drawing.Size(30, 30);
            this.lbl0716.TabIndex = 1060;
            this.lbl0716.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0616
            // 
            this.lbl0616.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0616.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0616.ForeColor = System.Drawing.Color.White;
            this.lbl0616.Location = new System.Drawing.Point(693, 222);
            this.lbl0616.Multiline = true;
            this.lbl0616.Name = "lbl0616";
            this.lbl0616.Size = new System.Drawing.Size(30, 30);
            this.lbl0616.TabIndex = 1059;
            this.lbl0616.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0516
            // 
            this.lbl0516.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0516.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0516.ForeColor = System.Drawing.Color.White;
            this.lbl0516.Location = new System.Drawing.Point(693, 186);
            this.lbl0516.Multiline = true;
            this.lbl0516.Name = "lbl0516";
            this.lbl0516.Size = new System.Drawing.Size(30, 30);
            this.lbl0516.TabIndex = 1058;
            this.lbl0516.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0416
            // 
            this.lbl0416.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0416.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0416.ForeColor = System.Drawing.Color.White;
            this.lbl0416.Location = new System.Drawing.Point(693, 150);
            this.lbl0416.Multiline = true;
            this.lbl0416.Name = "lbl0416";
            this.lbl0416.Size = new System.Drawing.Size(30, 30);
            this.lbl0416.TabIndex = 1057;
            this.lbl0416.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0316
            // 
            this.lbl0316.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0316.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0316.ForeColor = System.Drawing.Color.White;
            this.lbl0316.Location = new System.Drawing.Point(693, 114);
            this.lbl0316.Multiline = true;
            this.lbl0316.Name = "lbl0316";
            this.lbl0316.Size = new System.Drawing.Size(30, 30);
            this.lbl0316.TabIndex = 1056;
            this.lbl0316.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0216
            // 
            this.lbl0216.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0216.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0216.ForeColor = System.Drawing.Color.White;
            this.lbl0216.Location = new System.Drawing.Point(693, 78);
            this.lbl0216.Multiline = true;
            this.lbl0216.Name = "lbl0216";
            this.lbl0216.Size = new System.Drawing.Size(30, 30);
            this.lbl0216.TabIndex = 1055;
            this.lbl0216.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0116
            // 
            this.lbl0116.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0116.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0116.ForeColor = System.Drawing.Color.White;
            this.lbl0116.Location = new System.Drawing.Point(693, 42);
            this.lbl0116.Multiline = true;
            this.lbl0116.Name = "lbl0116";
            this.lbl0116.Size = new System.Drawing.Size(30, 30);
            this.lbl0116.TabIndex = 1054;
            this.lbl0116.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1115
            // 
            this.lbl1115.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1115.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1115.ForeColor = System.Drawing.Color.White;
            this.lbl1115.Location = new System.Drawing.Point(657, 402);
            this.lbl1115.Multiline = true;
            this.lbl1115.Name = "lbl1115";
            this.lbl1115.Size = new System.Drawing.Size(30, 30);
            this.lbl1115.TabIndex = 1053;
            this.lbl1115.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1015
            // 
            this.lbl1015.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1015.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1015.ForeColor = System.Drawing.Color.White;
            this.lbl1015.Location = new System.Drawing.Point(657, 366);
            this.lbl1015.Multiline = true;
            this.lbl1015.Name = "lbl1015";
            this.lbl1015.Size = new System.Drawing.Size(30, 30);
            this.lbl1015.TabIndex = 1052;
            this.lbl1015.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0915
            // 
            this.lbl0915.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl0915.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0915.ForeColor = System.Drawing.Color.White;
            this.lbl0915.Location = new System.Drawing.Point(657, 330);
            this.lbl0915.Multiline = true;
            this.lbl0915.Name = "lbl0915";
            this.lbl0915.Size = new System.Drawing.Size(30, 30);
            this.lbl0915.TabIndex = 1051;
            this.lbl0915.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0815
            // 
            this.lbl0815.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0815.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0815.ForeColor = System.Drawing.Color.White;
            this.lbl0815.Location = new System.Drawing.Point(657, 294);
            this.lbl0815.Multiline = true;
            this.lbl0815.Name = "lbl0815";
            this.lbl0815.Size = new System.Drawing.Size(30, 30);
            this.lbl0815.TabIndex = 1050;
            this.lbl0815.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0715
            // 
            this.lbl0715.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0715.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0715.ForeColor = System.Drawing.Color.White;
            this.lbl0715.Location = new System.Drawing.Point(657, 258);
            this.lbl0715.Multiline = true;
            this.lbl0715.Name = "lbl0715";
            this.lbl0715.Size = new System.Drawing.Size(30, 30);
            this.lbl0715.TabIndex = 1049;
            this.lbl0715.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0615
            // 
            this.lbl0615.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0615.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0615.ForeColor = System.Drawing.Color.White;
            this.lbl0615.Location = new System.Drawing.Point(657, 222);
            this.lbl0615.Multiline = true;
            this.lbl0615.Name = "lbl0615";
            this.lbl0615.Size = new System.Drawing.Size(30, 30);
            this.lbl0615.TabIndex = 1048;
            this.lbl0615.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0515
            // 
            this.lbl0515.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0515.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0515.ForeColor = System.Drawing.Color.White;
            this.lbl0515.Location = new System.Drawing.Point(657, 186);
            this.lbl0515.Multiline = true;
            this.lbl0515.Name = "lbl0515";
            this.lbl0515.Size = new System.Drawing.Size(30, 30);
            this.lbl0515.TabIndex = 1047;
            this.lbl0515.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0415
            // 
            this.lbl0415.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0415.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0415.ForeColor = System.Drawing.Color.White;
            this.lbl0415.Location = new System.Drawing.Point(657, 150);
            this.lbl0415.Multiline = true;
            this.lbl0415.Name = "lbl0415";
            this.lbl0415.Size = new System.Drawing.Size(30, 30);
            this.lbl0415.TabIndex = 1046;
            this.lbl0415.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0315
            // 
            this.lbl0315.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0315.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0315.ForeColor = System.Drawing.Color.White;
            this.lbl0315.Location = new System.Drawing.Point(657, 114);
            this.lbl0315.Multiline = true;
            this.lbl0315.Name = "lbl0315";
            this.lbl0315.Size = new System.Drawing.Size(30, 30);
            this.lbl0315.TabIndex = 1045;
            this.lbl0315.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0215
            // 
            this.lbl0215.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0215.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0215.ForeColor = System.Drawing.Color.White;
            this.lbl0215.Location = new System.Drawing.Point(657, 78);
            this.lbl0215.Multiline = true;
            this.lbl0215.Name = "lbl0215";
            this.lbl0215.Size = new System.Drawing.Size(30, 30);
            this.lbl0215.TabIndex = 1044;
            this.lbl0215.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0115
            // 
            this.lbl0115.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0115.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0115.ForeColor = System.Drawing.Color.White;
            this.lbl0115.Location = new System.Drawing.Point(657, 42);
            this.lbl0115.Multiline = true;
            this.lbl0115.Name = "lbl0115";
            this.lbl0115.Size = new System.Drawing.Size(30, 30);
            this.lbl0115.TabIndex = 1043;
            this.lbl0115.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1114
            // 
            this.lbl1114.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1114.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1114.ForeColor = System.Drawing.Color.White;
            this.lbl1114.Location = new System.Drawing.Point(621, 402);
            this.lbl1114.Multiline = true;
            this.lbl1114.Name = "lbl1114";
            this.lbl1114.Size = new System.Drawing.Size(30, 30);
            this.lbl1114.TabIndex = 1042;
            this.lbl1114.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1113
            // 
            this.lbl1113.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1113.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1113.ForeColor = System.Drawing.Color.White;
            this.lbl1113.Location = new System.Drawing.Point(585, 402);
            this.lbl1113.Multiline = true;
            this.lbl1113.Name = "lbl1113";
            this.lbl1113.Size = new System.Drawing.Size(30, 30);
            this.lbl1113.TabIndex = 1041;
            this.lbl1113.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1014
            // 
            this.lbl1014.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1014.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1014.ForeColor = System.Drawing.Color.White;
            this.lbl1014.Location = new System.Drawing.Point(621, 366);
            this.lbl1014.Multiline = true;
            this.lbl1014.Name = "lbl1014";
            this.lbl1014.Size = new System.Drawing.Size(30, 30);
            this.lbl1014.TabIndex = 1040;
            this.lbl1014.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1013
            // 
            this.lbl1013.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1013.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1013.ForeColor = System.Drawing.Color.White;
            this.lbl1013.Location = new System.Drawing.Point(585, 366);
            this.lbl1013.Multiline = true;
            this.lbl1013.Name = "lbl1013";
            this.lbl1013.Size = new System.Drawing.Size(30, 30);
            this.lbl1013.TabIndex = 1039;
            this.lbl1013.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0914
            // 
            this.lbl0914.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl0914.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0914.ForeColor = System.Drawing.Color.White;
            this.lbl0914.Location = new System.Drawing.Point(621, 330);
            this.lbl0914.Multiline = true;
            this.lbl0914.Name = "lbl0914";
            this.lbl0914.Size = new System.Drawing.Size(30, 30);
            this.lbl0914.TabIndex = 1038;
            this.lbl0914.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0913
            // 
            this.lbl0913.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl0913.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0913.ForeColor = System.Drawing.Color.White;
            this.lbl0913.Location = new System.Drawing.Point(585, 330);
            this.lbl0913.Multiline = true;
            this.lbl0913.Name = "lbl0913";
            this.lbl0913.Size = new System.Drawing.Size(30, 30);
            this.lbl0913.TabIndex = 1037;
            this.lbl0913.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0814
            // 
            this.lbl0814.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0814.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0814.ForeColor = System.Drawing.Color.White;
            this.lbl0814.Location = new System.Drawing.Point(621, 294);
            this.lbl0814.Multiline = true;
            this.lbl0814.Name = "lbl0814";
            this.lbl0814.Size = new System.Drawing.Size(30, 30);
            this.lbl0814.TabIndex = 1036;
            this.lbl0814.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0714
            // 
            this.lbl0714.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0714.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0714.ForeColor = System.Drawing.Color.White;
            this.lbl0714.Location = new System.Drawing.Point(621, 258);
            this.lbl0714.Multiline = true;
            this.lbl0714.Name = "lbl0714";
            this.lbl0714.Size = new System.Drawing.Size(30, 30);
            this.lbl0714.TabIndex = 1035;
            this.lbl0714.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0614
            // 
            this.lbl0614.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0614.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0614.ForeColor = System.Drawing.Color.White;
            this.lbl0614.Location = new System.Drawing.Point(621, 222);
            this.lbl0614.Multiline = true;
            this.lbl0614.Name = "lbl0614";
            this.lbl0614.Size = new System.Drawing.Size(30, 30);
            this.lbl0614.TabIndex = 1034;
            this.lbl0614.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0514
            // 
            this.lbl0514.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0514.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0514.ForeColor = System.Drawing.Color.White;
            this.lbl0514.Location = new System.Drawing.Point(621, 186);
            this.lbl0514.Multiline = true;
            this.lbl0514.Name = "lbl0514";
            this.lbl0514.Size = new System.Drawing.Size(30, 30);
            this.lbl0514.TabIndex = 1033;
            this.lbl0514.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0414
            // 
            this.lbl0414.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0414.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0414.ForeColor = System.Drawing.Color.White;
            this.lbl0414.Location = new System.Drawing.Point(621, 150);
            this.lbl0414.Multiline = true;
            this.lbl0414.Name = "lbl0414";
            this.lbl0414.Size = new System.Drawing.Size(30, 30);
            this.lbl0414.TabIndex = 1032;
            this.lbl0414.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0314
            // 
            this.lbl0314.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0314.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0314.ForeColor = System.Drawing.Color.White;
            this.lbl0314.Location = new System.Drawing.Point(621, 114);
            this.lbl0314.Multiline = true;
            this.lbl0314.Name = "lbl0314";
            this.lbl0314.Size = new System.Drawing.Size(30, 30);
            this.lbl0314.TabIndex = 1031;
            this.lbl0314.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0214
            // 
            this.lbl0214.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0214.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0214.ForeColor = System.Drawing.Color.White;
            this.lbl0214.Location = new System.Drawing.Point(621, 78);
            this.lbl0214.Multiline = true;
            this.lbl0214.Name = "lbl0214";
            this.lbl0214.Size = new System.Drawing.Size(30, 30);
            this.lbl0214.TabIndex = 1030;
            this.lbl0214.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0114
            // 
            this.lbl0114.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0114.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0114.ForeColor = System.Drawing.Color.White;
            this.lbl0114.Location = new System.Drawing.Point(621, 42);
            this.lbl0114.Multiline = true;
            this.lbl0114.Name = "lbl0114";
            this.lbl0114.Size = new System.Drawing.Size(30, 30);
            this.lbl0114.TabIndex = 1029;
            this.lbl0114.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0813
            // 
            this.lbl0813.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0813.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0813.ForeColor = System.Drawing.Color.White;
            this.lbl0813.Location = new System.Drawing.Point(585, 294);
            this.lbl0813.Multiline = true;
            this.lbl0813.Name = "lbl0813";
            this.lbl0813.Size = new System.Drawing.Size(30, 30);
            this.lbl0813.TabIndex = 1028;
            this.lbl0813.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0713
            // 
            this.lbl0713.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0713.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0713.ForeColor = System.Drawing.Color.White;
            this.lbl0713.Location = new System.Drawing.Point(585, 258);
            this.lbl0713.Multiline = true;
            this.lbl0713.Name = "lbl0713";
            this.lbl0713.Size = new System.Drawing.Size(30, 30);
            this.lbl0713.TabIndex = 1027;
            this.lbl0713.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0613
            // 
            this.lbl0613.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0613.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0613.ForeColor = System.Drawing.Color.White;
            this.lbl0613.Location = new System.Drawing.Point(585, 222);
            this.lbl0613.Multiline = true;
            this.lbl0613.Name = "lbl0613";
            this.lbl0613.Size = new System.Drawing.Size(30, 30);
            this.lbl0613.TabIndex = 1026;
            this.lbl0613.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0513
            // 
            this.lbl0513.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl0513.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0513.ForeColor = System.Drawing.Color.White;
            this.lbl0513.Location = new System.Drawing.Point(585, 186);
            this.lbl0513.Multiline = true;
            this.lbl0513.Name = "lbl0513";
            this.lbl0513.Size = new System.Drawing.Size(30, 30);
            this.lbl0513.TabIndex = 1025;
            this.lbl0513.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0413
            // 
            this.lbl0413.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0413.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0413.ForeColor = System.Drawing.Color.White;
            this.lbl0413.Location = new System.Drawing.Point(585, 150);
            this.lbl0413.Multiline = true;
            this.lbl0413.Name = "lbl0413";
            this.lbl0413.Size = new System.Drawing.Size(30, 30);
            this.lbl0413.TabIndex = 1024;
            this.lbl0413.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0313
            // 
            this.lbl0313.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0313.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0313.ForeColor = System.Drawing.Color.White;
            this.lbl0313.Location = new System.Drawing.Point(585, 114);
            this.lbl0313.Multiline = true;
            this.lbl0313.Name = "lbl0313";
            this.lbl0313.Size = new System.Drawing.Size(30, 30);
            this.lbl0313.TabIndex = 1023;
            this.lbl0313.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0213
            // 
            this.lbl0213.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0213.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0213.ForeColor = System.Drawing.Color.White;
            this.lbl0213.Location = new System.Drawing.Point(585, 78);
            this.lbl0213.Multiline = true;
            this.lbl0213.Name = "lbl0213";
            this.lbl0213.Size = new System.Drawing.Size(30, 30);
            this.lbl0213.TabIndex = 1022;
            this.lbl0213.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0113
            // 
            this.lbl0113.BackColor = System.Drawing.Color.OliveDrab;
            this.lbl0113.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0113.ForeColor = System.Drawing.Color.White;
            this.lbl0113.Location = new System.Drawing.Point(585, 42);
            this.lbl0113.Multiline = true;
            this.lbl0113.Name = "lbl0113";
            this.lbl0113.Size = new System.Drawing.Size(30, 30);
            this.lbl0113.TabIndex = 1021;
            this.lbl0113.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1516
            // 
            this.lbl1516.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1516.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1516.ForeColor = System.Drawing.Color.White;
            this.lbl1516.Location = new System.Drawing.Point(693, 546);
            this.lbl1516.Multiline = true;
            this.lbl1516.Name = "lbl1516";
            this.lbl1516.Size = new System.Drawing.Size(30, 30);
            this.lbl1516.TabIndex = 1116;
            this.lbl1516.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1515
            // 
            this.lbl1515.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1515.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1515.ForeColor = System.Drawing.Color.White;
            this.lbl1515.Location = new System.Drawing.Point(657, 546);
            this.lbl1515.Multiline = true;
            this.lbl1515.Name = "lbl1515";
            this.lbl1515.Size = new System.Drawing.Size(30, 30);
            this.lbl1515.TabIndex = 1115;
            this.lbl1515.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1514
            // 
            this.lbl1514.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1514.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1514.ForeColor = System.Drawing.Color.White;
            this.lbl1514.Location = new System.Drawing.Point(621, 546);
            this.lbl1514.Multiline = true;
            this.lbl1514.Name = "lbl1514";
            this.lbl1514.Size = new System.Drawing.Size(30, 30);
            this.lbl1514.TabIndex = 1114;
            this.lbl1514.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1513
            // 
            this.lbl1513.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1513.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1513.ForeColor = System.Drawing.Color.White;
            this.lbl1513.Location = new System.Drawing.Point(585, 546);
            this.lbl1513.Multiline = true;
            this.lbl1513.Name = "lbl1513";
            this.lbl1513.Size = new System.Drawing.Size(30, 30);
            this.lbl1513.TabIndex = 1113;
            this.lbl1513.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1416
            // 
            this.lbl1416.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1416.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1416.ForeColor = System.Drawing.Color.White;
            this.lbl1416.Location = new System.Drawing.Point(693, 510);
            this.lbl1416.Multiline = true;
            this.lbl1416.Name = "lbl1416";
            this.lbl1416.Size = new System.Drawing.Size(30, 30);
            this.lbl1416.TabIndex = 1112;
            this.lbl1416.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1316
            // 
            this.lbl1316.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1316.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1316.ForeColor = System.Drawing.Color.White;
            this.lbl1316.Location = new System.Drawing.Point(693, 474);
            this.lbl1316.Multiline = true;
            this.lbl1316.Name = "lbl1316";
            this.lbl1316.Size = new System.Drawing.Size(30, 30);
            this.lbl1316.TabIndex = 1111;
            this.lbl1316.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1415
            // 
            this.lbl1415.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1415.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1415.ForeColor = System.Drawing.Color.White;
            this.lbl1415.Location = new System.Drawing.Point(657, 510);
            this.lbl1415.Multiline = true;
            this.lbl1415.Name = "lbl1415";
            this.lbl1415.Size = new System.Drawing.Size(30, 30);
            this.lbl1415.TabIndex = 1110;
            this.lbl1415.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1315
            // 
            this.lbl1315.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1315.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1315.ForeColor = System.Drawing.Color.White;
            this.lbl1315.Location = new System.Drawing.Point(657, 474);
            this.lbl1315.Multiline = true;
            this.lbl1315.Name = "lbl1315";
            this.lbl1315.Size = new System.Drawing.Size(30, 30);
            this.lbl1315.TabIndex = 1109;
            this.lbl1315.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1414
            // 
            this.lbl1414.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1414.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1414.ForeColor = System.Drawing.Color.White;
            this.lbl1414.Location = new System.Drawing.Point(621, 510);
            this.lbl1414.Multiline = true;
            this.lbl1414.Name = "lbl1414";
            this.lbl1414.Size = new System.Drawing.Size(30, 30);
            this.lbl1414.TabIndex = 1108;
            this.lbl1414.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1413
            // 
            this.lbl1413.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1413.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1413.ForeColor = System.Drawing.Color.White;
            this.lbl1413.Location = new System.Drawing.Point(585, 510);
            this.lbl1413.Multiline = true;
            this.lbl1413.Name = "lbl1413";
            this.lbl1413.Size = new System.Drawing.Size(30, 30);
            this.lbl1413.TabIndex = 1107;
            this.lbl1413.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1314
            // 
            this.lbl1314.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1314.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1314.ForeColor = System.Drawing.Color.White;
            this.lbl1314.Location = new System.Drawing.Point(621, 474);
            this.lbl1314.Multiline = true;
            this.lbl1314.Name = "lbl1314";
            this.lbl1314.Size = new System.Drawing.Size(30, 30);
            this.lbl1314.TabIndex = 1106;
            this.lbl1314.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1313
            // 
            this.lbl1313.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1313.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1313.ForeColor = System.Drawing.Color.White;
            this.lbl1313.Location = new System.Drawing.Point(585, 474);
            this.lbl1313.Multiline = true;
            this.lbl1313.Name = "lbl1313";
            this.lbl1313.Size = new System.Drawing.Size(30, 30);
            this.lbl1313.TabIndex = 1105;
            this.lbl1313.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1512
            // 
            this.lbl1512.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1512.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1512.ForeColor = System.Drawing.Color.White;
            this.lbl1512.Location = new System.Drawing.Point(549, 546);
            this.lbl1512.Multiline = true;
            this.lbl1512.Name = "lbl1512";
            this.lbl1512.Size = new System.Drawing.Size(30, 30);
            this.lbl1512.TabIndex = 1104;
            this.lbl1512.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1511
            // 
            this.lbl1511.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1511.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1511.ForeColor = System.Drawing.Color.White;
            this.lbl1511.Location = new System.Drawing.Point(513, 546);
            this.lbl1511.Multiline = true;
            this.lbl1511.Name = "lbl1511";
            this.lbl1511.Size = new System.Drawing.Size(30, 30);
            this.lbl1511.TabIndex = 1103;
            this.lbl1511.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1510
            // 
            this.lbl1510.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1510.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1510.ForeColor = System.Drawing.Color.White;
            this.lbl1510.Location = new System.Drawing.Point(477, 546);
            this.lbl1510.Multiline = true;
            this.lbl1510.Name = "lbl1510";
            this.lbl1510.Size = new System.Drawing.Size(30, 30);
            this.lbl1510.TabIndex = 1102;
            this.lbl1510.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1509
            // 
            this.lbl1509.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1509.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1509.ForeColor = System.Drawing.Color.White;
            this.lbl1509.Location = new System.Drawing.Point(441, 546);
            this.lbl1509.Multiline = true;
            this.lbl1509.Name = "lbl1509";
            this.lbl1509.Size = new System.Drawing.Size(30, 30);
            this.lbl1509.TabIndex = 1101;
            this.lbl1509.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1508
            // 
            this.lbl1508.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1508.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1508.ForeColor = System.Drawing.Color.White;
            this.lbl1508.Location = new System.Drawing.Point(405, 546);
            this.lbl1508.Multiline = true;
            this.lbl1508.Name = "lbl1508";
            this.lbl1508.Size = new System.Drawing.Size(30, 30);
            this.lbl1508.TabIndex = 1100;
            this.lbl1508.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1507
            // 
            this.lbl1507.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1507.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1507.ForeColor = System.Drawing.Color.White;
            this.lbl1507.Location = new System.Drawing.Point(369, 546);
            this.lbl1507.Multiline = true;
            this.lbl1507.Name = "lbl1507";
            this.lbl1507.Size = new System.Drawing.Size(30, 30);
            this.lbl1507.TabIndex = 1099;
            this.lbl1507.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1506
            // 
            this.lbl1506.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1506.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1506.ForeColor = System.Drawing.Color.White;
            this.lbl1506.Location = new System.Drawing.Point(333, 546);
            this.lbl1506.Multiline = true;
            this.lbl1506.Name = "lbl1506";
            this.lbl1506.Size = new System.Drawing.Size(30, 30);
            this.lbl1506.TabIndex = 1098;
            this.lbl1506.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1505
            // 
            this.lbl1505.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1505.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1505.ForeColor = System.Drawing.Color.White;
            this.lbl1505.Location = new System.Drawing.Point(297, 546);
            this.lbl1505.Multiline = true;
            this.lbl1505.Name = "lbl1505";
            this.lbl1505.Size = new System.Drawing.Size(30, 30);
            this.lbl1505.TabIndex = 1097;
            this.lbl1505.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1504
            // 
            this.lbl1504.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1504.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1504.ForeColor = System.Drawing.Color.White;
            this.lbl1504.Location = new System.Drawing.Point(261, 546);
            this.lbl1504.Multiline = true;
            this.lbl1504.Name = "lbl1504";
            this.lbl1504.Size = new System.Drawing.Size(30, 30);
            this.lbl1504.TabIndex = 1096;
            this.lbl1504.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1503
            // 
            this.lbl1503.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1503.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1503.ForeColor = System.Drawing.Color.White;
            this.lbl1503.Location = new System.Drawing.Point(225, 546);
            this.lbl1503.Multiline = true;
            this.lbl1503.Name = "lbl1503";
            this.lbl1503.Size = new System.Drawing.Size(30, 30);
            this.lbl1503.TabIndex = 1095;
            this.lbl1503.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1502
            // 
            this.lbl1502.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1502.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1502.ForeColor = System.Drawing.Color.White;
            this.lbl1502.Location = new System.Drawing.Point(189, 546);
            this.lbl1502.Multiline = true;
            this.lbl1502.Name = "lbl1502";
            this.lbl1502.Size = new System.Drawing.Size(30, 30);
            this.lbl1502.TabIndex = 1094;
            this.lbl1502.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1501
            // 
            this.lbl1501.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1501.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1501.ForeColor = System.Drawing.Color.White;
            this.lbl1501.Location = new System.Drawing.Point(153, 546);
            this.lbl1501.Multiline = true;
            this.lbl1501.Name = "lbl1501";
            this.lbl1501.Size = new System.Drawing.Size(30, 30);
            this.lbl1501.TabIndex = 1093;
            this.lbl1501.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1412
            // 
            this.lbl1412.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1412.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1412.ForeColor = System.Drawing.Color.White;
            this.lbl1412.Location = new System.Drawing.Point(549, 510);
            this.lbl1412.Multiline = true;
            this.lbl1412.Name = "lbl1412";
            this.lbl1412.Size = new System.Drawing.Size(30, 30);
            this.lbl1412.TabIndex = 1092;
            this.lbl1412.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1312
            // 
            this.lbl1312.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1312.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1312.ForeColor = System.Drawing.Color.White;
            this.lbl1312.Location = new System.Drawing.Point(549, 474);
            this.lbl1312.Multiline = true;
            this.lbl1312.Name = "lbl1312";
            this.lbl1312.Size = new System.Drawing.Size(30, 30);
            this.lbl1312.TabIndex = 1091;
            this.lbl1312.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1411
            // 
            this.lbl1411.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1411.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1411.ForeColor = System.Drawing.Color.White;
            this.lbl1411.Location = new System.Drawing.Point(513, 510);
            this.lbl1411.Multiline = true;
            this.lbl1411.Name = "lbl1411";
            this.lbl1411.Size = new System.Drawing.Size(30, 30);
            this.lbl1411.TabIndex = 1090;
            this.lbl1411.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1311
            // 
            this.lbl1311.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1311.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1311.ForeColor = System.Drawing.Color.White;
            this.lbl1311.Location = new System.Drawing.Point(513, 474);
            this.lbl1311.Multiline = true;
            this.lbl1311.Name = "lbl1311";
            this.lbl1311.Size = new System.Drawing.Size(30, 30);
            this.lbl1311.TabIndex = 1089;
            this.lbl1311.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1410
            // 
            this.lbl1410.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1410.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1410.ForeColor = System.Drawing.Color.White;
            this.lbl1410.Location = new System.Drawing.Point(477, 510);
            this.lbl1410.Multiline = true;
            this.lbl1410.Name = "lbl1410";
            this.lbl1410.Size = new System.Drawing.Size(30, 30);
            this.lbl1410.TabIndex = 1088;
            this.lbl1410.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1409
            // 
            this.lbl1409.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1409.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1409.ForeColor = System.Drawing.Color.White;
            this.lbl1409.Location = new System.Drawing.Point(441, 510);
            this.lbl1409.Multiline = true;
            this.lbl1409.Name = "lbl1409";
            this.lbl1409.Size = new System.Drawing.Size(30, 30);
            this.lbl1409.TabIndex = 1087;
            this.lbl1409.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1408
            // 
            this.lbl1408.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1408.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1408.ForeColor = System.Drawing.Color.White;
            this.lbl1408.Location = new System.Drawing.Point(405, 510);
            this.lbl1408.Multiline = true;
            this.lbl1408.Name = "lbl1408";
            this.lbl1408.Size = new System.Drawing.Size(30, 30);
            this.lbl1408.TabIndex = 1086;
            this.lbl1408.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1407
            // 
            this.lbl1407.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1407.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1407.ForeColor = System.Drawing.Color.White;
            this.lbl1407.Location = new System.Drawing.Point(369, 510);
            this.lbl1407.Multiline = true;
            this.lbl1407.Name = "lbl1407";
            this.lbl1407.Size = new System.Drawing.Size(30, 30);
            this.lbl1407.TabIndex = 1085;
            this.lbl1407.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1406
            // 
            this.lbl1406.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1406.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1406.ForeColor = System.Drawing.Color.White;
            this.lbl1406.Location = new System.Drawing.Point(333, 510);
            this.lbl1406.Multiline = true;
            this.lbl1406.Name = "lbl1406";
            this.lbl1406.Size = new System.Drawing.Size(30, 30);
            this.lbl1406.TabIndex = 1084;
            this.lbl1406.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1405
            // 
            this.lbl1405.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1405.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1405.ForeColor = System.Drawing.Color.White;
            this.lbl1405.Location = new System.Drawing.Point(297, 510);
            this.lbl1405.Multiline = true;
            this.lbl1405.Name = "lbl1405";
            this.lbl1405.Size = new System.Drawing.Size(30, 30);
            this.lbl1405.TabIndex = 1083;
            this.lbl1405.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1404
            // 
            this.lbl1404.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1404.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1404.ForeColor = System.Drawing.Color.White;
            this.lbl1404.Location = new System.Drawing.Point(261, 510);
            this.lbl1404.Multiline = true;
            this.lbl1404.Name = "lbl1404";
            this.lbl1404.Size = new System.Drawing.Size(30, 30);
            this.lbl1404.TabIndex = 1082;
            this.lbl1404.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1403
            // 
            this.lbl1403.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1403.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1403.ForeColor = System.Drawing.Color.White;
            this.lbl1403.Location = new System.Drawing.Point(225, 510);
            this.lbl1403.Multiline = true;
            this.lbl1403.Name = "lbl1403";
            this.lbl1403.Size = new System.Drawing.Size(30, 30);
            this.lbl1403.TabIndex = 1081;
            this.lbl1403.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1402
            // 
            this.lbl1402.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1402.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1402.ForeColor = System.Drawing.Color.White;
            this.lbl1402.Location = new System.Drawing.Point(189, 510);
            this.lbl1402.Multiline = true;
            this.lbl1402.Name = "lbl1402";
            this.lbl1402.Size = new System.Drawing.Size(30, 30);
            this.lbl1402.TabIndex = 1080;
            this.lbl1402.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1401
            // 
            this.lbl1401.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1401.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1401.ForeColor = System.Drawing.Color.White;
            this.lbl1401.Location = new System.Drawing.Point(153, 510);
            this.lbl1401.Multiline = true;
            this.lbl1401.Name = "lbl1401";
            this.lbl1401.Size = new System.Drawing.Size(30, 30);
            this.lbl1401.TabIndex = 1079;
            this.lbl1401.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1310
            // 
            this.lbl1310.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1310.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1310.ForeColor = System.Drawing.Color.White;
            this.lbl1310.Location = new System.Drawing.Point(477, 474);
            this.lbl1310.Multiline = true;
            this.lbl1310.Name = "lbl1310";
            this.lbl1310.Size = new System.Drawing.Size(30, 30);
            this.lbl1310.TabIndex = 1078;
            this.lbl1310.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1309
            // 
            this.lbl1309.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1309.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1309.ForeColor = System.Drawing.Color.White;
            this.lbl1309.Location = new System.Drawing.Point(441, 474);
            this.lbl1309.Multiline = true;
            this.lbl1309.Name = "lbl1309";
            this.lbl1309.Size = new System.Drawing.Size(30, 30);
            this.lbl1309.TabIndex = 1077;
            this.lbl1309.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1308
            // 
            this.lbl1308.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1308.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1308.ForeColor = System.Drawing.Color.White;
            this.lbl1308.Location = new System.Drawing.Point(405, 474);
            this.lbl1308.Multiline = true;
            this.lbl1308.Name = "lbl1308";
            this.lbl1308.Size = new System.Drawing.Size(30, 30);
            this.lbl1308.TabIndex = 1076;
            this.lbl1308.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1307
            // 
            this.lbl1307.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1307.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1307.ForeColor = System.Drawing.Color.White;
            this.lbl1307.Location = new System.Drawing.Point(369, 474);
            this.lbl1307.Multiline = true;
            this.lbl1307.Name = "lbl1307";
            this.lbl1307.Size = new System.Drawing.Size(30, 30);
            this.lbl1307.TabIndex = 1075;
            this.lbl1307.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1306
            // 
            this.lbl1306.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1306.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1306.ForeColor = System.Drawing.Color.White;
            this.lbl1306.Location = new System.Drawing.Point(333, 474);
            this.lbl1306.Multiline = true;
            this.lbl1306.Name = "lbl1306";
            this.lbl1306.Size = new System.Drawing.Size(30, 30);
            this.lbl1306.TabIndex = 1074;
            this.lbl1306.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1305
            // 
            this.lbl1305.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1305.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1305.ForeColor = System.Drawing.Color.White;
            this.lbl1305.Location = new System.Drawing.Point(297, 474);
            this.lbl1305.Multiline = true;
            this.lbl1305.Name = "lbl1305";
            this.lbl1305.Size = new System.Drawing.Size(30, 30);
            this.lbl1305.TabIndex = 1073;
            this.lbl1305.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1304
            // 
            this.lbl1304.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1304.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1304.ForeColor = System.Drawing.Color.White;
            this.lbl1304.Location = new System.Drawing.Point(261, 474);
            this.lbl1304.Multiline = true;
            this.lbl1304.Name = "lbl1304";
            this.lbl1304.Size = new System.Drawing.Size(30, 30);
            this.lbl1304.TabIndex = 1072;
            this.lbl1304.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1303
            // 
            this.lbl1303.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1303.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1303.ForeColor = System.Drawing.Color.White;
            this.lbl1303.Location = new System.Drawing.Point(225, 474);
            this.lbl1303.Multiline = true;
            this.lbl1303.Name = "lbl1303";
            this.lbl1303.Size = new System.Drawing.Size(30, 30);
            this.lbl1303.TabIndex = 1071;
            this.lbl1303.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1302
            // 
            this.lbl1302.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1302.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1302.ForeColor = System.Drawing.Color.White;
            this.lbl1302.Location = new System.Drawing.Point(189, 474);
            this.lbl1302.Multiline = true;
            this.lbl1302.Name = "lbl1302";
            this.lbl1302.Size = new System.Drawing.Size(30, 30);
            this.lbl1302.TabIndex = 1070;
            this.lbl1302.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1301
            // 
            this.lbl1301.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1301.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1301.ForeColor = System.Drawing.Color.White;
            this.lbl1301.Location = new System.Drawing.Point(153, 474);
            this.lbl1301.Multiline = true;
            this.lbl1301.Name = "lbl1301";
            this.lbl1301.Size = new System.Drawing.Size(30, 30);
            this.lbl1301.TabIndex = 1069;
            this.lbl1301.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1616
            // 
            this.lbl1616.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1616.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1616.ForeColor = System.Drawing.Color.White;
            this.lbl1616.Location = new System.Drawing.Point(693, 582);
            this.lbl1616.Multiline = true;
            this.lbl1616.Name = "lbl1616";
            this.lbl1616.Size = new System.Drawing.Size(30, 30);
            this.lbl1616.TabIndex = 1132;
            this.lbl1616.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1615
            // 
            this.lbl1615.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1615.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1615.ForeColor = System.Drawing.Color.White;
            this.lbl1615.Location = new System.Drawing.Point(657, 582);
            this.lbl1615.Multiline = true;
            this.lbl1615.Name = "lbl1615";
            this.lbl1615.Size = new System.Drawing.Size(30, 30);
            this.lbl1615.TabIndex = 1131;
            this.lbl1615.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1614
            // 
            this.lbl1614.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1614.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1614.ForeColor = System.Drawing.Color.White;
            this.lbl1614.Location = new System.Drawing.Point(621, 582);
            this.lbl1614.Multiline = true;
            this.lbl1614.Name = "lbl1614";
            this.lbl1614.Size = new System.Drawing.Size(30, 30);
            this.lbl1614.TabIndex = 1130;
            this.lbl1614.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1613
            // 
            this.lbl1613.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lbl1613.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1613.ForeColor = System.Drawing.Color.White;
            this.lbl1613.Location = new System.Drawing.Point(585, 582);
            this.lbl1613.Multiline = true;
            this.lbl1613.Name = "lbl1613";
            this.lbl1613.Size = new System.Drawing.Size(30, 30);
            this.lbl1613.TabIndex = 1129;
            this.lbl1613.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1612
            // 
            this.lbl1612.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1612.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1612.ForeColor = System.Drawing.Color.White;
            this.lbl1612.Location = new System.Drawing.Point(549, 582);
            this.lbl1612.Multiline = true;
            this.lbl1612.Name = "lbl1612";
            this.lbl1612.Size = new System.Drawing.Size(30, 30);
            this.lbl1612.TabIndex = 1128;
            this.lbl1612.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1611
            // 
            this.lbl1611.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1611.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1611.ForeColor = System.Drawing.Color.White;
            this.lbl1611.Location = new System.Drawing.Point(513, 582);
            this.lbl1611.Multiline = true;
            this.lbl1611.Name = "lbl1611";
            this.lbl1611.Size = new System.Drawing.Size(30, 30);
            this.lbl1611.TabIndex = 1127;
            this.lbl1611.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1610
            // 
            this.lbl1610.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1610.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1610.ForeColor = System.Drawing.Color.White;
            this.lbl1610.Location = new System.Drawing.Point(477, 582);
            this.lbl1610.Multiline = true;
            this.lbl1610.Name = "lbl1610";
            this.lbl1610.Size = new System.Drawing.Size(30, 30);
            this.lbl1610.TabIndex = 1126;
            this.lbl1610.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1609
            // 
            this.lbl1609.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbl1609.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1609.ForeColor = System.Drawing.Color.White;
            this.lbl1609.Location = new System.Drawing.Point(441, 582);
            this.lbl1609.Multiline = true;
            this.lbl1609.Name = "lbl1609";
            this.lbl1609.Size = new System.Drawing.Size(30, 30);
            this.lbl1609.TabIndex = 1125;
            this.lbl1609.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1608
            // 
            this.lbl1608.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1608.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1608.ForeColor = System.Drawing.Color.White;
            this.lbl1608.Location = new System.Drawing.Point(405, 582);
            this.lbl1608.Multiline = true;
            this.lbl1608.Name = "lbl1608";
            this.lbl1608.Size = new System.Drawing.Size(30, 30);
            this.lbl1608.TabIndex = 1124;
            this.lbl1608.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1607
            // 
            this.lbl1607.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1607.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1607.ForeColor = System.Drawing.Color.White;
            this.lbl1607.Location = new System.Drawing.Point(369, 582);
            this.lbl1607.Multiline = true;
            this.lbl1607.Name = "lbl1607";
            this.lbl1607.Size = new System.Drawing.Size(30, 30);
            this.lbl1607.TabIndex = 1123;
            this.lbl1607.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1606
            // 
            this.lbl1606.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1606.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1606.ForeColor = System.Drawing.Color.White;
            this.lbl1606.Location = new System.Drawing.Point(333, 582);
            this.lbl1606.Multiline = true;
            this.lbl1606.Name = "lbl1606";
            this.lbl1606.Size = new System.Drawing.Size(30, 30);
            this.lbl1606.TabIndex = 1122;
            this.lbl1606.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1605
            // 
            this.lbl1605.BackColor = System.Drawing.Color.SteelBlue;
            this.lbl1605.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1605.ForeColor = System.Drawing.Color.White;
            this.lbl1605.Location = new System.Drawing.Point(297, 582);
            this.lbl1605.Multiline = true;
            this.lbl1605.Name = "lbl1605";
            this.lbl1605.Size = new System.Drawing.Size(30, 30);
            this.lbl1605.TabIndex = 1121;
            this.lbl1605.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1604
            // 
            this.lbl1604.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1604.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1604.ForeColor = System.Drawing.Color.White;
            this.lbl1604.Location = new System.Drawing.Point(261, 582);
            this.lbl1604.Multiline = true;
            this.lbl1604.Name = "lbl1604";
            this.lbl1604.Size = new System.Drawing.Size(30, 30);
            this.lbl1604.TabIndex = 1120;
            this.lbl1604.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1603
            // 
            this.lbl1603.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1603.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1603.ForeColor = System.Drawing.Color.White;
            this.lbl1603.Location = new System.Drawing.Point(225, 582);
            this.lbl1603.Multiline = true;
            this.lbl1603.Name = "lbl1603";
            this.lbl1603.Size = new System.Drawing.Size(30, 30);
            this.lbl1603.TabIndex = 1119;
            this.lbl1603.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1602
            // 
            this.lbl1602.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1602.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1602.ForeColor = System.Drawing.Color.White;
            this.lbl1602.Location = new System.Drawing.Point(189, 582);
            this.lbl1602.Multiline = true;
            this.lbl1602.Name = "lbl1602";
            this.lbl1602.Size = new System.Drawing.Size(30, 30);
            this.lbl1602.TabIndex = 1118;
            this.lbl1602.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1601
            // 
            this.lbl1601.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1601.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1601.ForeColor = System.Drawing.Color.White;
            this.lbl1601.Location = new System.Drawing.Point(153, 582);
            this.lbl1601.Multiline = true;
            this.lbl1601.Name = "lbl1601";
            this.lbl1601.Size = new System.Drawing.Size(30, 30);
            this.lbl1601.TabIndex = 1117;
            this.lbl1601.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblClear
            // 
            this.lblClear.AutoSize = true;
            this.lblClear.BackColor = System.Drawing.Color.Transparent;
            this.lblClear.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClear.ForeColor = System.Drawing.Color.Crimson;
            this.lblClear.Location = new System.Drawing.Point(957, 74);
            this.lblClear.Name = "lblClear";
            this.lblClear.Size = new System.Drawing.Size(78, 28);
            this.lblClear.TabIndex = 1136;
            this.lblClear.Text = "Clear";
            this.lblClear.Click += new System.EventHandler(this.btnClear_Click);
            this.lblClear.MouseLeave += new System.EventHandler(this.lblClear_MouseLeave);
            this.lblClear.MouseHover += new System.EventHandler(this.lblClear_MouseHover);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.BackColor = System.Drawing.Color.Transparent;
            this.lblResult.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.ForeColor = System.Drawing.Color.Crimson;
            this.lblResult.Location = new System.Drawing.Point(851, 72);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(90, 28);
            this.lblResult.TabIndex = 1135;
            this.lblResult.Text = "Result";
            this.lblResult.Click += new System.EventHandler(this.btnGo_Click);
            this.lblResult.MouseLeave += new System.EventHandler(this.lblResult_MouseLeave);
            this.lblResult.MouseHover += new System.EventHandler(this.lblResult_MouseHover);
            // 
            // lblBack
            // 
            this.lblBack.AutoSize = true;
            this.lblBack.BackColor = System.Drawing.Color.Transparent;
            this.lblBack.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBack.ForeColor = System.Drawing.Color.Crimson;
            this.lblBack.Location = new System.Drawing.Point(753, 294);
            this.lblBack.Name = "lblBack";
            this.lblBack.Size = new System.Drawing.Size(148, 28);
            this.lblBack.TabIndex = 1133;
            this.lblBack.Text = "Back Menu";
            this.lblBack.Click += new System.EventHandler(this.btnBack_Click);
            this.lblBack.MouseLeave += new System.EventHandler(this.lblBack_MouseLeave);
            this.lblBack.MouseHover += new System.EventHandler(this.lblBack_MouseHover);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MintCream;
            this.label3.Location = new System.Drawing.Point(897, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 39);
            this.label3.TabIndex = 1138;
            this.label3.Text = "16x16";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(755, 324);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(267, 16);
            this.label4.TabIndex = 1139;
            this.label4.Text = "_____________________________________";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(737, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(302, 16);
            this.label2.TabIndex = 1140;
            this.label2.Text = "__________________________________________";
            // 
            // Check
            // 
            this.Check.AutoSize = true;
            this.Check.BackColor = System.Drawing.Color.Transparent;
            this.Check.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check.ForeColor = System.Drawing.Color.Crimson;
            this.Check.Location = new System.Drawing.Point(740, 72);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(86, 28);
            this.Check.TabIndex = 1141;
            this.Check.Text = "Check";
            this.Check.Click += new System.EventHandler(this.Check_Click);
            // 
            // N16
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowText;
            this.BackgroundImage = global::SudokuN.Properties.Resources.back2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1131, 635);
            this.Controls.Add(this.Check);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblClear);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblBack);
            this.Controls.Add(this.lbl1616);
            this.Controls.Add(this.lbl1615);
            this.Controls.Add(this.lbl1614);
            this.Controls.Add(this.lbl1613);
            this.Controls.Add(this.lbl1612);
            this.Controls.Add(this.lbl1611);
            this.Controls.Add(this.lbl1610);
            this.Controls.Add(this.lbl1609);
            this.Controls.Add(this.lbl1608);
            this.Controls.Add(this.lbl1607);
            this.Controls.Add(this.lbl1606);
            this.Controls.Add(this.lbl1605);
            this.Controls.Add(this.lbl1604);
            this.Controls.Add(this.lbl1603);
            this.Controls.Add(this.lbl1602);
            this.Controls.Add(this.lbl1601);
            this.Controls.Add(this.lbl1516);
            this.Controls.Add(this.lbl1515);
            this.Controls.Add(this.lbl1514);
            this.Controls.Add(this.lbl1513);
            this.Controls.Add(this.lbl1416);
            this.Controls.Add(this.lbl1316);
            this.Controls.Add(this.lbl1415);
            this.Controls.Add(this.lbl1315);
            this.Controls.Add(this.lbl1414);
            this.Controls.Add(this.lbl1413);
            this.Controls.Add(this.lbl1314);
            this.Controls.Add(this.lbl1313);
            this.Controls.Add(this.lbl1512);
            this.Controls.Add(this.lbl1511);
            this.Controls.Add(this.lbl1510);
            this.Controls.Add(this.lbl1509);
            this.Controls.Add(this.lbl1508);
            this.Controls.Add(this.lbl1507);
            this.Controls.Add(this.lbl1506);
            this.Controls.Add(this.lbl1505);
            this.Controls.Add(this.lbl1504);
            this.Controls.Add(this.lbl1503);
            this.Controls.Add(this.lbl1502);
            this.Controls.Add(this.lbl1501);
            this.Controls.Add(this.lbl1412);
            this.Controls.Add(this.lbl1312);
            this.Controls.Add(this.lbl1411);
            this.Controls.Add(this.lbl1311);
            this.Controls.Add(this.lbl1410);
            this.Controls.Add(this.lbl1409);
            this.Controls.Add(this.lbl1408);
            this.Controls.Add(this.lbl1407);
            this.Controls.Add(this.lbl1406);
            this.Controls.Add(this.lbl1405);
            this.Controls.Add(this.lbl1404);
            this.Controls.Add(this.lbl1403);
            this.Controls.Add(this.lbl1402);
            this.Controls.Add(this.lbl1401);
            this.Controls.Add(this.lbl1310);
            this.Controls.Add(this.lbl1309);
            this.Controls.Add(this.lbl1308);
            this.Controls.Add(this.lbl1307);
            this.Controls.Add(this.lbl1306);
            this.Controls.Add(this.lbl1305);
            this.Controls.Add(this.lbl1304);
            this.Controls.Add(this.lbl1303);
            this.Controls.Add(this.lbl1302);
            this.Controls.Add(this.lbl1301);
            this.Controls.Add(this.lbl1216);
            this.Controls.Add(this.lbl1215);
            this.Controls.Add(this.lbl1214);
            this.Controls.Add(this.lbl1213);
            this.Controls.Add(this.lbl1116);
            this.Controls.Add(this.lbl1016);
            this.Controls.Add(this.lbl0916);
            this.Controls.Add(this.lbl0816);
            this.Controls.Add(this.lbl0716);
            this.Controls.Add(this.lbl0616);
            this.Controls.Add(this.lbl0516);
            this.Controls.Add(this.lbl0416);
            this.Controls.Add(this.lbl0316);
            this.Controls.Add(this.lbl0216);
            this.Controls.Add(this.lbl0116);
            this.Controls.Add(this.lbl1115);
            this.Controls.Add(this.lbl1015);
            this.Controls.Add(this.lbl0915);
            this.Controls.Add(this.lbl0815);
            this.Controls.Add(this.lbl0715);
            this.Controls.Add(this.lbl0615);
            this.Controls.Add(this.lbl0515);
            this.Controls.Add(this.lbl0415);
            this.Controls.Add(this.lbl0315);
            this.Controls.Add(this.lbl0215);
            this.Controls.Add(this.lbl0115);
            this.Controls.Add(this.lbl1114);
            this.Controls.Add(this.lbl1113);
            this.Controls.Add(this.lbl1014);
            this.Controls.Add(this.lbl1013);
            this.Controls.Add(this.lbl0914);
            this.Controls.Add(this.lbl0913);
            this.Controls.Add(this.lbl0814);
            this.Controls.Add(this.lbl0714);
            this.Controls.Add(this.lbl0614);
            this.Controls.Add(this.lbl0514);
            this.Controls.Add(this.lbl0414);
            this.Controls.Add(this.lbl0314);
            this.Controls.Add(this.lbl0214);
            this.Controls.Add(this.lbl0114);
            this.Controls.Add(this.lbl0813);
            this.Controls.Add(this.lbl0713);
            this.Controls.Add(this.lbl0613);
            this.Controls.Add(this.lbl0513);
            this.Controls.Add(this.lbl0413);
            this.Controls.Add(this.lbl0313);
            this.Controls.Add(this.lbl0213);
            this.Controls.Add(this.lbl0113);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl1212);
            this.Controls.Add(this.lbl1211);
            this.Controls.Add(this.lbl1210);
            this.Controls.Add(this.lbl1209);
            this.Controls.Add(this.lbl1208);
            this.Controls.Add(this.lbl1207);
            this.Controls.Add(this.lbl1206);
            this.Controls.Add(this.lbl1205);
            this.Controls.Add(this.lbl1204);
            this.Controls.Add(this.lbl1203);
            this.Controls.Add(this.lbl1202);
            this.Controls.Add(this.lbl1201);
            this.Controls.Add(this.lbl1112);
            this.Controls.Add(this.lbl1012);
            this.Controls.Add(this.lbl0912);
            this.Controls.Add(this.lbl0812);
            this.Controls.Add(this.lbl0712);
            this.Controls.Add(this.lbl0612);
            this.Controls.Add(this.lbl0512);
            this.Controls.Add(this.lbl0412);
            this.Controls.Add(this.lbl0312);
            this.Controls.Add(this.lbl0212);
            this.Controls.Add(this.lbl0112);
            this.Controls.Add(this.lbl1111);
            this.Controls.Add(this.lbl1011);
            this.Controls.Add(this.lbl0911);
            this.Controls.Add(this.lbl0811);
            this.Controls.Add(this.lbl0711);
            this.Controls.Add(this.lbl0611);
            this.Controls.Add(this.lbl0511);
            this.Controls.Add(this.lbl0411);
            this.Controls.Add(this.lbl0311);
            this.Controls.Add(this.lbl0211);
            this.Controls.Add(this.lbl0111);
            this.Controls.Add(this.lbl1110);
            this.Controls.Add(this.lbl1109);
            this.Controls.Add(this.lbl1108);
            this.Controls.Add(this.lbl1107);
            this.Controls.Add(this.lbl1106);
            this.Controls.Add(this.lbl1105);
            this.Controls.Add(this.lbl1104);
            this.Controls.Add(this.lbl1103);
            this.Controls.Add(this.lbl1102);
            this.Controls.Add(this.lbl1101);
            this.Controls.Add(this.lbl1010);
            this.Controls.Add(this.lbl1009);
            this.Controls.Add(this.lbl1008);
            this.Controls.Add(this.lbl1007);
            this.Controls.Add(this.lbl1006);
            this.Controls.Add(this.lbl1005);
            this.Controls.Add(this.lbl1004);
            this.Controls.Add(this.lbl1003);
            this.Controls.Add(this.lbl1002);
            this.Controls.Add(this.lbl1001);
            this.Controls.Add(this.lbl0910);
            this.Controls.Add(this.lbl0909);
            this.Controls.Add(this.lbl0908);
            this.Controls.Add(this.lbl0907);
            this.Controls.Add(this.lbl0906);
            this.Controls.Add(this.lbl0905);
            this.Controls.Add(this.lbl0904);
            this.Controls.Add(this.lbl0903);
            this.Controls.Add(this.lbl0902);
            this.Controls.Add(this.lbl0901);
            this.Controls.Add(this.lbl0810);
            this.Controls.Add(this.lbl0710);
            this.Controls.Add(this.lbl0610);
            this.Controls.Add(this.lbl0510);
            this.Controls.Add(this.lbl0410);
            this.Controls.Add(this.lbl0310);
            this.Controls.Add(this.lbl0210);
            this.Controls.Add(this.lbl0110);
            this.Controls.Add(this.lbl0809);
            this.Controls.Add(this.lbl0709);
            this.Controls.Add(this.lbl0609);
            this.Controls.Add(this.lbl0509);
            this.Controls.Add(this.lbl0409);
            this.Controls.Add(this.lbl0309);
            this.Controls.Add(this.lbl0209);
            this.Controls.Add(this.lbl0109);
            this.Controls.Add(this.lbl0808);
            this.Controls.Add(this.lbl0807);
            this.Controls.Add(this.lbl0806);
            this.Controls.Add(this.lbl0805);
            this.Controls.Add(this.lbl0708);
            this.Controls.Add(this.lbl0707);
            this.Controls.Add(this.lbl0706);
            this.Controls.Add(this.lbl0705);
            this.Controls.Add(this.lbl0804);
            this.Controls.Add(this.lbl0803);
            this.Controls.Add(this.lbl0802);
            this.Controls.Add(this.lbl0801);
            this.Controls.Add(this.lbl0704);
            this.Controls.Add(this.lbl0703);
            this.Controls.Add(this.lbl0702);
            this.Controls.Add(this.lbl0701);
            this.Controls.Add(this.lbl0608);
            this.Controls.Add(this.lbl0607);
            this.Controls.Add(this.lbl0606);
            this.Controls.Add(this.lbl0605);
            this.Controls.Add(this.lbl0508);
            this.Controls.Add(this.lbl0507);
            this.Controls.Add(this.lbl0506);
            this.Controls.Add(this.lbl0505);
            this.Controls.Add(this.lbl0408);
            this.Controls.Add(this.lbl0407);
            this.Controls.Add(this.lbl0406);
            this.Controls.Add(this.lbl0405);
            this.Controls.Add(this.lbl0308);
            this.Controls.Add(this.lbl0307);
            this.Controls.Add(this.lbl0306);
            this.Controls.Add(this.lbl0305);
            this.Controls.Add(this.lbl0208);
            this.Controls.Add(this.lbl0207);
            this.Controls.Add(this.lbl0206);
            this.Controls.Add(this.lbl0205);
            this.Controls.Add(this.lbl0108);
            this.Controls.Add(this.lbl0107);
            this.Controls.Add(this.lbl0106);
            this.Controls.Add(this.lbl0105);
            this.Controls.Add(this.lbl0604);
            this.Controls.Add(this.lbl0603);
            this.Controls.Add(this.lbl0602);
            this.Controls.Add(this.lbl0601);
            this.Controls.Add(this.lbl0504);
            this.Controls.Add(this.lbl0503);
            this.Controls.Add(this.lbl0502);
            this.Controls.Add(this.lbl0501);
            this.Controls.Add(this.lbl0404);
            this.Controls.Add(this.lbl0403);
            this.Controls.Add(this.lbl0402);
            this.Controls.Add(this.lbl0401);
            this.Controls.Add(this.lbl0304);
            this.Controls.Add(this.lbl0303);
            this.Controls.Add(this.lbl0302);
            this.Controls.Add(this.lbl0301);
            this.Controls.Add(this.lbl0204);
            this.Controls.Add(this.lbl0203);
            this.Controls.Add(this.lbl0202);
            this.Controls.Add(this.lbl0201);
            this.Controls.Add(this.lbl0104);
            this.Controls.Add(this.lbl0103);
            this.Controls.Add(this.lbl0102);
            this.Controls.Add(this.lbl0101);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximumSize = new System.Drawing.Size(1147, 674);
            this.MinimumSize = new System.Drawing.Size(1147, 674);
            this.Name = "N16";
            this.Text = "N16";
            this.Load += new System.EventHandler(this.N16_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lbl1212;
        private System.Windows.Forms.TextBox lbl1211;
        private System.Windows.Forms.TextBox lbl1210;
        private System.Windows.Forms.TextBox lbl1209;
        private System.Windows.Forms.TextBox lbl1208;
        private System.Windows.Forms.TextBox lbl1207;
        private System.Windows.Forms.TextBox lbl1206;
        private System.Windows.Forms.TextBox lbl1205;
        private System.Windows.Forms.TextBox lbl1204;
        private System.Windows.Forms.TextBox lbl1203;
        private System.Windows.Forms.TextBox lbl1202;
        private System.Windows.Forms.TextBox lbl1201;
        private System.Windows.Forms.TextBox lbl1112;
        private System.Windows.Forms.TextBox lbl1012;
        private System.Windows.Forms.TextBox lbl0912;
        private System.Windows.Forms.TextBox lbl0812;
        private System.Windows.Forms.TextBox lbl0712;
        private System.Windows.Forms.TextBox lbl0612;
        private System.Windows.Forms.TextBox lbl0512;
        private System.Windows.Forms.TextBox lbl0412;
        private System.Windows.Forms.TextBox lbl0312;
        private System.Windows.Forms.TextBox lbl0212;
        private System.Windows.Forms.TextBox lbl0112;
        private System.Windows.Forms.TextBox lbl1111;
        private System.Windows.Forms.TextBox lbl1011;
        private System.Windows.Forms.TextBox lbl0911;
        private System.Windows.Forms.TextBox lbl0811;
        private System.Windows.Forms.TextBox lbl0711;
        private System.Windows.Forms.TextBox lbl0611;
        private System.Windows.Forms.TextBox lbl0511;
        private System.Windows.Forms.TextBox lbl0411;
        private System.Windows.Forms.TextBox lbl0311;
        private System.Windows.Forms.TextBox lbl0211;
        private System.Windows.Forms.TextBox lbl0111;
        private System.Windows.Forms.TextBox lbl1110;
        private System.Windows.Forms.TextBox lbl1109;
        private System.Windows.Forms.TextBox lbl1108;
        private System.Windows.Forms.TextBox lbl1107;
        private System.Windows.Forms.TextBox lbl1106;
        private System.Windows.Forms.TextBox lbl1105;
        private System.Windows.Forms.TextBox lbl1104;
        private System.Windows.Forms.TextBox lbl1103;
        private System.Windows.Forms.TextBox lbl1102;
        private System.Windows.Forms.TextBox lbl1101;
        private System.Windows.Forms.TextBox lbl1010;
        private System.Windows.Forms.TextBox lbl1009;
        private System.Windows.Forms.TextBox lbl1008;
        private System.Windows.Forms.TextBox lbl1007;
        private System.Windows.Forms.TextBox lbl1006;
        private System.Windows.Forms.TextBox lbl1005;
        private System.Windows.Forms.TextBox lbl1004;
        private System.Windows.Forms.TextBox lbl1003;
        private System.Windows.Forms.TextBox lbl1002;
        private System.Windows.Forms.TextBox lbl1001;
        private System.Windows.Forms.TextBox lbl0910;
        private System.Windows.Forms.TextBox lbl0909;
        private System.Windows.Forms.TextBox lbl0908;
        private System.Windows.Forms.TextBox lbl0907;
        private System.Windows.Forms.TextBox lbl0906;
        private System.Windows.Forms.TextBox lbl0905;
        private System.Windows.Forms.TextBox lbl0904;
        private System.Windows.Forms.TextBox lbl0903;
        private System.Windows.Forms.TextBox lbl0902;
        private System.Windows.Forms.TextBox lbl0901;
        private System.Windows.Forms.TextBox lbl0810;
        private System.Windows.Forms.TextBox lbl0710;
        private System.Windows.Forms.TextBox lbl0610;
        private System.Windows.Forms.TextBox lbl0510;
        private System.Windows.Forms.TextBox lbl0410;
        private System.Windows.Forms.TextBox lbl0310;
        private System.Windows.Forms.TextBox lbl0210;
        private System.Windows.Forms.TextBox lbl0110;
        private System.Windows.Forms.TextBox lbl0809;
        private System.Windows.Forms.TextBox lbl0709;
        private System.Windows.Forms.TextBox lbl0609;
        private System.Windows.Forms.TextBox lbl0509;
        private System.Windows.Forms.TextBox lbl0409;
        private System.Windows.Forms.TextBox lbl0309;
        private System.Windows.Forms.TextBox lbl0209;
        private System.Windows.Forms.TextBox lbl0109;
        private System.Windows.Forms.TextBox lbl0808;
        private System.Windows.Forms.TextBox lbl0807;
        private System.Windows.Forms.TextBox lbl0806;
        private System.Windows.Forms.TextBox lbl0805;
        private System.Windows.Forms.TextBox lbl0708;
        private System.Windows.Forms.TextBox lbl0707;
        private System.Windows.Forms.TextBox lbl0706;
        private System.Windows.Forms.TextBox lbl0705;
        private System.Windows.Forms.TextBox lbl0804;
        private System.Windows.Forms.TextBox lbl0803;
        private System.Windows.Forms.TextBox lbl0802;
        private System.Windows.Forms.TextBox lbl0801;
        private System.Windows.Forms.TextBox lbl0704;
        private System.Windows.Forms.TextBox lbl0703;
        private System.Windows.Forms.TextBox lbl0702;
        private System.Windows.Forms.TextBox lbl0701;
        private System.Windows.Forms.TextBox lbl0608;
        private System.Windows.Forms.TextBox lbl0607;
        private System.Windows.Forms.TextBox lbl0606;
        private System.Windows.Forms.TextBox lbl0605;
        private System.Windows.Forms.TextBox lbl0508;
        private System.Windows.Forms.TextBox lbl0507;
        private System.Windows.Forms.TextBox lbl0506;
        private System.Windows.Forms.TextBox lbl0505;
        private System.Windows.Forms.TextBox lbl0408;
        private System.Windows.Forms.TextBox lbl0407;
        private System.Windows.Forms.TextBox lbl0406;
        private System.Windows.Forms.TextBox lbl0405;
        private System.Windows.Forms.TextBox lbl0308;
        private System.Windows.Forms.TextBox lbl0307;
        private System.Windows.Forms.TextBox lbl0306;
        private System.Windows.Forms.TextBox lbl0305;
        private System.Windows.Forms.TextBox lbl0208;
        private System.Windows.Forms.TextBox lbl0207;
        private System.Windows.Forms.TextBox lbl0206;
        private System.Windows.Forms.TextBox lbl0205;
        private System.Windows.Forms.TextBox lbl0108;
        private System.Windows.Forms.TextBox lbl0107;
        private System.Windows.Forms.TextBox lbl0106;
        private System.Windows.Forms.TextBox lbl0105;
        private System.Windows.Forms.TextBox lbl0604;
        private System.Windows.Forms.TextBox lbl0603;
        private System.Windows.Forms.TextBox lbl0602;
        private System.Windows.Forms.TextBox lbl0601;
        private System.Windows.Forms.TextBox lbl0504;
        private System.Windows.Forms.TextBox lbl0503;
        private System.Windows.Forms.TextBox lbl0502;
        private System.Windows.Forms.TextBox lbl0501;
        private System.Windows.Forms.TextBox lbl0404;
        private System.Windows.Forms.TextBox lbl0403;
        private System.Windows.Forms.TextBox lbl0402;
        private System.Windows.Forms.TextBox lbl0401;
        private System.Windows.Forms.TextBox lbl0304;
        private System.Windows.Forms.TextBox lbl0303;
        private System.Windows.Forms.TextBox lbl0302;
        private System.Windows.Forms.TextBox lbl0301;
        private System.Windows.Forms.TextBox lbl0204;
        private System.Windows.Forms.TextBox lbl0203;
        private System.Windows.Forms.TextBox lbl0202;
        private System.Windows.Forms.TextBox lbl0201;
        private System.Windows.Forms.TextBox lbl0104;
        private System.Windows.Forms.TextBox lbl0103;
        private System.Windows.Forms.TextBox lbl0102;
        private System.Windows.Forms.TextBox lbl0101;
        private System.Windows.Forms.TextBox lbl1216;
        private System.Windows.Forms.TextBox lbl1215;
        private System.Windows.Forms.TextBox lbl1214;
        private System.Windows.Forms.TextBox lbl1213;
        private System.Windows.Forms.TextBox lbl1116;
        private System.Windows.Forms.TextBox lbl1016;
        private System.Windows.Forms.TextBox lbl0916;
        private System.Windows.Forms.TextBox lbl0816;
        private System.Windows.Forms.TextBox lbl0716;
        private System.Windows.Forms.TextBox lbl0616;
        private System.Windows.Forms.TextBox lbl0516;
        private System.Windows.Forms.TextBox lbl0416;
        private System.Windows.Forms.TextBox lbl0316;
        private System.Windows.Forms.TextBox lbl0216;
        private System.Windows.Forms.TextBox lbl0116;
        private System.Windows.Forms.TextBox lbl1115;
        private System.Windows.Forms.TextBox lbl1015;
        private System.Windows.Forms.TextBox lbl0915;
        private System.Windows.Forms.TextBox lbl0815;
        private System.Windows.Forms.TextBox lbl0715;
        private System.Windows.Forms.TextBox lbl0615;
        private System.Windows.Forms.TextBox lbl0515;
        private System.Windows.Forms.TextBox lbl0415;
        private System.Windows.Forms.TextBox lbl0315;
        private System.Windows.Forms.TextBox lbl0215;
        private System.Windows.Forms.TextBox lbl0115;
        private System.Windows.Forms.TextBox lbl1114;
        private System.Windows.Forms.TextBox lbl1113;
        private System.Windows.Forms.TextBox lbl1014;
        private System.Windows.Forms.TextBox lbl1013;
        private System.Windows.Forms.TextBox lbl0914;
        private System.Windows.Forms.TextBox lbl0913;
        private System.Windows.Forms.TextBox lbl0814;
        private System.Windows.Forms.TextBox lbl0714;
        private System.Windows.Forms.TextBox lbl0614;
        private System.Windows.Forms.TextBox lbl0514;
        private System.Windows.Forms.TextBox lbl0414;
        private System.Windows.Forms.TextBox lbl0314;
        private System.Windows.Forms.TextBox lbl0214;
        private System.Windows.Forms.TextBox lbl0114;
        private System.Windows.Forms.TextBox lbl0813;
        private System.Windows.Forms.TextBox lbl0713;
        private System.Windows.Forms.TextBox lbl0613;
        private System.Windows.Forms.TextBox lbl0513;
        private System.Windows.Forms.TextBox lbl0413;
        private System.Windows.Forms.TextBox lbl0313;
        private System.Windows.Forms.TextBox lbl0213;
        private System.Windows.Forms.TextBox lbl0113;
        private System.Windows.Forms.TextBox lbl1516;
        private System.Windows.Forms.TextBox lbl1515;
        private System.Windows.Forms.TextBox lbl1514;
        private System.Windows.Forms.TextBox lbl1513;
        private System.Windows.Forms.TextBox lbl1416;
        private System.Windows.Forms.TextBox lbl1316;
        private System.Windows.Forms.TextBox lbl1415;
        private System.Windows.Forms.TextBox lbl1315;
        private System.Windows.Forms.TextBox lbl1414;
        private System.Windows.Forms.TextBox lbl1413;
        private System.Windows.Forms.TextBox lbl1314;
        private System.Windows.Forms.TextBox lbl1313;
        private System.Windows.Forms.TextBox lbl1512;
        private System.Windows.Forms.TextBox lbl1511;
        private System.Windows.Forms.TextBox lbl1510;
        private System.Windows.Forms.TextBox lbl1509;
        private System.Windows.Forms.TextBox lbl1508;
        private System.Windows.Forms.TextBox lbl1507;
        private System.Windows.Forms.TextBox lbl1506;
        private System.Windows.Forms.TextBox lbl1505;
        private System.Windows.Forms.TextBox lbl1504;
        private System.Windows.Forms.TextBox lbl1503;
        private System.Windows.Forms.TextBox lbl1502;
        private System.Windows.Forms.TextBox lbl1501;
        private System.Windows.Forms.TextBox lbl1412;
        private System.Windows.Forms.TextBox lbl1312;
        private System.Windows.Forms.TextBox lbl1411;
        private System.Windows.Forms.TextBox lbl1311;
        private System.Windows.Forms.TextBox lbl1410;
        private System.Windows.Forms.TextBox lbl1409;
        private System.Windows.Forms.TextBox lbl1408;
        private System.Windows.Forms.TextBox lbl1407;
        private System.Windows.Forms.TextBox lbl1406;
        private System.Windows.Forms.TextBox lbl1405;
        private System.Windows.Forms.TextBox lbl1404;
        private System.Windows.Forms.TextBox lbl1403;
        private System.Windows.Forms.TextBox lbl1402;
        private System.Windows.Forms.TextBox lbl1401;
        private System.Windows.Forms.TextBox lbl1310;
        private System.Windows.Forms.TextBox lbl1309;
        private System.Windows.Forms.TextBox lbl1308;
        private System.Windows.Forms.TextBox lbl1307;
        private System.Windows.Forms.TextBox lbl1306;
        private System.Windows.Forms.TextBox lbl1305;
        private System.Windows.Forms.TextBox lbl1304;
        private System.Windows.Forms.TextBox lbl1303;
        private System.Windows.Forms.TextBox lbl1302;
        private System.Windows.Forms.TextBox lbl1301;
        private System.Windows.Forms.TextBox lbl1616;
        private System.Windows.Forms.TextBox lbl1615;
        private System.Windows.Forms.TextBox lbl1614;
        private System.Windows.Forms.TextBox lbl1613;
        private System.Windows.Forms.TextBox lbl1612;
        private System.Windows.Forms.TextBox lbl1611;
        private System.Windows.Forms.TextBox lbl1610;
        private System.Windows.Forms.TextBox lbl1609;
        private System.Windows.Forms.TextBox lbl1608;
        private System.Windows.Forms.TextBox lbl1607;
        private System.Windows.Forms.TextBox lbl1606;
        private System.Windows.Forms.TextBox lbl1605;
        private System.Windows.Forms.TextBox lbl1604;
        private System.Windows.Forms.TextBox lbl1603;
        private System.Windows.Forms.TextBox lbl1602;
        private System.Windows.Forms.TextBox lbl1601;
        private System.Windows.Forms.Label lblClear;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblBack;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Check;
    }
}