﻿namespace SudokuN.View
{
    partial class N8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl88 = new System.Windows.Forms.TextBox();
            this.lbl87 = new System.Windows.Forms.TextBox();
            this.lbl86 = new System.Windows.Forms.TextBox();
            this.lbl85 = new System.Windows.Forms.TextBox();
            this.lbl78 = new System.Windows.Forms.TextBox();
            this.lbl77 = new System.Windows.Forms.TextBox();
            this.lbl76 = new System.Windows.Forms.TextBox();
            this.lbl75 = new System.Windows.Forms.TextBox();
            this.lbl84 = new System.Windows.Forms.TextBox();
            this.lbl83 = new System.Windows.Forms.TextBox();
            this.lbl82 = new System.Windows.Forms.TextBox();
            this.lbl81 = new System.Windows.Forms.TextBox();
            this.lbl74 = new System.Windows.Forms.TextBox();
            this.lbl73 = new System.Windows.Forms.TextBox();
            this.lbl72 = new System.Windows.Forms.TextBox();
            this.lbl71 = new System.Windows.Forms.TextBox();
            this.lbl68 = new System.Windows.Forms.TextBox();
            this.lbl67 = new System.Windows.Forms.TextBox();
            this.lbl66 = new System.Windows.Forms.TextBox();
            this.lbl65 = new System.Windows.Forms.TextBox();
            this.lbl58 = new System.Windows.Forms.TextBox();
            this.lbl57 = new System.Windows.Forms.TextBox();
            this.lbl56 = new System.Windows.Forms.TextBox();
            this.lbl55 = new System.Windows.Forms.TextBox();
            this.lbl48 = new System.Windows.Forms.TextBox();
            this.lbl47 = new System.Windows.Forms.TextBox();
            this.lbl46 = new System.Windows.Forms.TextBox();
            this.lbl45 = new System.Windows.Forms.TextBox();
            this.lbl38 = new System.Windows.Forms.TextBox();
            this.lbl37 = new System.Windows.Forms.TextBox();
            this.lbl36 = new System.Windows.Forms.TextBox();
            this.lbl35 = new System.Windows.Forms.TextBox();
            this.lbl28 = new System.Windows.Forms.TextBox();
            this.lbl27 = new System.Windows.Forms.TextBox();
            this.lbl26 = new System.Windows.Forms.TextBox();
            this.lbl25 = new System.Windows.Forms.TextBox();
            this.lbl18 = new System.Windows.Forms.TextBox();
            this.lbl17 = new System.Windows.Forms.TextBox();
            this.lbl16 = new System.Windows.Forms.TextBox();
            this.lbl15 = new System.Windows.Forms.TextBox();
            this.lbl64 = new System.Windows.Forms.TextBox();
            this.lbl63 = new System.Windows.Forms.TextBox();
            this.lbl62 = new System.Windows.Forms.TextBox();
            this.lbl61 = new System.Windows.Forms.TextBox();
            this.lbl54 = new System.Windows.Forms.TextBox();
            this.lbl53 = new System.Windows.Forms.TextBox();
            this.lbl52 = new System.Windows.Forms.TextBox();
            this.lbl51 = new System.Windows.Forms.TextBox();
            this.lbl44 = new System.Windows.Forms.TextBox();
            this.lbl43 = new System.Windows.Forms.TextBox();
            this.lbl42 = new System.Windows.Forms.TextBox();
            this.lbl41 = new System.Windows.Forms.TextBox();
            this.lbl34 = new System.Windows.Forms.TextBox();
            this.lbl33 = new System.Windows.Forms.TextBox();
            this.lbl32 = new System.Windows.Forms.TextBox();
            this.lbl31 = new System.Windows.Forms.TextBox();
            this.lbl24 = new System.Windows.Forms.TextBox();
            this.lbl23 = new System.Windows.Forms.TextBox();
            this.lbl22 = new System.Windows.Forms.TextBox();
            this.lbl21 = new System.Windows.Forms.TextBox();
            this.lbl14 = new System.Windows.Forms.TextBox();
            this.lbl13 = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.TextBox();
            this.lbl11 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblClear = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblBack = new System.Windows.Forms.Label();
            this.Check = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl88
            // 
            this.lbl88.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl88.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl88.ForeColor = System.Drawing.Color.White;
            this.lbl88.Location = new System.Drawing.Point(685, 369);
            this.lbl88.Multiline = true;
            this.lbl88.Name = "lbl88";
            this.lbl88.Size = new System.Drawing.Size(44, 40);
            this.lbl88.TabIndex = 326;
            this.lbl88.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl87
            // 
            this.lbl87.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl87.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl87.ForeColor = System.Drawing.Color.White;
            this.lbl87.Location = new System.Drawing.Point(635, 369);
            this.lbl87.Multiline = true;
            this.lbl87.Name = "lbl87";
            this.lbl87.Size = new System.Drawing.Size(44, 40);
            this.lbl87.TabIndex = 325;
            this.lbl87.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl86
            // 
            this.lbl86.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl86.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl86.ForeColor = System.Drawing.Color.White;
            this.lbl86.Location = new System.Drawing.Point(585, 369);
            this.lbl86.Multiline = true;
            this.lbl86.Name = "lbl86";
            this.lbl86.Size = new System.Drawing.Size(44, 40);
            this.lbl86.TabIndex = 324;
            this.lbl86.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl85
            // 
            this.lbl85.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl85.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl85.ForeColor = System.Drawing.Color.White;
            this.lbl85.Location = new System.Drawing.Point(535, 369);
            this.lbl85.Multiline = true;
            this.lbl85.Name = "lbl85";
            this.lbl85.Size = new System.Drawing.Size(44, 40);
            this.lbl85.TabIndex = 323;
            this.lbl85.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl78
            // 
            this.lbl78.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl78.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl78.ForeColor = System.Drawing.Color.White;
            this.lbl78.Location = new System.Drawing.Point(685, 323);
            this.lbl78.Multiline = true;
            this.lbl78.Name = "lbl78";
            this.lbl78.Size = new System.Drawing.Size(44, 40);
            this.lbl78.TabIndex = 322;
            this.lbl78.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl77
            // 
            this.lbl77.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl77.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl77.ForeColor = System.Drawing.Color.White;
            this.lbl77.Location = new System.Drawing.Point(635, 323);
            this.lbl77.Multiline = true;
            this.lbl77.Name = "lbl77";
            this.lbl77.Size = new System.Drawing.Size(44, 40);
            this.lbl77.TabIndex = 321;
            this.lbl77.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl76
            // 
            this.lbl76.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl76.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl76.ForeColor = System.Drawing.Color.White;
            this.lbl76.Location = new System.Drawing.Point(585, 323);
            this.lbl76.Multiline = true;
            this.lbl76.Name = "lbl76";
            this.lbl76.Size = new System.Drawing.Size(44, 40);
            this.lbl76.TabIndex = 320;
            this.lbl76.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl75
            // 
            this.lbl75.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl75.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl75.ForeColor = System.Drawing.Color.White;
            this.lbl75.Location = new System.Drawing.Point(535, 323);
            this.lbl75.Multiline = true;
            this.lbl75.Name = "lbl75";
            this.lbl75.Size = new System.Drawing.Size(44, 40);
            this.lbl75.TabIndex = 319;
            this.lbl75.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl84
            // 
            this.lbl84.BackColor = System.Drawing.Color.Tomato;
            this.lbl84.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl84.ForeColor = System.Drawing.Color.White;
            this.lbl84.Location = new System.Drawing.Point(485, 369);
            this.lbl84.Multiline = true;
            this.lbl84.Name = "lbl84";
            this.lbl84.Size = new System.Drawing.Size(44, 40);
            this.lbl84.TabIndex = 318;
            this.lbl84.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl83
            // 
            this.lbl83.BackColor = System.Drawing.Color.Tomato;
            this.lbl83.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl83.ForeColor = System.Drawing.Color.White;
            this.lbl83.Location = new System.Drawing.Point(435, 369);
            this.lbl83.Multiline = true;
            this.lbl83.Name = "lbl83";
            this.lbl83.Size = new System.Drawing.Size(44, 40);
            this.lbl83.TabIndex = 317;
            this.lbl83.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl82
            // 
            this.lbl82.BackColor = System.Drawing.Color.Tomato;
            this.lbl82.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl82.ForeColor = System.Drawing.Color.White;
            this.lbl82.Location = new System.Drawing.Point(385, 369);
            this.lbl82.Multiline = true;
            this.lbl82.Name = "lbl82";
            this.lbl82.Size = new System.Drawing.Size(44, 40);
            this.lbl82.TabIndex = 316;
            this.lbl82.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl81
            // 
            this.lbl81.BackColor = System.Drawing.Color.Tomato;
            this.lbl81.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl81.ForeColor = System.Drawing.Color.White;
            this.lbl81.Location = new System.Drawing.Point(335, 369);
            this.lbl81.Multiline = true;
            this.lbl81.Name = "lbl81";
            this.lbl81.Size = new System.Drawing.Size(44, 40);
            this.lbl81.TabIndex = 315;
            this.lbl81.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl74
            // 
            this.lbl74.BackColor = System.Drawing.Color.Tomato;
            this.lbl74.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl74.ForeColor = System.Drawing.Color.White;
            this.lbl74.Location = new System.Drawing.Point(485, 323);
            this.lbl74.Multiline = true;
            this.lbl74.Name = "lbl74";
            this.lbl74.Size = new System.Drawing.Size(44, 40);
            this.lbl74.TabIndex = 314;
            this.lbl74.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl73
            // 
            this.lbl73.BackColor = System.Drawing.Color.Tomato;
            this.lbl73.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl73.ForeColor = System.Drawing.Color.White;
            this.lbl73.Location = new System.Drawing.Point(435, 323);
            this.lbl73.Multiline = true;
            this.lbl73.Name = "lbl73";
            this.lbl73.Size = new System.Drawing.Size(44, 40);
            this.lbl73.TabIndex = 313;
            this.lbl73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl72
            // 
            this.lbl72.BackColor = System.Drawing.Color.Tomato;
            this.lbl72.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl72.ForeColor = System.Drawing.Color.White;
            this.lbl72.Location = new System.Drawing.Point(385, 323);
            this.lbl72.Multiline = true;
            this.lbl72.Name = "lbl72";
            this.lbl72.Size = new System.Drawing.Size(44, 40);
            this.lbl72.TabIndex = 312;
            this.lbl72.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl71
            // 
            this.lbl71.BackColor = System.Drawing.Color.Tomato;
            this.lbl71.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl71.ForeColor = System.Drawing.Color.White;
            this.lbl71.Location = new System.Drawing.Point(335, 323);
            this.lbl71.Multiline = true;
            this.lbl71.Name = "lbl71";
            this.lbl71.Size = new System.Drawing.Size(44, 40);
            this.lbl71.TabIndex = 311;
            this.lbl71.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl68
            // 
            this.lbl68.BackColor = System.Drawing.Color.Crimson;
            this.lbl68.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl68.ForeColor = System.Drawing.Color.White;
            this.lbl68.Location = new System.Drawing.Point(685, 277);
            this.lbl68.Multiline = true;
            this.lbl68.Name = "lbl68";
            this.lbl68.Size = new System.Drawing.Size(44, 40);
            this.lbl68.TabIndex = 310;
            this.lbl68.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl67
            // 
            this.lbl67.BackColor = System.Drawing.Color.Crimson;
            this.lbl67.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl67.ForeColor = System.Drawing.Color.White;
            this.lbl67.Location = new System.Drawing.Point(635, 277);
            this.lbl67.Multiline = true;
            this.lbl67.Name = "lbl67";
            this.lbl67.Size = new System.Drawing.Size(44, 40);
            this.lbl67.TabIndex = 309;
            this.lbl67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl66
            // 
            this.lbl66.BackColor = System.Drawing.Color.Crimson;
            this.lbl66.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl66.ForeColor = System.Drawing.Color.White;
            this.lbl66.Location = new System.Drawing.Point(585, 277);
            this.lbl66.Multiline = true;
            this.lbl66.Name = "lbl66";
            this.lbl66.Size = new System.Drawing.Size(44, 40);
            this.lbl66.TabIndex = 308;
            this.lbl66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl65
            // 
            this.lbl65.BackColor = System.Drawing.Color.Crimson;
            this.lbl65.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl65.ForeColor = System.Drawing.Color.White;
            this.lbl65.Location = new System.Drawing.Point(535, 277);
            this.lbl65.Multiline = true;
            this.lbl65.Name = "lbl65";
            this.lbl65.Size = new System.Drawing.Size(44, 40);
            this.lbl65.TabIndex = 307;
            this.lbl65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl58
            // 
            this.lbl58.BackColor = System.Drawing.Color.Crimson;
            this.lbl58.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl58.ForeColor = System.Drawing.Color.White;
            this.lbl58.Location = new System.Drawing.Point(685, 231);
            this.lbl58.Multiline = true;
            this.lbl58.Name = "lbl58";
            this.lbl58.Size = new System.Drawing.Size(44, 40);
            this.lbl58.TabIndex = 306;
            this.lbl58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl57
            // 
            this.lbl57.BackColor = System.Drawing.Color.Crimson;
            this.lbl57.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl57.ForeColor = System.Drawing.Color.White;
            this.lbl57.Location = new System.Drawing.Point(635, 231);
            this.lbl57.Multiline = true;
            this.lbl57.Name = "lbl57";
            this.lbl57.Size = new System.Drawing.Size(44, 40);
            this.lbl57.TabIndex = 305;
            this.lbl57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl56
            // 
            this.lbl56.BackColor = System.Drawing.Color.Crimson;
            this.lbl56.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl56.ForeColor = System.Drawing.Color.White;
            this.lbl56.Location = new System.Drawing.Point(585, 231);
            this.lbl56.Multiline = true;
            this.lbl56.Name = "lbl56";
            this.lbl56.Size = new System.Drawing.Size(44, 40);
            this.lbl56.TabIndex = 304;
            this.lbl56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl55
            // 
            this.lbl55.BackColor = System.Drawing.Color.Crimson;
            this.lbl55.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl55.ForeColor = System.Drawing.Color.White;
            this.lbl55.Location = new System.Drawing.Point(535, 231);
            this.lbl55.Multiline = true;
            this.lbl55.Name = "lbl55";
            this.lbl55.Size = new System.Drawing.Size(44, 40);
            this.lbl55.TabIndex = 303;
            this.lbl55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl48
            // 
            this.lbl48.BackColor = System.Drawing.Color.Teal;
            this.lbl48.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl48.ForeColor = System.Drawing.Color.White;
            this.lbl48.Location = new System.Drawing.Point(685, 185);
            this.lbl48.Multiline = true;
            this.lbl48.Name = "lbl48";
            this.lbl48.Size = new System.Drawing.Size(44, 40);
            this.lbl48.TabIndex = 302;
            this.lbl48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl47
            // 
            this.lbl47.BackColor = System.Drawing.Color.Teal;
            this.lbl47.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl47.ForeColor = System.Drawing.Color.White;
            this.lbl47.Location = new System.Drawing.Point(635, 185);
            this.lbl47.Multiline = true;
            this.lbl47.Name = "lbl47";
            this.lbl47.Size = new System.Drawing.Size(44, 40);
            this.lbl47.TabIndex = 301;
            this.lbl47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl46
            // 
            this.lbl46.BackColor = System.Drawing.Color.Teal;
            this.lbl46.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl46.ForeColor = System.Drawing.Color.White;
            this.lbl46.Location = new System.Drawing.Point(585, 185);
            this.lbl46.Multiline = true;
            this.lbl46.Name = "lbl46";
            this.lbl46.Size = new System.Drawing.Size(44, 40);
            this.lbl46.TabIndex = 300;
            this.lbl46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl45
            // 
            this.lbl45.BackColor = System.Drawing.Color.Teal;
            this.lbl45.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl45.ForeColor = System.Drawing.Color.White;
            this.lbl45.Location = new System.Drawing.Point(535, 185);
            this.lbl45.Multiline = true;
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(44, 40);
            this.lbl45.TabIndex = 299;
            this.lbl45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl38
            // 
            this.lbl38.BackColor = System.Drawing.Color.Teal;
            this.lbl38.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl38.ForeColor = System.Drawing.Color.White;
            this.lbl38.Location = new System.Drawing.Point(685, 139);
            this.lbl38.Multiline = true;
            this.lbl38.Name = "lbl38";
            this.lbl38.Size = new System.Drawing.Size(44, 40);
            this.lbl38.TabIndex = 298;
            this.lbl38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl37
            // 
            this.lbl37.BackColor = System.Drawing.Color.Teal;
            this.lbl37.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl37.ForeColor = System.Drawing.Color.White;
            this.lbl37.Location = new System.Drawing.Point(635, 139);
            this.lbl37.Multiline = true;
            this.lbl37.Name = "lbl37";
            this.lbl37.Size = new System.Drawing.Size(44, 40);
            this.lbl37.TabIndex = 297;
            this.lbl37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl36
            // 
            this.lbl36.BackColor = System.Drawing.Color.Teal;
            this.lbl36.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl36.ForeColor = System.Drawing.Color.White;
            this.lbl36.Location = new System.Drawing.Point(585, 139);
            this.lbl36.Multiline = true;
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(44, 40);
            this.lbl36.TabIndex = 296;
            this.lbl36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl35
            // 
            this.lbl35.BackColor = System.Drawing.Color.Teal;
            this.lbl35.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl35.ForeColor = System.Drawing.Color.White;
            this.lbl35.Location = new System.Drawing.Point(535, 139);
            this.lbl35.Multiline = true;
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(44, 40);
            this.lbl35.TabIndex = 295;
            this.lbl35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl28
            // 
            this.lbl28.BackColor = System.Drawing.Color.Green;
            this.lbl28.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl28.ForeColor = System.Drawing.Color.White;
            this.lbl28.Location = new System.Drawing.Point(685, 93);
            this.lbl28.Multiline = true;
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(44, 40);
            this.lbl28.TabIndex = 294;
            this.lbl28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl27
            // 
            this.lbl27.BackColor = System.Drawing.Color.Green;
            this.lbl27.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27.ForeColor = System.Drawing.Color.White;
            this.lbl27.Location = new System.Drawing.Point(635, 93);
            this.lbl27.Multiline = true;
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(44, 40);
            this.lbl27.TabIndex = 293;
            this.lbl27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl26
            // 
            this.lbl26.BackColor = System.Drawing.Color.Green;
            this.lbl26.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26.ForeColor = System.Drawing.Color.White;
            this.lbl26.Location = new System.Drawing.Point(585, 93);
            this.lbl26.Multiline = true;
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(44, 40);
            this.lbl26.TabIndex = 292;
            this.lbl26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl25
            // 
            this.lbl25.BackColor = System.Drawing.Color.Green;
            this.lbl25.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.ForeColor = System.Drawing.Color.White;
            this.lbl25.Location = new System.Drawing.Point(535, 93);
            this.lbl25.Multiline = true;
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(44, 40);
            this.lbl25.TabIndex = 291;
            this.lbl25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl18
            // 
            this.lbl18.BackColor = System.Drawing.Color.Green;
            this.lbl18.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl18.ForeColor = System.Drawing.Color.White;
            this.lbl18.Location = new System.Drawing.Point(685, 47);
            this.lbl18.Multiline = true;
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(44, 40);
            this.lbl18.TabIndex = 290;
            this.lbl18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl17
            // 
            this.lbl17.BackColor = System.Drawing.Color.Green;
            this.lbl17.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17.ForeColor = System.Drawing.Color.White;
            this.lbl17.Location = new System.Drawing.Point(635, 47);
            this.lbl17.Multiline = true;
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(44, 40);
            this.lbl17.TabIndex = 289;
            this.lbl17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl16
            // 
            this.lbl16.BackColor = System.Drawing.Color.Green;
            this.lbl16.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl16.ForeColor = System.Drawing.Color.White;
            this.lbl16.Location = new System.Drawing.Point(585, 47);
            this.lbl16.Multiline = true;
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(44, 40);
            this.lbl16.TabIndex = 288;
            this.lbl16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl15
            // 
            this.lbl15.BackColor = System.Drawing.Color.Green;
            this.lbl15.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.ForeColor = System.Drawing.Color.White;
            this.lbl15.Location = new System.Drawing.Point(535, 47);
            this.lbl15.Multiline = true;
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(44, 40);
            this.lbl15.TabIndex = 287;
            this.lbl15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl64
            // 
            this.lbl64.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl64.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl64.ForeColor = System.Drawing.Color.White;
            this.lbl64.Location = new System.Drawing.Point(485, 277);
            this.lbl64.Multiline = true;
            this.lbl64.Name = "lbl64";
            this.lbl64.Size = new System.Drawing.Size(44, 40);
            this.lbl64.TabIndex = 286;
            this.lbl64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl63
            // 
            this.lbl63.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl63.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl63.ForeColor = System.Drawing.Color.White;
            this.lbl63.Location = new System.Drawing.Point(435, 277);
            this.lbl63.Multiline = true;
            this.lbl63.Name = "lbl63";
            this.lbl63.Size = new System.Drawing.Size(44, 40);
            this.lbl63.TabIndex = 285;
            this.lbl63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl62
            // 
            this.lbl62.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl62.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl62.ForeColor = System.Drawing.Color.White;
            this.lbl62.Location = new System.Drawing.Point(385, 277);
            this.lbl62.Multiline = true;
            this.lbl62.Name = "lbl62";
            this.lbl62.Size = new System.Drawing.Size(44, 40);
            this.lbl62.TabIndex = 284;
            this.lbl62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl61
            // 
            this.lbl61.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl61.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl61.ForeColor = System.Drawing.Color.White;
            this.lbl61.Location = new System.Drawing.Point(335, 277);
            this.lbl61.Multiline = true;
            this.lbl61.Name = "lbl61";
            this.lbl61.Size = new System.Drawing.Size(44, 40);
            this.lbl61.TabIndex = 283;
            this.lbl61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl54
            // 
            this.lbl54.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl54.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl54.ForeColor = System.Drawing.Color.White;
            this.lbl54.Location = new System.Drawing.Point(485, 231);
            this.lbl54.Multiline = true;
            this.lbl54.Name = "lbl54";
            this.lbl54.Size = new System.Drawing.Size(44, 40);
            this.lbl54.TabIndex = 282;
            this.lbl54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl53
            // 
            this.lbl53.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl53.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl53.ForeColor = System.Drawing.Color.White;
            this.lbl53.Location = new System.Drawing.Point(435, 231);
            this.lbl53.Multiline = true;
            this.lbl53.Name = "lbl53";
            this.lbl53.Size = new System.Drawing.Size(44, 40);
            this.lbl53.TabIndex = 281;
            this.lbl53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl52
            // 
            this.lbl52.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl52.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl52.ForeColor = System.Drawing.Color.White;
            this.lbl52.Location = new System.Drawing.Point(385, 231);
            this.lbl52.Multiline = true;
            this.lbl52.Name = "lbl52";
            this.lbl52.Size = new System.Drawing.Size(44, 40);
            this.lbl52.TabIndex = 280;
            this.lbl52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl51
            // 
            this.lbl51.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl51.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl51.ForeColor = System.Drawing.Color.White;
            this.lbl51.Location = new System.Drawing.Point(335, 231);
            this.lbl51.Multiline = true;
            this.lbl51.Name = "lbl51";
            this.lbl51.Size = new System.Drawing.Size(44, 40);
            this.lbl51.TabIndex = 279;
            this.lbl51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl44
            // 
            this.lbl44.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl44.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl44.ForeColor = System.Drawing.Color.White;
            this.lbl44.Location = new System.Drawing.Point(485, 185);
            this.lbl44.Multiline = true;
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(44, 40);
            this.lbl44.TabIndex = 278;
            this.lbl44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl43
            // 
            this.lbl43.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl43.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl43.ForeColor = System.Drawing.Color.White;
            this.lbl43.Location = new System.Drawing.Point(435, 185);
            this.lbl43.Multiline = true;
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(44, 40);
            this.lbl43.TabIndex = 277;
            this.lbl43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl42
            // 
            this.lbl42.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl42.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl42.ForeColor = System.Drawing.Color.White;
            this.lbl42.Location = new System.Drawing.Point(385, 185);
            this.lbl42.Multiline = true;
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(44, 40);
            this.lbl42.TabIndex = 276;
            this.lbl42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl41
            // 
            this.lbl41.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl41.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl41.ForeColor = System.Drawing.Color.White;
            this.lbl41.Location = new System.Drawing.Point(335, 185);
            this.lbl41.Multiline = true;
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(44, 40);
            this.lbl41.TabIndex = 275;
            this.lbl41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl34
            // 
            this.lbl34.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl34.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl34.ForeColor = System.Drawing.Color.White;
            this.lbl34.Location = new System.Drawing.Point(485, 139);
            this.lbl34.Multiline = true;
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(44, 40);
            this.lbl34.TabIndex = 274;
            this.lbl34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl33
            // 
            this.lbl33.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl33.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.ForeColor = System.Drawing.Color.White;
            this.lbl33.Location = new System.Drawing.Point(435, 139);
            this.lbl33.Multiline = true;
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(44, 40);
            this.lbl33.TabIndex = 273;
            this.lbl33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl32
            // 
            this.lbl32.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl32.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.ForeColor = System.Drawing.Color.White;
            this.lbl32.Location = new System.Drawing.Point(385, 139);
            this.lbl32.Multiline = true;
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(44, 40);
            this.lbl32.TabIndex = 272;
            this.lbl32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl31
            // 
            this.lbl31.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl31.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.ForeColor = System.Drawing.Color.White;
            this.lbl31.Location = new System.Drawing.Point(335, 139);
            this.lbl31.Multiline = true;
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(44, 40);
            this.lbl31.TabIndex = 271;
            this.lbl31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl24
            // 
            this.lbl24.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl24.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.ForeColor = System.Drawing.Color.White;
            this.lbl24.Location = new System.Drawing.Point(485, 93);
            this.lbl24.Multiline = true;
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(44, 40);
            this.lbl24.TabIndex = 270;
            this.lbl24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl23
            // 
            this.lbl23.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl23.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.ForeColor = System.Drawing.Color.White;
            this.lbl23.Location = new System.Drawing.Point(435, 93);
            this.lbl23.Multiline = true;
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(44, 40);
            this.lbl23.TabIndex = 269;
            this.lbl23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl22
            // 
            this.lbl22.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl22.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.ForeColor = System.Drawing.Color.White;
            this.lbl22.Location = new System.Drawing.Point(385, 93);
            this.lbl22.Multiline = true;
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(44, 40);
            this.lbl22.TabIndex = 268;
            this.lbl22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl21
            // 
            this.lbl21.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl21.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.ForeColor = System.Drawing.Color.White;
            this.lbl21.Location = new System.Drawing.Point(335, 93);
            this.lbl21.Multiline = true;
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(44, 40);
            this.lbl21.TabIndex = 267;
            this.lbl21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl14
            // 
            this.lbl14.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl14.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl14.ForeColor = System.Drawing.Color.White;
            this.lbl14.Location = new System.Drawing.Point(485, 47);
            this.lbl14.Multiline = true;
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(44, 40);
            this.lbl14.TabIndex = 266;
            this.lbl14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl13
            // 
            this.lbl13.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl13.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.ForeColor = System.Drawing.Color.White;
            this.lbl13.Location = new System.Drawing.Point(435, 47);
            this.lbl13.Multiline = true;
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(44, 40);
            this.lbl13.TabIndex = 265;
            this.lbl13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl12.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.ForeColor = System.Drawing.Color.White;
            this.lbl12.Location = new System.Drawing.Point(385, 47);
            this.lbl12.Multiline = true;
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(44, 40);
            this.lbl12.TabIndex = 264;
            this.lbl12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl11.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.ForeColor = System.Drawing.Color.White;
            this.lbl11.Location = new System.Drawing.Point(335, 47);
            this.lbl11.Multiline = true;
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(44, 40);
            this.lbl11.TabIndex = 263;
            this.lbl11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 60F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(699, 435);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 98);
            this.label1.TabIndex = 871;
            this.label1.Text = "8x8";
            // 
            // lblClear
            // 
            this.lblClear.AutoSize = true;
            this.lblClear.BackColor = System.Drawing.Color.Transparent;
            this.lblClear.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClear.ForeColor = System.Drawing.Color.Crimson;
            this.lblClear.Location = new System.Drawing.Point(723, 582);
            this.lblClear.Name = "lblClear";
            this.lblClear.Size = new System.Drawing.Size(78, 28);
            this.lblClear.TabIndex = 899;
            this.lblClear.Text = "Clear";
            this.lblClear.Click += new System.EventHandler(this.btnClear_Click);
            this.lblClear.MouseLeave += new System.EventHandler(this.lblClear_MouseLeave);
            this.lblClear.MouseHover += new System.EventHandler(this.lblClear_MouseHover);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.BackColor = System.Drawing.Color.Transparent;
            this.lblResult.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.ForeColor = System.Drawing.Color.Crimson;
            this.lblResult.Location = new System.Drawing.Point(549, 582);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(90, 28);
            this.lblResult.TabIndex = 898;
            this.lblResult.Text = "Result";
            this.lblResult.Click += new System.EventHandler(this.btnGo_Click);
            this.lblResult.MouseLeave += new System.EventHandler(this.lblResult_MouseLeave);
            this.lblResult.MouseHover += new System.EventHandler(this.lblResult_MouseHover);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(268, 601);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(568, 16);
            this.label5.TabIndex = 897;
            this.label5.Text = "________________________________________________________________________________";
            // 
            // lblBack
            // 
            this.lblBack.AutoSize = true;
            this.lblBack.BackColor = System.Drawing.Color.Transparent;
            this.lblBack.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBack.ForeColor = System.Drawing.Color.Crimson;
            this.lblBack.Location = new System.Drawing.Point(43, 6);
            this.lblBack.Name = "lblBack";
            this.lblBack.Size = new System.Drawing.Size(148, 28);
            this.lblBack.TabIndex = 896;
            this.lblBack.Text = "Back Menu";
            this.lblBack.Click += new System.EventHandler(this.btnBack_Click);
            this.lblBack.MouseLeave += new System.EventHandler(this.lblBack_MouseLeave);
            this.lblBack.MouseHover += new System.EventHandler(this.lblBack_MouseHover);
            // 
            // Check
            // 
            this.Check.AutoSize = true;
            this.Check.BackColor = System.Drawing.Color.Transparent;
            this.Check.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check.ForeColor = System.Drawing.Color.Crimson;
            this.Check.Location = new System.Drawing.Point(337, 583);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(86, 28);
            this.Check.TabIndex = 900;
            this.Check.Text = "Check";
            this.Check.Click += new System.EventHandler(this.Check_Click);
            // 
            // N8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::SudokuN.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1087, 655);
            this.Controls.Add(this.Check);
            this.Controls.Add(this.lblClear);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl88);
            this.Controls.Add(this.lbl87);
            this.Controls.Add(this.lbl86);
            this.Controls.Add(this.lbl85);
            this.Controls.Add(this.lbl78);
            this.Controls.Add(this.lbl77);
            this.Controls.Add(this.lbl76);
            this.Controls.Add(this.lbl75);
            this.Controls.Add(this.lbl84);
            this.Controls.Add(this.lbl83);
            this.Controls.Add(this.lbl82);
            this.Controls.Add(this.lbl81);
            this.Controls.Add(this.lbl74);
            this.Controls.Add(this.lbl73);
            this.Controls.Add(this.lbl72);
            this.Controls.Add(this.lbl71);
            this.Controls.Add(this.lbl68);
            this.Controls.Add(this.lbl67);
            this.Controls.Add(this.lbl66);
            this.Controls.Add(this.lbl65);
            this.Controls.Add(this.lbl58);
            this.Controls.Add(this.lbl57);
            this.Controls.Add(this.lbl56);
            this.Controls.Add(this.lbl55);
            this.Controls.Add(this.lbl48);
            this.Controls.Add(this.lbl47);
            this.Controls.Add(this.lbl46);
            this.Controls.Add(this.lbl45);
            this.Controls.Add(this.lbl38);
            this.Controls.Add(this.lbl37);
            this.Controls.Add(this.lbl36);
            this.Controls.Add(this.lbl35);
            this.Controls.Add(this.lbl28);
            this.Controls.Add(this.lbl27);
            this.Controls.Add(this.lbl26);
            this.Controls.Add(this.lbl25);
            this.Controls.Add(this.lbl18);
            this.Controls.Add(this.lbl17);
            this.Controls.Add(this.lbl16);
            this.Controls.Add(this.lbl15);
            this.Controls.Add(this.lbl64);
            this.Controls.Add(this.lbl63);
            this.Controls.Add(this.lbl62);
            this.Controls.Add(this.lbl61);
            this.Controls.Add(this.lbl54);
            this.Controls.Add(this.lbl53);
            this.Controls.Add(this.lbl52);
            this.Controls.Add(this.lbl51);
            this.Controls.Add(this.lbl44);
            this.Controls.Add(this.lbl43);
            this.Controls.Add(this.lbl42);
            this.Controls.Add(this.lbl41);
            this.Controls.Add(this.lbl34);
            this.Controls.Add(this.lbl33);
            this.Controls.Add(this.lbl32);
            this.Controls.Add(this.lbl31);
            this.Controls.Add(this.lbl24);
            this.Controls.Add(this.lbl23);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl14);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximumSize = new System.Drawing.Size(1103, 694);
            this.MinimumSize = new System.Drawing.Size(1103, 694);
            this.Name = "N8";
            this.Text = "N8";
            this.Load += new System.EventHandler(this.N8_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox lbl88;
        private System.Windows.Forms.TextBox lbl87;
        private System.Windows.Forms.TextBox lbl86;
        private System.Windows.Forms.TextBox lbl85;
        private System.Windows.Forms.TextBox lbl78;
        private System.Windows.Forms.TextBox lbl77;
        private System.Windows.Forms.TextBox lbl76;
        private System.Windows.Forms.TextBox lbl75;
        private System.Windows.Forms.TextBox lbl84;
        private System.Windows.Forms.TextBox lbl83;
        private System.Windows.Forms.TextBox lbl82;
        private System.Windows.Forms.TextBox lbl81;
        private System.Windows.Forms.TextBox lbl74;
        private System.Windows.Forms.TextBox lbl73;
        private System.Windows.Forms.TextBox lbl72;
        private System.Windows.Forms.TextBox lbl71;
        private System.Windows.Forms.TextBox lbl68;
        private System.Windows.Forms.TextBox lbl67;
        private System.Windows.Forms.TextBox lbl66;
        private System.Windows.Forms.TextBox lbl65;
        private System.Windows.Forms.TextBox lbl58;
        private System.Windows.Forms.TextBox lbl57;
        private System.Windows.Forms.TextBox lbl56;
        private System.Windows.Forms.TextBox lbl55;
        private System.Windows.Forms.TextBox lbl48;
        private System.Windows.Forms.TextBox lbl47;
        private System.Windows.Forms.TextBox lbl46;
        private System.Windows.Forms.TextBox lbl45;
        private System.Windows.Forms.TextBox lbl38;
        private System.Windows.Forms.TextBox lbl37;
        private System.Windows.Forms.TextBox lbl36;
        private System.Windows.Forms.TextBox lbl35;
        private System.Windows.Forms.TextBox lbl28;
        private System.Windows.Forms.TextBox lbl27;
        private System.Windows.Forms.TextBox lbl26;
        private System.Windows.Forms.TextBox lbl25;
        private System.Windows.Forms.TextBox lbl18;
        private System.Windows.Forms.TextBox lbl17;
        private System.Windows.Forms.TextBox lbl16;
        private System.Windows.Forms.TextBox lbl15;
        private System.Windows.Forms.TextBox lbl64;
        private System.Windows.Forms.TextBox lbl63;
        private System.Windows.Forms.TextBox lbl62;
        private System.Windows.Forms.TextBox lbl61;
        private System.Windows.Forms.TextBox lbl54;
        private System.Windows.Forms.TextBox lbl53;
        private System.Windows.Forms.TextBox lbl52;
        private System.Windows.Forms.TextBox lbl51;
        private System.Windows.Forms.TextBox lbl44;
        private System.Windows.Forms.TextBox lbl43;
        private System.Windows.Forms.TextBox lbl42;
        private System.Windows.Forms.TextBox lbl41;
        private System.Windows.Forms.TextBox lbl34;
        private System.Windows.Forms.TextBox lbl33;
        private System.Windows.Forms.TextBox lbl32;
        private System.Windows.Forms.TextBox lbl31;
        private System.Windows.Forms.TextBox lbl24;
        private System.Windows.Forms.TextBox lbl23;
        private System.Windows.Forms.TextBox lbl22;
        private System.Windows.Forms.TextBox lbl21;
        private System.Windows.Forms.TextBox lbl14;
        private System.Windows.Forms.TextBox lbl13;
        private System.Windows.Forms.TextBox lbl12;
        private System.Windows.Forms.TextBox lbl11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblClear;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblBack;
        private System.Windows.Forms.Label Check;
    }
}