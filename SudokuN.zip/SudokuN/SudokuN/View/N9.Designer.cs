﻿namespace SudokuN.View
{
    partial class N9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl99 = new System.Windows.Forms.TextBox();
            this.lbl98 = new System.Windows.Forms.TextBox();
            this.lbl97 = new System.Windows.Forms.TextBox();
            this.lbl89 = new System.Windows.Forms.TextBox();
            this.lbl88 = new System.Windows.Forms.TextBox();
            this.lbl87 = new System.Windows.Forms.TextBox();
            this.lbl79 = new System.Windows.Forms.TextBox();
            this.lbl78 = new System.Windows.Forms.TextBox();
            this.lbl77 = new System.Windows.Forms.TextBox();
            this.lbl69 = new System.Windows.Forms.TextBox();
            this.lbl68 = new System.Windows.Forms.TextBox();
            this.lbl67 = new System.Windows.Forms.TextBox();
            this.lbl59 = new System.Windows.Forms.TextBox();
            this.lbl58 = new System.Windows.Forms.TextBox();
            this.lbl57 = new System.Windows.Forms.TextBox();
            this.lbl49 = new System.Windows.Forms.TextBox();
            this.lbl48 = new System.Windows.Forms.TextBox();
            this.lbl47 = new System.Windows.Forms.TextBox();
            this.lbl39 = new System.Windows.Forms.TextBox();
            this.lbl38 = new System.Windows.Forms.TextBox();
            this.lbl37 = new System.Windows.Forms.TextBox();
            this.lbl29 = new System.Windows.Forms.TextBox();
            this.lbl28 = new System.Windows.Forms.TextBox();
            this.lbl27 = new System.Windows.Forms.TextBox();
            this.lbl19 = new System.Windows.Forms.TextBox();
            this.lbl18 = new System.Windows.Forms.TextBox();
            this.lbl17 = new System.Windows.Forms.TextBox();
            this.lbl96 = new System.Windows.Forms.TextBox();
            this.lbl95 = new System.Windows.Forms.TextBox();
            this.lbl94 = new System.Windows.Forms.TextBox();
            this.lbl86 = new System.Windows.Forms.TextBox();
            this.lbl85 = new System.Windows.Forms.TextBox();
            this.lbl84 = new System.Windows.Forms.TextBox();
            this.lbl76 = new System.Windows.Forms.TextBox();
            this.lbl75 = new System.Windows.Forms.TextBox();
            this.lbl74 = new System.Windows.Forms.TextBox();
            this.lbl66 = new System.Windows.Forms.TextBox();
            this.lbl65 = new System.Windows.Forms.TextBox();
            this.lbl64 = new System.Windows.Forms.TextBox();
            this.lbl56 = new System.Windows.Forms.TextBox();
            this.lbl55 = new System.Windows.Forms.TextBox();
            this.lbl54 = new System.Windows.Forms.TextBox();
            this.lbl46 = new System.Windows.Forms.TextBox();
            this.lbl45 = new System.Windows.Forms.TextBox();
            this.lbl44 = new System.Windows.Forms.TextBox();
            this.lbl36 = new System.Windows.Forms.TextBox();
            this.lbl35 = new System.Windows.Forms.TextBox();
            this.lbl34 = new System.Windows.Forms.TextBox();
            this.lbl26 = new System.Windows.Forms.TextBox();
            this.lbl25 = new System.Windows.Forms.TextBox();
            this.lbl24 = new System.Windows.Forms.TextBox();
            this.lbl16 = new System.Windows.Forms.TextBox();
            this.lbl15 = new System.Windows.Forms.TextBox();
            this.lbl14 = new System.Windows.Forms.TextBox();
            this.lbl93 = new System.Windows.Forms.TextBox();
            this.lbl92 = new System.Windows.Forms.TextBox();
            this.lbl91 = new System.Windows.Forms.TextBox();
            this.lbl83 = new System.Windows.Forms.TextBox();
            this.lbl82 = new System.Windows.Forms.TextBox();
            this.lbl81 = new System.Windows.Forms.TextBox();
            this.lbl73 = new System.Windows.Forms.TextBox();
            this.lbl72 = new System.Windows.Forms.TextBox();
            this.lbl71 = new System.Windows.Forms.TextBox();
            this.lbl63 = new System.Windows.Forms.TextBox();
            this.lbl62 = new System.Windows.Forms.TextBox();
            this.lbl61 = new System.Windows.Forms.TextBox();
            this.lbl53 = new System.Windows.Forms.TextBox();
            this.lbl52 = new System.Windows.Forms.TextBox();
            this.lbl51 = new System.Windows.Forms.TextBox();
            this.lbl43 = new System.Windows.Forms.TextBox();
            this.lbl42 = new System.Windows.Forms.TextBox();
            this.lbl41 = new System.Windows.Forms.TextBox();
            this.lbl33 = new System.Windows.Forms.TextBox();
            this.lbl32 = new System.Windows.Forms.TextBox();
            this.lbl31 = new System.Windows.Forms.TextBox();
            this.lbl23 = new System.Windows.Forms.TextBox();
            this.lbl22 = new System.Windows.Forms.TextBox();
            this.lbl21 = new System.Windows.Forms.TextBox();
            this.lbl13 = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.TextBox();
            this.lbl11 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblClear = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblBack = new System.Windows.Forms.Label();
            this.Check = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl99
            // 
            this.lbl99.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl99.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl99.ForeColor = System.Drawing.Color.White;
            this.lbl99.Location = new System.Drawing.Point(556, 381);
            this.lbl99.Multiline = true;
            this.lbl99.Name = "lbl99";
            this.lbl99.Size = new System.Drawing.Size(30, 30);
            this.lbl99.TabIndex = 358;
            this.lbl99.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl98
            // 
            this.lbl98.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl98.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl98.ForeColor = System.Drawing.Color.White;
            this.lbl98.Location = new System.Drawing.Point(520, 381);
            this.lbl98.Multiline = true;
            this.lbl98.Name = "lbl98";
            this.lbl98.Size = new System.Drawing.Size(30, 30);
            this.lbl98.TabIndex = 357;
            this.lbl98.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl97
            // 
            this.lbl97.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl97.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl97.ForeColor = System.Drawing.Color.White;
            this.lbl97.Location = new System.Drawing.Point(484, 381);
            this.lbl97.Multiline = true;
            this.lbl97.Name = "lbl97";
            this.lbl97.Size = new System.Drawing.Size(30, 30);
            this.lbl97.TabIndex = 356;
            this.lbl97.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl89
            // 
            this.lbl89.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl89.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl89.ForeColor = System.Drawing.Color.White;
            this.lbl89.Location = new System.Drawing.Point(556, 345);
            this.lbl89.Multiline = true;
            this.lbl89.Name = "lbl89";
            this.lbl89.Size = new System.Drawing.Size(30, 30);
            this.lbl89.TabIndex = 355;
            this.lbl89.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl88
            // 
            this.lbl88.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl88.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl88.ForeColor = System.Drawing.Color.White;
            this.lbl88.Location = new System.Drawing.Point(520, 345);
            this.lbl88.Multiline = true;
            this.lbl88.Name = "lbl88";
            this.lbl88.Size = new System.Drawing.Size(30, 30);
            this.lbl88.TabIndex = 354;
            this.lbl88.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl87
            // 
            this.lbl87.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl87.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl87.ForeColor = System.Drawing.Color.White;
            this.lbl87.Location = new System.Drawing.Point(484, 345);
            this.lbl87.Multiline = true;
            this.lbl87.Name = "lbl87";
            this.lbl87.Size = new System.Drawing.Size(30, 30);
            this.lbl87.TabIndex = 353;
            this.lbl87.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl79
            // 
            this.lbl79.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl79.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl79.ForeColor = System.Drawing.Color.White;
            this.lbl79.Location = new System.Drawing.Point(556, 309);
            this.lbl79.Multiline = true;
            this.lbl79.Name = "lbl79";
            this.lbl79.Size = new System.Drawing.Size(30, 30);
            this.lbl79.TabIndex = 352;
            this.lbl79.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl78
            // 
            this.lbl78.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl78.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl78.ForeColor = System.Drawing.Color.White;
            this.lbl78.Location = new System.Drawing.Point(520, 309);
            this.lbl78.Multiline = true;
            this.lbl78.Name = "lbl78";
            this.lbl78.Size = new System.Drawing.Size(30, 30);
            this.lbl78.TabIndex = 351;
            this.lbl78.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl77
            // 
            this.lbl77.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl77.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl77.ForeColor = System.Drawing.Color.White;
            this.lbl77.Location = new System.Drawing.Point(484, 309);
            this.lbl77.Multiline = true;
            this.lbl77.Name = "lbl77";
            this.lbl77.Size = new System.Drawing.Size(30, 30);
            this.lbl77.TabIndex = 350;
            this.lbl77.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl69
            // 
            this.lbl69.BackColor = System.Drawing.Color.DarkCyan;
            this.lbl69.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl69.ForeColor = System.Drawing.Color.White;
            this.lbl69.Location = new System.Drawing.Point(556, 263);
            this.lbl69.Multiline = true;
            this.lbl69.Name = "lbl69";
            this.lbl69.Size = new System.Drawing.Size(30, 30);
            this.lbl69.TabIndex = 349;
            this.lbl69.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl68
            // 
            this.lbl68.BackColor = System.Drawing.Color.DarkCyan;
            this.lbl68.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl68.ForeColor = System.Drawing.Color.White;
            this.lbl68.Location = new System.Drawing.Point(520, 263);
            this.lbl68.Multiline = true;
            this.lbl68.Name = "lbl68";
            this.lbl68.Size = new System.Drawing.Size(30, 30);
            this.lbl68.TabIndex = 348;
            this.lbl68.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl67
            // 
            this.lbl67.BackColor = System.Drawing.Color.DarkCyan;
            this.lbl67.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl67.ForeColor = System.Drawing.Color.White;
            this.lbl67.Location = new System.Drawing.Point(484, 263);
            this.lbl67.Multiline = true;
            this.lbl67.Name = "lbl67";
            this.lbl67.Size = new System.Drawing.Size(30, 30);
            this.lbl67.TabIndex = 347;
            this.lbl67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl59
            // 
            this.lbl59.BackColor = System.Drawing.Color.DarkCyan;
            this.lbl59.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl59.ForeColor = System.Drawing.Color.White;
            this.lbl59.Location = new System.Drawing.Point(556, 227);
            this.lbl59.Multiline = true;
            this.lbl59.Name = "lbl59";
            this.lbl59.Size = new System.Drawing.Size(30, 30);
            this.lbl59.TabIndex = 346;
            this.lbl59.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl58
            // 
            this.lbl58.BackColor = System.Drawing.Color.DarkCyan;
            this.lbl58.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl58.ForeColor = System.Drawing.Color.White;
            this.lbl58.Location = new System.Drawing.Point(520, 227);
            this.lbl58.Multiline = true;
            this.lbl58.Name = "lbl58";
            this.lbl58.Size = new System.Drawing.Size(30, 30);
            this.lbl58.TabIndex = 345;
            this.lbl58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl57
            // 
            this.lbl57.BackColor = System.Drawing.Color.DarkCyan;
            this.lbl57.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl57.ForeColor = System.Drawing.Color.White;
            this.lbl57.Location = new System.Drawing.Point(484, 227);
            this.lbl57.Multiline = true;
            this.lbl57.Name = "lbl57";
            this.lbl57.Size = new System.Drawing.Size(30, 30);
            this.lbl57.TabIndex = 344;
            this.lbl57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl49
            // 
            this.lbl49.BackColor = System.Drawing.Color.DarkCyan;
            this.lbl49.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl49.ForeColor = System.Drawing.Color.White;
            this.lbl49.Location = new System.Drawing.Point(556, 191);
            this.lbl49.Multiline = true;
            this.lbl49.Name = "lbl49";
            this.lbl49.Size = new System.Drawing.Size(30, 30);
            this.lbl49.TabIndex = 343;
            this.lbl49.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl48
            // 
            this.lbl48.BackColor = System.Drawing.Color.DarkCyan;
            this.lbl48.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl48.ForeColor = System.Drawing.Color.White;
            this.lbl48.Location = new System.Drawing.Point(520, 191);
            this.lbl48.Multiline = true;
            this.lbl48.Name = "lbl48";
            this.lbl48.Size = new System.Drawing.Size(30, 30);
            this.lbl48.TabIndex = 342;
            this.lbl48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl47
            // 
            this.lbl47.BackColor = System.Drawing.Color.DarkCyan;
            this.lbl47.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl47.ForeColor = System.Drawing.Color.White;
            this.lbl47.Location = new System.Drawing.Point(484, 191);
            this.lbl47.Multiline = true;
            this.lbl47.Name = "lbl47";
            this.lbl47.Size = new System.Drawing.Size(30, 30);
            this.lbl47.TabIndex = 341;
            this.lbl47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl39
            // 
            this.lbl39.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl39.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl39.ForeColor = System.Drawing.Color.White;
            this.lbl39.Location = new System.Drawing.Point(556, 145);
            this.lbl39.Multiline = true;
            this.lbl39.Name = "lbl39";
            this.lbl39.Size = new System.Drawing.Size(30, 30);
            this.lbl39.TabIndex = 340;
            this.lbl39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl38
            // 
            this.lbl38.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl38.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl38.ForeColor = System.Drawing.Color.White;
            this.lbl38.Location = new System.Drawing.Point(520, 145);
            this.lbl38.Multiline = true;
            this.lbl38.Name = "lbl38";
            this.lbl38.Size = new System.Drawing.Size(30, 30);
            this.lbl38.TabIndex = 339;
            this.lbl38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl37
            // 
            this.lbl37.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl37.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl37.ForeColor = System.Drawing.Color.White;
            this.lbl37.Location = new System.Drawing.Point(484, 145);
            this.lbl37.Multiline = true;
            this.lbl37.Name = "lbl37";
            this.lbl37.Size = new System.Drawing.Size(30, 30);
            this.lbl37.TabIndex = 338;
            this.lbl37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl29
            // 
            this.lbl29.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl29.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl29.ForeColor = System.Drawing.Color.White;
            this.lbl29.Location = new System.Drawing.Point(556, 109);
            this.lbl29.Multiline = true;
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(30, 30);
            this.lbl29.TabIndex = 337;
            this.lbl29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl28
            // 
            this.lbl28.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl28.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl28.ForeColor = System.Drawing.Color.White;
            this.lbl28.Location = new System.Drawing.Point(520, 109);
            this.lbl28.Multiline = true;
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(30, 30);
            this.lbl28.TabIndex = 336;
            this.lbl28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl27
            // 
            this.lbl27.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl27.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27.ForeColor = System.Drawing.Color.White;
            this.lbl27.Location = new System.Drawing.Point(484, 109);
            this.lbl27.Multiline = true;
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(30, 30);
            this.lbl27.TabIndex = 335;
            this.lbl27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl19
            // 
            this.lbl19.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl19.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl19.ForeColor = System.Drawing.Color.White;
            this.lbl19.Location = new System.Drawing.Point(556, 73);
            this.lbl19.Multiline = true;
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(30, 30);
            this.lbl19.TabIndex = 334;
            this.lbl19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl18
            // 
            this.lbl18.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl18.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl18.ForeColor = System.Drawing.Color.White;
            this.lbl18.Location = new System.Drawing.Point(520, 73);
            this.lbl18.Multiline = true;
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(30, 30);
            this.lbl18.TabIndex = 333;
            this.lbl18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl17
            // 
            this.lbl17.BackColor = System.Drawing.Color.LimeGreen;
            this.lbl17.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17.ForeColor = System.Drawing.Color.White;
            this.lbl17.Location = new System.Drawing.Point(484, 73);
            this.lbl17.Multiline = true;
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(30, 30);
            this.lbl17.TabIndex = 332;
            this.lbl17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl96
            // 
            this.lbl96.BackColor = System.Drawing.Color.Crimson;
            this.lbl96.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl96.ForeColor = System.Drawing.Color.White;
            this.lbl96.Location = new System.Drawing.Point(432, 381);
            this.lbl96.Multiline = true;
            this.lbl96.Name = "lbl96";
            this.lbl96.Size = new System.Drawing.Size(30, 30);
            this.lbl96.TabIndex = 331;
            this.lbl96.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl95
            // 
            this.lbl95.BackColor = System.Drawing.Color.Crimson;
            this.lbl95.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl95.ForeColor = System.Drawing.Color.White;
            this.lbl95.Location = new System.Drawing.Point(396, 381);
            this.lbl95.Multiline = true;
            this.lbl95.Name = "lbl95";
            this.lbl95.Size = new System.Drawing.Size(30, 30);
            this.lbl95.TabIndex = 330;
            this.lbl95.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl94
            // 
            this.lbl94.BackColor = System.Drawing.Color.Crimson;
            this.lbl94.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl94.ForeColor = System.Drawing.Color.White;
            this.lbl94.Location = new System.Drawing.Point(360, 381);
            this.lbl94.Multiline = true;
            this.lbl94.Name = "lbl94";
            this.lbl94.Size = new System.Drawing.Size(30, 30);
            this.lbl94.TabIndex = 329;
            this.lbl94.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl86
            // 
            this.lbl86.BackColor = System.Drawing.Color.Crimson;
            this.lbl86.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl86.ForeColor = System.Drawing.Color.White;
            this.lbl86.Location = new System.Drawing.Point(432, 345);
            this.lbl86.Multiline = true;
            this.lbl86.Name = "lbl86";
            this.lbl86.Size = new System.Drawing.Size(30, 30);
            this.lbl86.TabIndex = 328;
            this.lbl86.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl85
            // 
            this.lbl85.BackColor = System.Drawing.Color.Crimson;
            this.lbl85.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl85.ForeColor = System.Drawing.Color.White;
            this.lbl85.Location = new System.Drawing.Point(396, 345);
            this.lbl85.Multiline = true;
            this.lbl85.Name = "lbl85";
            this.lbl85.Size = new System.Drawing.Size(30, 30);
            this.lbl85.TabIndex = 327;
            this.lbl85.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl84
            // 
            this.lbl84.BackColor = System.Drawing.Color.Crimson;
            this.lbl84.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl84.ForeColor = System.Drawing.Color.White;
            this.lbl84.Location = new System.Drawing.Point(360, 345);
            this.lbl84.Multiline = true;
            this.lbl84.Name = "lbl84";
            this.lbl84.Size = new System.Drawing.Size(30, 30);
            this.lbl84.TabIndex = 326;
            this.lbl84.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl76
            // 
            this.lbl76.BackColor = System.Drawing.Color.Crimson;
            this.lbl76.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl76.ForeColor = System.Drawing.Color.White;
            this.lbl76.Location = new System.Drawing.Point(432, 309);
            this.lbl76.Multiline = true;
            this.lbl76.Name = "lbl76";
            this.lbl76.Size = new System.Drawing.Size(30, 30);
            this.lbl76.TabIndex = 325;
            this.lbl76.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl75
            // 
            this.lbl75.BackColor = System.Drawing.Color.Crimson;
            this.lbl75.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl75.ForeColor = System.Drawing.Color.White;
            this.lbl75.Location = new System.Drawing.Point(396, 309);
            this.lbl75.Multiline = true;
            this.lbl75.Name = "lbl75";
            this.lbl75.Size = new System.Drawing.Size(30, 30);
            this.lbl75.TabIndex = 324;
            this.lbl75.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl74
            // 
            this.lbl74.BackColor = System.Drawing.Color.Crimson;
            this.lbl74.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl74.ForeColor = System.Drawing.Color.White;
            this.lbl74.Location = new System.Drawing.Point(360, 309);
            this.lbl74.Multiline = true;
            this.lbl74.Name = "lbl74";
            this.lbl74.Size = new System.Drawing.Size(30, 30);
            this.lbl74.TabIndex = 323;
            this.lbl74.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl66
            // 
            this.lbl66.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl66.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl66.ForeColor = System.Drawing.Color.White;
            this.lbl66.Location = new System.Drawing.Point(432, 263);
            this.lbl66.Multiline = true;
            this.lbl66.Name = "lbl66";
            this.lbl66.Size = new System.Drawing.Size(30, 30);
            this.lbl66.TabIndex = 322;
            this.lbl66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl65
            // 
            this.lbl65.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl65.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl65.ForeColor = System.Drawing.Color.White;
            this.lbl65.Location = new System.Drawing.Point(396, 263);
            this.lbl65.Multiline = true;
            this.lbl65.Name = "lbl65";
            this.lbl65.Size = new System.Drawing.Size(30, 30);
            this.lbl65.TabIndex = 321;
            this.lbl65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl64
            // 
            this.lbl64.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl64.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl64.ForeColor = System.Drawing.Color.White;
            this.lbl64.Location = new System.Drawing.Point(360, 263);
            this.lbl64.Multiline = true;
            this.lbl64.Name = "lbl64";
            this.lbl64.Size = new System.Drawing.Size(30, 30);
            this.lbl64.TabIndex = 320;
            this.lbl64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl56
            // 
            this.lbl56.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl56.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl56.ForeColor = System.Drawing.Color.White;
            this.lbl56.Location = new System.Drawing.Point(432, 227);
            this.lbl56.Multiline = true;
            this.lbl56.Name = "lbl56";
            this.lbl56.Size = new System.Drawing.Size(30, 30);
            this.lbl56.TabIndex = 319;
            this.lbl56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl55
            // 
            this.lbl55.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl55.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl55.ForeColor = System.Drawing.Color.White;
            this.lbl55.Location = new System.Drawing.Point(396, 227);
            this.lbl55.Multiline = true;
            this.lbl55.Name = "lbl55";
            this.lbl55.Size = new System.Drawing.Size(30, 30);
            this.lbl55.TabIndex = 318;
            this.lbl55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl54
            // 
            this.lbl54.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl54.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl54.ForeColor = System.Drawing.Color.White;
            this.lbl54.Location = new System.Drawing.Point(360, 227);
            this.lbl54.Multiline = true;
            this.lbl54.Name = "lbl54";
            this.lbl54.Size = new System.Drawing.Size(30, 30);
            this.lbl54.TabIndex = 317;
            this.lbl54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl46
            // 
            this.lbl46.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl46.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl46.ForeColor = System.Drawing.Color.White;
            this.lbl46.Location = new System.Drawing.Point(432, 191);
            this.lbl46.Multiline = true;
            this.lbl46.Name = "lbl46";
            this.lbl46.Size = new System.Drawing.Size(30, 30);
            this.lbl46.TabIndex = 316;
            this.lbl46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl45
            // 
            this.lbl45.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl45.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl45.ForeColor = System.Drawing.Color.White;
            this.lbl45.Location = new System.Drawing.Point(396, 191);
            this.lbl45.Multiline = true;
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(30, 30);
            this.lbl45.TabIndex = 315;
            this.lbl45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl44
            // 
            this.lbl44.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl44.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl44.ForeColor = System.Drawing.Color.White;
            this.lbl44.Location = new System.Drawing.Point(360, 191);
            this.lbl44.Multiline = true;
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(30, 30);
            this.lbl44.TabIndex = 314;
            this.lbl44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl36
            // 
            this.lbl36.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl36.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl36.ForeColor = System.Drawing.Color.White;
            this.lbl36.Location = new System.Drawing.Point(432, 145);
            this.lbl36.Multiline = true;
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(30, 30);
            this.lbl36.TabIndex = 313;
            this.lbl36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl35
            // 
            this.lbl35.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl35.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl35.ForeColor = System.Drawing.Color.White;
            this.lbl35.Location = new System.Drawing.Point(396, 145);
            this.lbl35.Multiline = true;
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(30, 30);
            this.lbl35.TabIndex = 312;
            this.lbl35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl34
            // 
            this.lbl34.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl34.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl34.ForeColor = System.Drawing.Color.White;
            this.lbl34.Location = new System.Drawing.Point(360, 145);
            this.lbl34.Multiline = true;
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(30, 30);
            this.lbl34.TabIndex = 311;
            this.lbl34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl26
            // 
            this.lbl26.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl26.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26.ForeColor = System.Drawing.Color.White;
            this.lbl26.Location = new System.Drawing.Point(432, 109);
            this.lbl26.Multiline = true;
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(30, 30);
            this.lbl26.TabIndex = 310;
            this.lbl26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl25
            // 
            this.lbl25.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl25.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.ForeColor = System.Drawing.Color.White;
            this.lbl25.Location = new System.Drawing.Point(396, 109);
            this.lbl25.Multiline = true;
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(30, 30);
            this.lbl25.TabIndex = 309;
            this.lbl25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl24
            // 
            this.lbl24.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl24.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.ForeColor = System.Drawing.Color.White;
            this.lbl24.Location = new System.Drawing.Point(360, 109);
            this.lbl24.Multiline = true;
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(30, 30);
            this.lbl24.TabIndex = 308;
            this.lbl24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl16
            // 
            this.lbl16.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl16.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl16.ForeColor = System.Drawing.Color.White;
            this.lbl16.Location = new System.Drawing.Point(432, 73);
            this.lbl16.Multiline = true;
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(30, 30);
            this.lbl16.TabIndex = 307;
            this.lbl16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl15
            // 
            this.lbl15.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl15.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.ForeColor = System.Drawing.Color.White;
            this.lbl15.Location = new System.Drawing.Point(396, 73);
            this.lbl15.Multiline = true;
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(30, 30);
            this.lbl15.TabIndex = 306;
            this.lbl15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl14
            // 
            this.lbl14.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl14.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl14.ForeColor = System.Drawing.Color.White;
            this.lbl14.Location = new System.Drawing.Point(360, 73);
            this.lbl14.Multiline = true;
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(30, 30);
            this.lbl14.TabIndex = 305;
            this.lbl14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl93
            // 
            this.lbl93.BackColor = System.Drawing.Color.BlueViolet;
            this.lbl93.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl93.ForeColor = System.Drawing.Color.White;
            this.lbl93.Location = new System.Drawing.Point(313, 381);
            this.lbl93.Multiline = true;
            this.lbl93.Name = "lbl93";
            this.lbl93.Size = new System.Drawing.Size(30, 30);
            this.lbl93.TabIndex = 304;
            this.lbl93.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl92
            // 
            this.lbl92.BackColor = System.Drawing.Color.BlueViolet;
            this.lbl92.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl92.ForeColor = System.Drawing.Color.White;
            this.lbl92.Location = new System.Drawing.Point(277, 381);
            this.lbl92.Multiline = true;
            this.lbl92.Name = "lbl92";
            this.lbl92.Size = new System.Drawing.Size(30, 30);
            this.lbl92.TabIndex = 303;
            this.lbl92.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl91
            // 
            this.lbl91.BackColor = System.Drawing.Color.BlueViolet;
            this.lbl91.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl91.ForeColor = System.Drawing.Color.White;
            this.lbl91.Location = new System.Drawing.Point(241, 381);
            this.lbl91.Multiline = true;
            this.lbl91.Name = "lbl91";
            this.lbl91.Size = new System.Drawing.Size(30, 30);
            this.lbl91.TabIndex = 302;
            this.lbl91.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl83
            // 
            this.lbl83.BackColor = System.Drawing.Color.BlueViolet;
            this.lbl83.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl83.ForeColor = System.Drawing.Color.White;
            this.lbl83.Location = new System.Drawing.Point(313, 345);
            this.lbl83.Multiline = true;
            this.lbl83.Name = "lbl83";
            this.lbl83.Size = new System.Drawing.Size(30, 30);
            this.lbl83.TabIndex = 301;
            this.lbl83.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl82
            // 
            this.lbl82.BackColor = System.Drawing.Color.BlueViolet;
            this.lbl82.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl82.ForeColor = System.Drawing.Color.White;
            this.lbl82.Location = new System.Drawing.Point(277, 345);
            this.lbl82.Multiline = true;
            this.lbl82.Name = "lbl82";
            this.lbl82.Size = new System.Drawing.Size(30, 30);
            this.lbl82.TabIndex = 300;
            this.lbl82.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl81
            // 
            this.lbl81.BackColor = System.Drawing.Color.BlueViolet;
            this.lbl81.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl81.ForeColor = System.Drawing.Color.White;
            this.lbl81.Location = new System.Drawing.Point(241, 345);
            this.lbl81.Multiline = true;
            this.lbl81.Name = "lbl81";
            this.lbl81.Size = new System.Drawing.Size(30, 30);
            this.lbl81.TabIndex = 299;
            this.lbl81.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl73
            // 
            this.lbl73.BackColor = System.Drawing.Color.BlueViolet;
            this.lbl73.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl73.ForeColor = System.Drawing.Color.White;
            this.lbl73.Location = new System.Drawing.Point(313, 309);
            this.lbl73.Multiline = true;
            this.lbl73.Name = "lbl73";
            this.lbl73.Size = new System.Drawing.Size(30, 30);
            this.lbl73.TabIndex = 298;
            this.lbl73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl72
            // 
            this.lbl72.BackColor = System.Drawing.Color.BlueViolet;
            this.lbl72.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl72.ForeColor = System.Drawing.Color.White;
            this.lbl72.Location = new System.Drawing.Point(277, 309);
            this.lbl72.Multiline = true;
            this.lbl72.Name = "lbl72";
            this.lbl72.Size = new System.Drawing.Size(30, 30);
            this.lbl72.TabIndex = 297;
            this.lbl72.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl71
            // 
            this.lbl71.BackColor = System.Drawing.Color.BlueViolet;
            this.lbl71.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl71.ForeColor = System.Drawing.Color.White;
            this.lbl71.Location = new System.Drawing.Point(241, 309);
            this.lbl71.Multiline = true;
            this.lbl71.Name = "lbl71";
            this.lbl71.Size = new System.Drawing.Size(30, 30);
            this.lbl71.TabIndex = 296;
            this.lbl71.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl63
            // 
            this.lbl63.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl63.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl63.ForeColor = System.Drawing.Color.White;
            this.lbl63.Location = new System.Drawing.Point(313, 263);
            this.lbl63.Multiline = true;
            this.lbl63.Name = "lbl63";
            this.lbl63.Size = new System.Drawing.Size(30, 30);
            this.lbl63.TabIndex = 295;
            this.lbl63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl62
            // 
            this.lbl62.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl62.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl62.ForeColor = System.Drawing.Color.White;
            this.lbl62.Location = new System.Drawing.Point(277, 263);
            this.lbl62.Multiline = true;
            this.lbl62.Name = "lbl62";
            this.lbl62.Size = new System.Drawing.Size(30, 30);
            this.lbl62.TabIndex = 294;
            this.lbl62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl61
            // 
            this.lbl61.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl61.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl61.ForeColor = System.Drawing.Color.White;
            this.lbl61.Location = new System.Drawing.Point(241, 263);
            this.lbl61.Multiline = true;
            this.lbl61.Name = "lbl61";
            this.lbl61.Size = new System.Drawing.Size(30, 30);
            this.lbl61.TabIndex = 293;
            this.lbl61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl53
            // 
            this.lbl53.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl53.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl53.ForeColor = System.Drawing.Color.White;
            this.lbl53.Location = new System.Drawing.Point(313, 227);
            this.lbl53.Multiline = true;
            this.lbl53.Name = "lbl53";
            this.lbl53.Size = new System.Drawing.Size(30, 30);
            this.lbl53.TabIndex = 292;
            this.lbl53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl52
            // 
            this.lbl52.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl52.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl52.ForeColor = System.Drawing.Color.White;
            this.lbl52.Location = new System.Drawing.Point(277, 227);
            this.lbl52.Multiline = true;
            this.lbl52.Name = "lbl52";
            this.lbl52.Size = new System.Drawing.Size(30, 30);
            this.lbl52.TabIndex = 291;
            this.lbl52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl51
            // 
            this.lbl51.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl51.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl51.ForeColor = System.Drawing.Color.White;
            this.lbl51.Location = new System.Drawing.Point(241, 227);
            this.lbl51.Multiline = true;
            this.lbl51.Name = "lbl51";
            this.lbl51.Size = new System.Drawing.Size(30, 30);
            this.lbl51.TabIndex = 290;
            this.lbl51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl43
            // 
            this.lbl43.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl43.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl43.ForeColor = System.Drawing.Color.White;
            this.lbl43.Location = new System.Drawing.Point(313, 191);
            this.lbl43.Multiline = true;
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(30, 30);
            this.lbl43.TabIndex = 289;
            this.lbl43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl42
            // 
            this.lbl42.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl42.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl42.ForeColor = System.Drawing.Color.White;
            this.lbl42.Location = new System.Drawing.Point(277, 191);
            this.lbl42.Multiline = true;
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(30, 30);
            this.lbl42.TabIndex = 288;
            this.lbl42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl41
            // 
            this.lbl41.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl41.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl41.ForeColor = System.Drawing.Color.White;
            this.lbl41.Location = new System.Drawing.Point(241, 191);
            this.lbl41.Multiline = true;
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(30, 30);
            this.lbl41.TabIndex = 287;
            this.lbl41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl33
            // 
            this.lbl33.BackColor = System.Drawing.Color.Tomato;
            this.lbl33.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.ForeColor = System.Drawing.Color.White;
            this.lbl33.Location = new System.Drawing.Point(313, 145);
            this.lbl33.Multiline = true;
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(30, 30);
            this.lbl33.TabIndex = 286;
            this.lbl33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl32
            // 
            this.lbl32.BackColor = System.Drawing.Color.Tomato;
            this.lbl32.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.ForeColor = System.Drawing.Color.White;
            this.lbl32.Location = new System.Drawing.Point(277, 145);
            this.lbl32.Multiline = true;
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(30, 30);
            this.lbl32.TabIndex = 285;
            this.lbl32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl31
            // 
            this.lbl31.BackColor = System.Drawing.Color.Tomato;
            this.lbl31.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.ForeColor = System.Drawing.Color.White;
            this.lbl31.Location = new System.Drawing.Point(241, 145);
            this.lbl31.Multiline = true;
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(30, 30);
            this.lbl31.TabIndex = 284;
            this.lbl31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl23
            // 
            this.lbl23.BackColor = System.Drawing.Color.Tomato;
            this.lbl23.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.ForeColor = System.Drawing.Color.White;
            this.lbl23.Location = new System.Drawing.Point(313, 109);
            this.lbl23.Multiline = true;
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(30, 30);
            this.lbl23.TabIndex = 283;
            this.lbl23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl22
            // 
            this.lbl22.BackColor = System.Drawing.Color.Tomato;
            this.lbl22.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.ForeColor = System.Drawing.Color.White;
            this.lbl22.Location = new System.Drawing.Point(277, 109);
            this.lbl22.Multiline = true;
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(30, 30);
            this.lbl22.TabIndex = 282;
            this.lbl22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl21
            // 
            this.lbl21.BackColor = System.Drawing.Color.Tomato;
            this.lbl21.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.ForeColor = System.Drawing.Color.White;
            this.lbl21.Location = new System.Drawing.Point(241, 109);
            this.lbl21.Multiline = true;
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(30, 30);
            this.lbl21.TabIndex = 281;
            this.lbl21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl13
            // 
            this.lbl13.BackColor = System.Drawing.Color.Tomato;
            this.lbl13.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.ForeColor = System.Drawing.Color.White;
            this.lbl13.Location = new System.Drawing.Point(313, 73);
            this.lbl13.Multiline = true;
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(30, 30);
            this.lbl13.TabIndex = 280;
            this.lbl13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.Tomato;
            this.lbl12.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.ForeColor = System.Drawing.Color.White;
            this.lbl12.Location = new System.Drawing.Point(277, 73);
            this.lbl12.Multiline = true;
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(30, 30);
            this.lbl12.TabIndex = 279;
            this.lbl12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.Tomato;
            this.lbl11.Font = new System.Drawing.Font("Mistral", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.ForeColor = System.Drawing.Color.White;
            this.lbl11.Location = new System.Drawing.Point(241, 73);
            this.lbl11.Multiline = true;
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(30, 30);
            this.lbl11.TabIndex = 278;
            this.lbl11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 60F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(659, 413);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 98);
            this.label1.TabIndex = 871;
            this.label1.Text = "9x9";
            // 
            // lblClear
            // 
            this.lblClear.AutoSize = true;
            this.lblClear.BackColor = System.Drawing.Color.Transparent;
            this.lblClear.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClear.ForeColor = System.Drawing.Color.Crimson;
            this.lblClear.Location = new System.Drawing.Point(515, 563);
            this.lblClear.Name = "lblClear";
            this.lblClear.Size = new System.Drawing.Size(78, 28);
            this.lblClear.TabIndex = 903;
            this.lblClear.Text = "Clear";
            this.lblClear.Click += new System.EventHandler(this.btnClear_Click);
            this.lblClear.MouseLeave += new System.EventHandler(this.lblClear_MouseLeave);
            this.lblClear.MouseHover += new System.EventHandler(this.lblClear_MouseHover);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.BackColor = System.Drawing.Color.Transparent;
            this.lblResult.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.ForeColor = System.Drawing.Color.Crimson;
            this.lblResult.Location = new System.Drawing.Point(341, 563);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(90, 28);
            this.lblResult.TabIndex = 902;
            this.lblResult.Text = "Result";
            this.lblResult.Click += new System.EventHandler(this.btnGo_Click);
            this.lblResult.MouseLeave += new System.EventHandler(this.lblResult_MouseLeave);
            this.lblResult.MouseHover += new System.EventHandler(this.lblResult_MouseHover);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(109, 581);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(568, 16);
            this.label5.TabIndex = 901;
            this.label5.Text = "________________________________________________________________________________";
            // 
            // lblBack
            // 
            this.lblBack.AutoSize = true;
            this.lblBack.BackColor = System.Drawing.Color.Transparent;
            this.lblBack.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBack.ForeColor = System.Drawing.Color.Crimson;
            this.lblBack.Location = new System.Drawing.Point(41, 3);
            this.lblBack.Name = "lblBack";
            this.lblBack.Size = new System.Drawing.Size(148, 28);
            this.lblBack.TabIndex = 900;
            this.lblBack.Text = "Back Menu";
            this.lblBack.Click += new System.EventHandler(this.btnBack_Click);
            this.lblBack.MouseLeave += new System.EventHandler(this.lblBack_MouseLeave);
            this.lblBack.MouseHover += new System.EventHandler(this.lblBack_MouseHover);
            // 
            // Check
            // 
            this.Check.AutoSize = true;
            this.Check.BackColor = System.Drawing.Color.Transparent;
            this.Check.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check.ForeColor = System.Drawing.Color.Crimson;
            this.Check.Location = new System.Drawing.Point(163, 563);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(86, 28);
            this.Check.TabIndex = 904;
            this.Check.Text = "Check";
            this.Check.Click += new System.EventHandler(this.Check_Click);
            // 
            // N9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::SudokuN.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1030, 633);
            this.Controls.Add(this.Check);
            this.Controls.Add(this.lblClear);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl99);
            this.Controls.Add(this.lbl98);
            this.Controls.Add(this.lbl97);
            this.Controls.Add(this.lbl89);
            this.Controls.Add(this.lbl88);
            this.Controls.Add(this.lbl87);
            this.Controls.Add(this.lbl79);
            this.Controls.Add(this.lbl78);
            this.Controls.Add(this.lbl77);
            this.Controls.Add(this.lbl69);
            this.Controls.Add(this.lbl68);
            this.Controls.Add(this.lbl67);
            this.Controls.Add(this.lbl59);
            this.Controls.Add(this.lbl58);
            this.Controls.Add(this.lbl57);
            this.Controls.Add(this.lbl49);
            this.Controls.Add(this.lbl48);
            this.Controls.Add(this.lbl47);
            this.Controls.Add(this.lbl39);
            this.Controls.Add(this.lbl38);
            this.Controls.Add(this.lbl37);
            this.Controls.Add(this.lbl29);
            this.Controls.Add(this.lbl28);
            this.Controls.Add(this.lbl27);
            this.Controls.Add(this.lbl19);
            this.Controls.Add(this.lbl18);
            this.Controls.Add(this.lbl17);
            this.Controls.Add(this.lbl96);
            this.Controls.Add(this.lbl95);
            this.Controls.Add(this.lbl94);
            this.Controls.Add(this.lbl86);
            this.Controls.Add(this.lbl85);
            this.Controls.Add(this.lbl84);
            this.Controls.Add(this.lbl76);
            this.Controls.Add(this.lbl75);
            this.Controls.Add(this.lbl74);
            this.Controls.Add(this.lbl66);
            this.Controls.Add(this.lbl65);
            this.Controls.Add(this.lbl64);
            this.Controls.Add(this.lbl56);
            this.Controls.Add(this.lbl55);
            this.Controls.Add(this.lbl54);
            this.Controls.Add(this.lbl46);
            this.Controls.Add(this.lbl45);
            this.Controls.Add(this.lbl44);
            this.Controls.Add(this.lbl36);
            this.Controls.Add(this.lbl35);
            this.Controls.Add(this.lbl34);
            this.Controls.Add(this.lbl26);
            this.Controls.Add(this.lbl25);
            this.Controls.Add(this.lbl24);
            this.Controls.Add(this.lbl16);
            this.Controls.Add(this.lbl15);
            this.Controls.Add(this.lbl14);
            this.Controls.Add(this.lbl93);
            this.Controls.Add(this.lbl92);
            this.Controls.Add(this.lbl91);
            this.Controls.Add(this.lbl83);
            this.Controls.Add(this.lbl82);
            this.Controls.Add(this.lbl81);
            this.Controls.Add(this.lbl73);
            this.Controls.Add(this.lbl72);
            this.Controls.Add(this.lbl71);
            this.Controls.Add(this.lbl63);
            this.Controls.Add(this.lbl62);
            this.Controls.Add(this.lbl61);
            this.Controls.Add(this.lbl53);
            this.Controls.Add(this.lbl52);
            this.Controls.Add(this.lbl51);
            this.Controls.Add(this.lbl43);
            this.Controls.Add(this.lbl42);
            this.Controls.Add(this.lbl41);
            this.Controls.Add(this.lbl33);
            this.Controls.Add(this.lbl32);
            this.Controls.Add(this.lbl31);
            this.Controls.Add(this.lbl23);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximumSize = new System.Drawing.Size(1046, 672);
            this.MinimumSize = new System.Drawing.Size(1046, 672);
            this.Name = "N9";
            this.Text = "N9";
            this.Load += new System.EventHandler(this.N9_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox lbl99;
        private System.Windows.Forms.TextBox lbl98;
        private System.Windows.Forms.TextBox lbl97;
        private System.Windows.Forms.TextBox lbl89;
        private System.Windows.Forms.TextBox lbl88;
        private System.Windows.Forms.TextBox lbl87;
        private System.Windows.Forms.TextBox lbl79;
        private System.Windows.Forms.TextBox lbl78;
        private System.Windows.Forms.TextBox lbl77;
        private System.Windows.Forms.TextBox lbl69;
        private System.Windows.Forms.TextBox lbl68;
        private System.Windows.Forms.TextBox lbl67;
        private System.Windows.Forms.TextBox lbl59;
        private System.Windows.Forms.TextBox lbl58;
        private System.Windows.Forms.TextBox lbl57;
        private System.Windows.Forms.TextBox lbl49;
        private System.Windows.Forms.TextBox lbl48;
        private System.Windows.Forms.TextBox lbl47;
        private System.Windows.Forms.TextBox lbl39;
        private System.Windows.Forms.TextBox lbl38;
        private System.Windows.Forms.TextBox lbl37;
        private System.Windows.Forms.TextBox lbl29;
        private System.Windows.Forms.TextBox lbl28;
        private System.Windows.Forms.TextBox lbl27;
        private System.Windows.Forms.TextBox lbl19;
        private System.Windows.Forms.TextBox lbl18;
        private System.Windows.Forms.TextBox lbl17;
        private System.Windows.Forms.TextBox lbl96;
        private System.Windows.Forms.TextBox lbl95;
        private System.Windows.Forms.TextBox lbl94;
        private System.Windows.Forms.TextBox lbl86;
        private System.Windows.Forms.TextBox lbl85;
        private System.Windows.Forms.TextBox lbl84;
        private System.Windows.Forms.TextBox lbl76;
        private System.Windows.Forms.TextBox lbl75;
        private System.Windows.Forms.TextBox lbl74;
        private System.Windows.Forms.TextBox lbl66;
        private System.Windows.Forms.TextBox lbl65;
        private System.Windows.Forms.TextBox lbl64;
        private System.Windows.Forms.TextBox lbl56;
        private System.Windows.Forms.TextBox lbl55;
        private System.Windows.Forms.TextBox lbl54;
        private System.Windows.Forms.TextBox lbl46;
        private System.Windows.Forms.TextBox lbl45;
        private System.Windows.Forms.TextBox lbl44;
        private System.Windows.Forms.TextBox lbl36;
        private System.Windows.Forms.TextBox lbl35;
        private System.Windows.Forms.TextBox lbl34;
        private System.Windows.Forms.TextBox lbl26;
        private System.Windows.Forms.TextBox lbl25;
        private System.Windows.Forms.TextBox lbl24;
        private System.Windows.Forms.TextBox lbl16;
        private System.Windows.Forms.TextBox lbl15;
        private System.Windows.Forms.TextBox lbl14;
        private System.Windows.Forms.TextBox lbl93;
        private System.Windows.Forms.TextBox lbl92;
        private System.Windows.Forms.TextBox lbl91;
        private System.Windows.Forms.TextBox lbl83;
        private System.Windows.Forms.TextBox lbl82;
        private System.Windows.Forms.TextBox lbl81;
        private System.Windows.Forms.TextBox lbl73;
        private System.Windows.Forms.TextBox lbl72;
        private System.Windows.Forms.TextBox lbl71;
        private System.Windows.Forms.TextBox lbl63;
        private System.Windows.Forms.TextBox lbl62;
        private System.Windows.Forms.TextBox lbl61;
        private System.Windows.Forms.TextBox lbl53;
        private System.Windows.Forms.TextBox lbl52;
        private System.Windows.Forms.TextBox lbl51;
        private System.Windows.Forms.TextBox lbl43;
        private System.Windows.Forms.TextBox lbl42;
        private System.Windows.Forms.TextBox lbl41;
        private System.Windows.Forms.TextBox lbl33;
        private System.Windows.Forms.TextBox lbl32;
        private System.Windows.Forms.TextBox lbl31;
        private System.Windows.Forms.TextBox lbl23;
        private System.Windows.Forms.TextBox lbl22;
        private System.Windows.Forms.TextBox lbl21;
        private System.Windows.Forms.TextBox lbl13;
        private System.Windows.Forms.TextBox lbl12;
        private System.Windows.Forms.TextBox lbl11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblClear;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblBack;
        private System.Windows.Forms.Label Check;
    }
}