﻿namespace SudokuN.View
{
    partial class N11a
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClear = new System.Windows.Forms.Button();
            this.btnGo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lbl1111 = new System.Windows.Forms.TextBox();
            this.lbl1011 = new System.Windows.Forms.TextBox();
            this.lbl0911 = new System.Windows.Forms.TextBox();
            this.lbl0811 = new System.Windows.Forms.TextBox();
            this.lbl0711 = new System.Windows.Forms.TextBox();
            this.lbl0611 = new System.Windows.Forms.TextBox();
            this.lbl0511 = new System.Windows.Forms.TextBox();
            this.lbl0411 = new System.Windows.Forms.TextBox();
            this.lbl0311 = new System.Windows.Forms.TextBox();
            this.lbl0211 = new System.Windows.Forms.TextBox();
            this.lbl0111 = new System.Windows.Forms.TextBox();
            this.lbl1110 = new System.Windows.Forms.TextBox();
            this.lbl1109 = new System.Windows.Forms.TextBox();
            this.lbl1108 = new System.Windows.Forms.TextBox();
            this.lbl1107 = new System.Windows.Forms.TextBox();
            this.lbl1106 = new System.Windows.Forms.TextBox();
            this.lbl1105 = new System.Windows.Forms.TextBox();
            this.lbl1104 = new System.Windows.Forms.TextBox();
            this.lbl1103 = new System.Windows.Forms.TextBox();
            this.lbl1102 = new System.Windows.Forms.TextBox();
            this.lbl1101 = new System.Windows.Forms.TextBox();
            this.lbl1010 = new System.Windows.Forms.TextBox();
            this.lbl1009 = new System.Windows.Forms.TextBox();
            this.lbl1008 = new System.Windows.Forms.TextBox();
            this.lbl1007 = new System.Windows.Forms.TextBox();
            this.lbl1006 = new System.Windows.Forms.TextBox();
            this.lbl1005 = new System.Windows.Forms.TextBox();
            this.lbl1004 = new System.Windows.Forms.TextBox();
            this.lbl1003 = new System.Windows.Forms.TextBox();
            this.lbl1002 = new System.Windows.Forms.TextBox();
            this.lbl1001 = new System.Windows.Forms.TextBox();
            this.lbl0910 = new System.Windows.Forms.TextBox();
            this.lbl0909 = new System.Windows.Forms.TextBox();
            this.lbl0908 = new System.Windows.Forms.TextBox();
            this.lbl0907 = new System.Windows.Forms.TextBox();
            this.lbl0906 = new System.Windows.Forms.TextBox();
            this.lbl0905 = new System.Windows.Forms.TextBox();
            this.lbl0904 = new System.Windows.Forms.TextBox();
            this.lbl0903 = new System.Windows.Forms.TextBox();
            this.lbl0902 = new System.Windows.Forms.TextBox();
            this.lbl0901 = new System.Windows.Forms.TextBox();
            this.lbl0810 = new System.Windows.Forms.TextBox();
            this.lbl0710 = new System.Windows.Forms.TextBox();
            this.lbl0610 = new System.Windows.Forms.TextBox();
            this.lbl0510 = new System.Windows.Forms.TextBox();
            this.lbl0410 = new System.Windows.Forms.TextBox();
            this.lbl0310 = new System.Windows.Forms.TextBox();
            this.lbl0210 = new System.Windows.Forms.TextBox();
            this.lbl0110 = new System.Windows.Forms.TextBox();
            this.lbl0809 = new System.Windows.Forms.TextBox();
            this.lbl0709 = new System.Windows.Forms.TextBox();
            this.lbl0609 = new System.Windows.Forms.TextBox();
            this.lbl0509 = new System.Windows.Forms.TextBox();
            this.lbl0409 = new System.Windows.Forms.TextBox();
            this.lbl0309 = new System.Windows.Forms.TextBox();
            this.lbl0209 = new System.Windows.Forms.TextBox();
            this.lbl0109 = new System.Windows.Forms.TextBox();
            this.lbl0808 = new System.Windows.Forms.TextBox();
            this.lbl0807 = new System.Windows.Forms.TextBox();
            this.lbl0806 = new System.Windows.Forms.TextBox();
            this.lbl0805 = new System.Windows.Forms.TextBox();
            this.lbl0708 = new System.Windows.Forms.TextBox();
            this.lbl0707 = new System.Windows.Forms.TextBox();
            this.lbl0706 = new System.Windows.Forms.TextBox();
            this.lbl0705 = new System.Windows.Forms.TextBox();
            this.lbl0804 = new System.Windows.Forms.TextBox();
            this.lbl0803 = new System.Windows.Forms.TextBox();
            this.lbl0802 = new System.Windows.Forms.TextBox();
            this.lbl0801 = new System.Windows.Forms.TextBox();
            this.lbl0704 = new System.Windows.Forms.TextBox();
            this.lbl0703 = new System.Windows.Forms.TextBox();
            this.lbl0702 = new System.Windows.Forms.TextBox();
            this.lbl0701 = new System.Windows.Forms.TextBox();
            this.lbl0608 = new System.Windows.Forms.TextBox();
            this.lbl0607 = new System.Windows.Forms.TextBox();
            this.lbl0606 = new System.Windows.Forms.TextBox();
            this.lbl0605 = new System.Windows.Forms.TextBox();
            this.lbl0508 = new System.Windows.Forms.TextBox();
            this.lbl0507 = new System.Windows.Forms.TextBox();
            this.lbl0506 = new System.Windows.Forms.TextBox();
            this.lbl0505 = new System.Windows.Forms.TextBox();
            this.lbl0408 = new System.Windows.Forms.TextBox();
            this.lbl0407 = new System.Windows.Forms.TextBox();
            this.lbl0406 = new System.Windows.Forms.TextBox();
            this.lbl0405 = new System.Windows.Forms.TextBox();
            this.lbl0308 = new System.Windows.Forms.TextBox();
            this.lbl0307 = new System.Windows.Forms.TextBox();
            this.lbl0306 = new System.Windows.Forms.TextBox();
            this.lbl0305 = new System.Windows.Forms.TextBox();
            this.lbl0208 = new System.Windows.Forms.TextBox();
            this.lbl0207 = new System.Windows.Forms.TextBox();
            this.lbl0206 = new System.Windows.Forms.TextBox();
            this.lbl0205 = new System.Windows.Forms.TextBox();
            this.lbl0108 = new System.Windows.Forms.TextBox();
            this.lbl0107 = new System.Windows.Forms.TextBox();
            this.lbl0106 = new System.Windows.Forms.TextBox();
            this.lbl0105 = new System.Windows.Forms.TextBox();
            this.lbl0604 = new System.Windows.Forms.TextBox();
            this.lbl0603 = new System.Windows.Forms.TextBox();
            this.lbl0602 = new System.Windows.Forms.TextBox();
            this.lbl0601 = new System.Windows.Forms.TextBox();
            this.lbl0504 = new System.Windows.Forms.TextBox();
            this.lbl0503 = new System.Windows.Forms.TextBox();
            this.lbl0502 = new System.Windows.Forms.TextBox();
            this.lbl0501 = new System.Windows.Forms.TextBox();
            this.lbl0404 = new System.Windows.Forms.TextBox();
            this.lbl0403 = new System.Windows.Forms.TextBox();
            this.lbl0402 = new System.Windows.Forms.TextBox();
            this.lbl0401 = new System.Windows.Forms.TextBox();
            this.lbl0304 = new System.Windows.Forms.TextBox();
            this.lbl0303 = new System.Windows.Forms.TextBox();
            this.lbl0302 = new System.Windows.Forms.TextBox();
            this.lbl0301 = new System.Windows.Forms.TextBox();
            this.lbl0204 = new System.Windows.Forms.TextBox();
            this.lbl0203 = new System.Windows.Forms.TextBox();
            this.lbl0202 = new System.Windows.Forms.TextBox();
            this.lbl0201 = new System.Windows.Forms.TextBox();
            this.lbl0104 = new System.Windows.Forms.TextBox();
            this.lbl0103 = new System.Windows.Forms.TextBox();
            this.lbl0102 = new System.Windows.Forms.TextBox();
            this.lbl0101 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Goldenrod;
            this.btnClear.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(310, 586);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(94, 35);
            this.btnClear.TabIndex = 998;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            // 
            // btnGo
            // 
            this.btnGo.BackColor = System.Drawing.Color.Goldenrod;
            this.btnGo.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGo.ForeColor = System.Drawing.Color.White;
            this.btnGo.Location = new System.Drawing.Point(210, 586);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(94, 35);
            this.btnGo.TabIndex = 997;
            this.btnGo.Text = "Go";
            this.btnGo.UseVisualStyleBackColor = false;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(244, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 45);
            this.label1.TabIndex = 996;
            this.label1.Text = "11x11";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.White;
            this.btnBack.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnBack.Location = new System.Drawing.Point(-1, -1);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(93, 35);
            this.btnBack.TabIndex = 995;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            // 
            // lbl1111
            // 
            this.lbl1111.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1111.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1111.ForeColor = System.Drawing.Color.White;
            this.lbl1111.Location = new System.Drawing.Point(538, 533);
            this.lbl1111.Multiline = true;
            this.lbl1111.Name = "lbl1111";
            this.lbl1111.Size = new System.Drawing.Size(44, 40);
            this.lbl1111.TabIndex = 994;
            this.lbl1111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1011
            // 
            this.lbl1011.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1011.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1011.ForeColor = System.Drawing.Color.White;
            this.lbl1011.Location = new System.Drawing.Point(538, 487);
            this.lbl1011.Multiline = true;
            this.lbl1011.Name = "lbl1011";
            this.lbl1011.Size = new System.Drawing.Size(44, 40);
            this.lbl1011.TabIndex = 993;
            this.lbl1011.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0911
            // 
            this.lbl0911.BackColor = System.Drawing.Color.Crimson;
            this.lbl0911.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0911.ForeColor = System.Drawing.Color.White;
            this.lbl0911.Location = new System.Drawing.Point(538, 441);
            this.lbl0911.Multiline = true;
            this.lbl0911.Name = "lbl0911";
            this.lbl0911.Size = new System.Drawing.Size(44, 40);
            this.lbl0911.TabIndex = 992;
            this.lbl0911.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0811
            // 
            this.lbl0811.BackColor = System.Drawing.Color.Gray;
            this.lbl0811.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0811.ForeColor = System.Drawing.Color.White;
            this.lbl0811.Location = new System.Drawing.Point(538, 395);
            this.lbl0811.Multiline = true;
            this.lbl0811.Name = "lbl0811";
            this.lbl0811.Size = new System.Drawing.Size(44, 40);
            this.lbl0811.TabIndex = 991;
            this.lbl0811.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0711
            // 
            this.lbl0711.BackColor = System.Drawing.Color.Gray;
            this.lbl0711.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0711.ForeColor = System.Drawing.Color.White;
            this.lbl0711.Location = new System.Drawing.Point(538, 349);
            this.lbl0711.Multiline = true;
            this.lbl0711.Name = "lbl0711";
            this.lbl0711.Size = new System.Drawing.Size(44, 40);
            this.lbl0711.TabIndex = 990;
            this.lbl0711.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0611
            // 
            this.lbl0611.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0611.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0611.ForeColor = System.Drawing.Color.White;
            this.lbl0611.Location = new System.Drawing.Point(538, 303);
            this.lbl0611.Multiline = true;
            this.lbl0611.Name = "lbl0611";
            this.lbl0611.Size = new System.Drawing.Size(44, 40);
            this.lbl0611.TabIndex = 989;
            this.lbl0611.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0511
            // 
            this.lbl0511.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0511.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0511.ForeColor = System.Drawing.Color.White;
            this.lbl0511.Location = new System.Drawing.Point(538, 257);
            this.lbl0511.Multiline = true;
            this.lbl0511.Name = "lbl0511";
            this.lbl0511.Size = new System.Drawing.Size(44, 40);
            this.lbl0511.TabIndex = 988;
            this.lbl0511.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0411
            // 
            this.lbl0411.BackColor = System.Drawing.Color.Gray;
            this.lbl0411.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0411.ForeColor = System.Drawing.Color.White;
            this.lbl0411.Location = new System.Drawing.Point(538, 211);
            this.lbl0411.Multiline = true;
            this.lbl0411.Name = "lbl0411";
            this.lbl0411.Size = new System.Drawing.Size(44, 40);
            this.lbl0411.TabIndex = 987;
            this.lbl0411.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0311
            // 
            this.lbl0311.BackColor = System.Drawing.Color.Gray;
            this.lbl0311.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0311.ForeColor = System.Drawing.Color.White;
            this.lbl0311.Location = new System.Drawing.Point(538, 165);
            this.lbl0311.Multiline = true;
            this.lbl0311.Name = "lbl0311";
            this.lbl0311.Size = new System.Drawing.Size(44, 40);
            this.lbl0311.TabIndex = 986;
            this.lbl0311.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0211
            // 
            this.lbl0211.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0211.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0211.ForeColor = System.Drawing.Color.White;
            this.lbl0211.Location = new System.Drawing.Point(538, 119);
            this.lbl0211.Multiline = true;
            this.lbl0211.Name = "lbl0211";
            this.lbl0211.Size = new System.Drawing.Size(44, 40);
            this.lbl0211.TabIndex = 985;
            this.lbl0211.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0111
            // 
            this.lbl0111.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0111.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0111.ForeColor = System.Drawing.Color.White;
            this.lbl0111.Location = new System.Drawing.Point(538, 73);
            this.lbl0111.Multiline = true;
            this.lbl0111.Name = "lbl0111";
            this.lbl0111.Size = new System.Drawing.Size(44, 40);
            this.lbl0111.TabIndex = 984;
            this.lbl0111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1110
            // 
            this.lbl1110.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1110.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1110.ForeColor = System.Drawing.Color.White;
            this.lbl1110.Location = new System.Drawing.Point(488, 533);
            this.lbl1110.Multiline = true;
            this.lbl1110.Name = "lbl1110";
            this.lbl1110.Size = new System.Drawing.Size(44, 40);
            this.lbl1110.TabIndex = 983;
            this.lbl1110.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1109
            // 
            this.lbl1109.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1109.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1109.ForeColor = System.Drawing.Color.White;
            this.lbl1109.Location = new System.Drawing.Point(438, 533);
            this.lbl1109.Multiline = true;
            this.lbl1109.Name = "lbl1109";
            this.lbl1109.Size = new System.Drawing.Size(44, 40);
            this.lbl1109.TabIndex = 982;
            this.lbl1109.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1108
            // 
            this.lbl1108.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1108.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1108.ForeColor = System.Drawing.Color.White;
            this.lbl1108.Location = new System.Drawing.Point(388, 533);
            this.lbl1108.Multiline = true;
            this.lbl1108.Name = "lbl1108";
            this.lbl1108.Size = new System.Drawing.Size(44, 40);
            this.lbl1108.TabIndex = 981;
            this.lbl1108.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1107
            // 
            this.lbl1107.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1107.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1107.ForeColor = System.Drawing.Color.White;
            this.lbl1107.Location = new System.Drawing.Point(338, 533);
            this.lbl1107.Multiline = true;
            this.lbl1107.Name = "lbl1107";
            this.lbl1107.Size = new System.Drawing.Size(44, 40);
            this.lbl1107.TabIndex = 980;
            this.lbl1107.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1106
            // 
            this.lbl1106.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1106.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1106.ForeColor = System.Drawing.Color.White;
            this.lbl1106.Location = new System.Drawing.Point(288, 533);
            this.lbl1106.Multiline = true;
            this.lbl1106.Name = "lbl1106";
            this.lbl1106.Size = new System.Drawing.Size(44, 40);
            this.lbl1106.TabIndex = 979;
            this.lbl1106.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1105
            // 
            this.lbl1105.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1105.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1105.ForeColor = System.Drawing.Color.White;
            this.lbl1105.Location = new System.Drawing.Point(238, 533);
            this.lbl1105.Multiline = true;
            this.lbl1105.Name = "lbl1105";
            this.lbl1105.Size = new System.Drawing.Size(44, 40);
            this.lbl1105.TabIndex = 978;
            this.lbl1105.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1104
            // 
            this.lbl1104.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1104.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1104.ForeColor = System.Drawing.Color.White;
            this.lbl1104.Location = new System.Drawing.Point(188, 533);
            this.lbl1104.Multiline = true;
            this.lbl1104.Name = "lbl1104";
            this.lbl1104.Size = new System.Drawing.Size(44, 40);
            this.lbl1104.TabIndex = 977;
            this.lbl1104.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1103
            // 
            this.lbl1103.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1103.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1103.ForeColor = System.Drawing.Color.White;
            this.lbl1103.Location = new System.Drawing.Point(138, 533);
            this.lbl1103.Multiline = true;
            this.lbl1103.Name = "lbl1103";
            this.lbl1103.Size = new System.Drawing.Size(44, 40);
            this.lbl1103.TabIndex = 976;
            this.lbl1103.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1102
            // 
            this.lbl1102.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1102.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1102.ForeColor = System.Drawing.Color.White;
            this.lbl1102.Location = new System.Drawing.Point(88, 533);
            this.lbl1102.Multiline = true;
            this.lbl1102.Name = "lbl1102";
            this.lbl1102.Size = new System.Drawing.Size(44, 40);
            this.lbl1102.TabIndex = 975;
            this.lbl1102.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1101
            // 
            this.lbl1101.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1101.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1101.ForeColor = System.Drawing.Color.White;
            this.lbl1101.Location = new System.Drawing.Point(38, 533);
            this.lbl1101.Multiline = true;
            this.lbl1101.Name = "lbl1101";
            this.lbl1101.Size = new System.Drawing.Size(44, 40);
            this.lbl1101.TabIndex = 974;
            this.lbl1101.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1010
            // 
            this.lbl1010.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1010.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1010.ForeColor = System.Drawing.Color.White;
            this.lbl1010.Location = new System.Drawing.Point(488, 487);
            this.lbl1010.Multiline = true;
            this.lbl1010.Name = "lbl1010";
            this.lbl1010.Size = new System.Drawing.Size(44, 40);
            this.lbl1010.TabIndex = 973;
            this.lbl1010.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1009
            // 
            this.lbl1009.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1009.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1009.ForeColor = System.Drawing.Color.White;
            this.lbl1009.Location = new System.Drawing.Point(438, 487);
            this.lbl1009.Multiline = true;
            this.lbl1009.Name = "lbl1009";
            this.lbl1009.Size = new System.Drawing.Size(44, 40);
            this.lbl1009.TabIndex = 972;
            this.lbl1009.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1008
            // 
            this.lbl1008.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl1008.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1008.ForeColor = System.Drawing.Color.White;
            this.lbl1008.Location = new System.Drawing.Point(388, 487);
            this.lbl1008.Multiline = true;
            this.lbl1008.Name = "lbl1008";
            this.lbl1008.Size = new System.Drawing.Size(44, 40);
            this.lbl1008.TabIndex = 971;
            this.lbl1008.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1007
            // 
            this.lbl1007.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1007.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1007.ForeColor = System.Drawing.Color.White;
            this.lbl1007.Location = new System.Drawing.Point(338, 487);
            this.lbl1007.Multiline = true;
            this.lbl1007.Name = "lbl1007";
            this.lbl1007.Size = new System.Drawing.Size(44, 40);
            this.lbl1007.TabIndex = 970;
            this.lbl1007.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1006
            // 
            this.lbl1006.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1006.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1006.ForeColor = System.Drawing.Color.White;
            this.lbl1006.Location = new System.Drawing.Point(288, 487);
            this.lbl1006.Multiline = true;
            this.lbl1006.Name = "lbl1006";
            this.lbl1006.Size = new System.Drawing.Size(44, 40);
            this.lbl1006.TabIndex = 969;
            this.lbl1006.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1005
            // 
            this.lbl1005.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl1005.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1005.ForeColor = System.Drawing.Color.White;
            this.lbl1005.Location = new System.Drawing.Point(238, 487);
            this.lbl1005.Multiline = true;
            this.lbl1005.Name = "lbl1005";
            this.lbl1005.Size = new System.Drawing.Size(44, 40);
            this.lbl1005.TabIndex = 968;
            this.lbl1005.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1004
            // 
            this.lbl1004.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1004.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1004.ForeColor = System.Drawing.Color.White;
            this.lbl1004.Location = new System.Drawing.Point(188, 487);
            this.lbl1004.Multiline = true;
            this.lbl1004.Name = "lbl1004";
            this.lbl1004.Size = new System.Drawing.Size(44, 40);
            this.lbl1004.TabIndex = 967;
            this.lbl1004.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1003
            // 
            this.lbl1003.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1003.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1003.ForeColor = System.Drawing.Color.White;
            this.lbl1003.Location = new System.Drawing.Point(138, 487);
            this.lbl1003.Multiline = true;
            this.lbl1003.Name = "lbl1003";
            this.lbl1003.Size = new System.Drawing.Size(44, 40);
            this.lbl1003.TabIndex = 966;
            this.lbl1003.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1002
            // 
            this.lbl1002.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1002.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1002.ForeColor = System.Drawing.Color.White;
            this.lbl1002.Location = new System.Drawing.Point(88, 487);
            this.lbl1002.Multiline = true;
            this.lbl1002.Name = "lbl1002";
            this.lbl1002.Size = new System.Drawing.Size(44, 40);
            this.lbl1002.TabIndex = 965;
            this.lbl1002.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl1001
            // 
            this.lbl1001.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl1001.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1001.ForeColor = System.Drawing.Color.White;
            this.lbl1001.Location = new System.Drawing.Point(38, 487);
            this.lbl1001.Multiline = true;
            this.lbl1001.Name = "lbl1001";
            this.lbl1001.Size = new System.Drawing.Size(44, 40);
            this.lbl1001.TabIndex = 964;
            this.lbl1001.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0910
            // 
            this.lbl0910.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl0910.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0910.ForeColor = System.Drawing.Color.White;
            this.lbl0910.Location = new System.Drawing.Point(488, 441);
            this.lbl0910.Multiline = true;
            this.lbl0910.Name = "lbl0910";
            this.lbl0910.Size = new System.Drawing.Size(44, 40);
            this.lbl0910.TabIndex = 963;
            this.lbl0910.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0909
            // 
            this.lbl0909.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl0909.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0909.ForeColor = System.Drawing.Color.White;
            this.lbl0909.Location = new System.Drawing.Point(438, 441);
            this.lbl0909.Multiline = true;
            this.lbl0909.Name = "lbl0909";
            this.lbl0909.Size = new System.Drawing.Size(44, 40);
            this.lbl0909.TabIndex = 962;
            this.lbl0909.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0908
            // 
            this.lbl0908.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl0908.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0908.ForeColor = System.Drawing.Color.White;
            this.lbl0908.Location = new System.Drawing.Point(388, 441);
            this.lbl0908.Multiline = true;
            this.lbl0908.Name = "lbl0908";
            this.lbl0908.Size = new System.Drawing.Size(44, 40);
            this.lbl0908.TabIndex = 961;
            this.lbl0908.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0907
            // 
            this.lbl0907.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl0907.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0907.ForeColor = System.Drawing.Color.White;
            this.lbl0907.Location = new System.Drawing.Point(338, 441);
            this.lbl0907.Multiline = true;
            this.lbl0907.Name = "lbl0907";
            this.lbl0907.Size = new System.Drawing.Size(44, 40);
            this.lbl0907.TabIndex = 960;
            this.lbl0907.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0906
            // 
            this.lbl0906.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl0906.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0906.ForeColor = System.Drawing.Color.White;
            this.lbl0906.Location = new System.Drawing.Point(288, 441);
            this.lbl0906.Multiline = true;
            this.lbl0906.Name = "lbl0906";
            this.lbl0906.Size = new System.Drawing.Size(44, 40);
            this.lbl0906.TabIndex = 959;
            this.lbl0906.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0905
            // 
            this.lbl0905.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lbl0905.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0905.ForeColor = System.Drawing.Color.White;
            this.lbl0905.Location = new System.Drawing.Point(238, 441);
            this.lbl0905.Multiline = true;
            this.lbl0905.Name = "lbl0905";
            this.lbl0905.Size = new System.Drawing.Size(44, 40);
            this.lbl0905.TabIndex = 958;
            this.lbl0905.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0904
            // 
            this.lbl0904.BackColor = System.Drawing.Color.DarkOrchid;
            this.lbl0904.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0904.ForeColor = System.Drawing.Color.White;
            this.lbl0904.Location = new System.Drawing.Point(188, 441);
            this.lbl0904.Multiline = true;
            this.lbl0904.Name = "lbl0904";
            this.lbl0904.Size = new System.Drawing.Size(44, 40);
            this.lbl0904.TabIndex = 957;
            this.lbl0904.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0903
            // 
            this.lbl0903.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl0903.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0903.ForeColor = System.Drawing.Color.White;
            this.lbl0903.Location = new System.Drawing.Point(138, 441);
            this.lbl0903.Multiline = true;
            this.lbl0903.Name = "lbl0903";
            this.lbl0903.Size = new System.Drawing.Size(44, 40);
            this.lbl0903.TabIndex = 956;
            this.lbl0903.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0902
            // 
            this.lbl0902.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl0902.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0902.ForeColor = System.Drawing.Color.White;
            this.lbl0902.Location = new System.Drawing.Point(88, 441);
            this.lbl0902.Multiline = true;
            this.lbl0902.Name = "lbl0902";
            this.lbl0902.Size = new System.Drawing.Size(44, 40);
            this.lbl0902.TabIndex = 955;
            this.lbl0902.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0901
            // 
            this.lbl0901.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lbl0901.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0901.ForeColor = System.Drawing.Color.White;
            this.lbl0901.Location = new System.Drawing.Point(38, 441);
            this.lbl0901.Multiline = true;
            this.lbl0901.Name = "lbl0901";
            this.lbl0901.Size = new System.Drawing.Size(44, 40);
            this.lbl0901.TabIndex = 954;
            this.lbl0901.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0810
            // 
            this.lbl0810.BackColor = System.Drawing.Color.Gray;
            this.lbl0810.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0810.ForeColor = System.Drawing.Color.White;
            this.lbl0810.Location = new System.Drawing.Point(488, 395);
            this.lbl0810.Multiline = true;
            this.lbl0810.Name = "lbl0810";
            this.lbl0810.Size = new System.Drawing.Size(44, 40);
            this.lbl0810.TabIndex = 953;
            this.lbl0810.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0710
            // 
            this.lbl0710.BackColor = System.Drawing.Color.Gray;
            this.lbl0710.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0710.ForeColor = System.Drawing.Color.White;
            this.lbl0710.Location = new System.Drawing.Point(488, 349);
            this.lbl0710.Multiline = true;
            this.lbl0710.Name = "lbl0710";
            this.lbl0710.Size = new System.Drawing.Size(44, 40);
            this.lbl0710.TabIndex = 952;
            this.lbl0710.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0610
            // 
            this.lbl0610.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0610.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0610.ForeColor = System.Drawing.Color.White;
            this.lbl0610.Location = new System.Drawing.Point(488, 303);
            this.lbl0610.Multiline = true;
            this.lbl0610.Name = "lbl0610";
            this.lbl0610.Size = new System.Drawing.Size(44, 40);
            this.lbl0610.TabIndex = 951;
            this.lbl0610.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0510
            // 
            this.lbl0510.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0510.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0510.ForeColor = System.Drawing.Color.White;
            this.lbl0510.Location = new System.Drawing.Point(488, 257);
            this.lbl0510.Multiline = true;
            this.lbl0510.Name = "lbl0510";
            this.lbl0510.Size = new System.Drawing.Size(44, 40);
            this.lbl0510.TabIndex = 950;
            this.lbl0510.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0410
            // 
            this.lbl0410.BackColor = System.Drawing.Color.Gray;
            this.lbl0410.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0410.ForeColor = System.Drawing.Color.White;
            this.lbl0410.Location = new System.Drawing.Point(488, 211);
            this.lbl0410.Multiline = true;
            this.lbl0410.Name = "lbl0410";
            this.lbl0410.Size = new System.Drawing.Size(44, 40);
            this.lbl0410.TabIndex = 949;
            this.lbl0410.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0310
            // 
            this.lbl0310.BackColor = System.Drawing.Color.Gray;
            this.lbl0310.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0310.ForeColor = System.Drawing.Color.White;
            this.lbl0310.Location = new System.Drawing.Point(488, 165);
            this.lbl0310.Multiline = true;
            this.lbl0310.Name = "lbl0310";
            this.lbl0310.Size = new System.Drawing.Size(44, 40);
            this.lbl0310.TabIndex = 948;
            this.lbl0310.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0210
            // 
            this.lbl0210.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0210.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0210.ForeColor = System.Drawing.Color.White;
            this.lbl0210.Location = new System.Drawing.Point(488, 119);
            this.lbl0210.Multiline = true;
            this.lbl0210.Name = "lbl0210";
            this.lbl0210.Size = new System.Drawing.Size(44, 40);
            this.lbl0210.TabIndex = 947;
            this.lbl0210.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0110
            // 
            this.lbl0110.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0110.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0110.ForeColor = System.Drawing.Color.White;
            this.lbl0110.Location = new System.Drawing.Point(488, 73);
            this.lbl0110.Multiline = true;
            this.lbl0110.Name = "lbl0110";
            this.lbl0110.Size = new System.Drawing.Size(44, 40);
            this.lbl0110.TabIndex = 946;
            this.lbl0110.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0809
            // 
            this.lbl0809.BackColor = System.Drawing.Color.Gray;
            this.lbl0809.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0809.ForeColor = System.Drawing.Color.White;
            this.lbl0809.Location = new System.Drawing.Point(438, 395);
            this.lbl0809.Multiline = true;
            this.lbl0809.Name = "lbl0809";
            this.lbl0809.Size = new System.Drawing.Size(44, 40);
            this.lbl0809.TabIndex = 945;
            this.lbl0809.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0709
            // 
            this.lbl0709.BackColor = System.Drawing.Color.Gray;
            this.lbl0709.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0709.ForeColor = System.Drawing.Color.White;
            this.lbl0709.Location = new System.Drawing.Point(438, 349);
            this.lbl0709.Multiline = true;
            this.lbl0709.Name = "lbl0709";
            this.lbl0709.Size = new System.Drawing.Size(44, 40);
            this.lbl0709.TabIndex = 944;
            this.lbl0709.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0609
            // 
            this.lbl0609.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0609.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0609.ForeColor = System.Drawing.Color.White;
            this.lbl0609.Location = new System.Drawing.Point(438, 303);
            this.lbl0609.Multiline = true;
            this.lbl0609.Name = "lbl0609";
            this.lbl0609.Size = new System.Drawing.Size(44, 40);
            this.lbl0609.TabIndex = 943;
            this.lbl0609.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0509
            // 
            this.lbl0509.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0509.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0509.ForeColor = System.Drawing.Color.White;
            this.lbl0509.Location = new System.Drawing.Point(438, 257);
            this.lbl0509.Multiline = true;
            this.lbl0509.Name = "lbl0509";
            this.lbl0509.Size = new System.Drawing.Size(44, 40);
            this.lbl0509.TabIndex = 942;
            this.lbl0509.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0409
            // 
            this.lbl0409.BackColor = System.Drawing.Color.Gray;
            this.lbl0409.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0409.ForeColor = System.Drawing.Color.White;
            this.lbl0409.Location = new System.Drawing.Point(438, 211);
            this.lbl0409.Multiline = true;
            this.lbl0409.Name = "lbl0409";
            this.lbl0409.Size = new System.Drawing.Size(44, 40);
            this.lbl0409.TabIndex = 941;
            this.lbl0409.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0309
            // 
            this.lbl0309.BackColor = System.Drawing.Color.Gray;
            this.lbl0309.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0309.ForeColor = System.Drawing.Color.White;
            this.lbl0309.Location = new System.Drawing.Point(438, 165);
            this.lbl0309.Multiline = true;
            this.lbl0309.Name = "lbl0309";
            this.lbl0309.Size = new System.Drawing.Size(44, 40);
            this.lbl0309.TabIndex = 940;
            this.lbl0309.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0209
            // 
            this.lbl0209.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0209.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0209.ForeColor = System.Drawing.Color.White;
            this.lbl0209.Location = new System.Drawing.Point(438, 119);
            this.lbl0209.Multiline = true;
            this.lbl0209.Name = "lbl0209";
            this.lbl0209.Size = new System.Drawing.Size(44, 40);
            this.lbl0209.TabIndex = 939;
            this.lbl0209.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0109
            // 
            this.lbl0109.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0109.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0109.ForeColor = System.Drawing.Color.White;
            this.lbl0109.Location = new System.Drawing.Point(438, 73);
            this.lbl0109.Multiline = true;
            this.lbl0109.Name = "lbl0109";
            this.lbl0109.Size = new System.Drawing.Size(44, 40);
            this.lbl0109.TabIndex = 938;
            this.lbl0109.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0808
            // 
            this.lbl0808.BackColor = System.Drawing.Color.Gray;
            this.lbl0808.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0808.ForeColor = System.Drawing.Color.White;
            this.lbl0808.Location = new System.Drawing.Point(388, 395);
            this.lbl0808.Multiline = true;
            this.lbl0808.Name = "lbl0808";
            this.lbl0808.Size = new System.Drawing.Size(44, 40);
            this.lbl0808.TabIndex = 937;
            this.lbl0808.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0807
            // 
            this.lbl0807.BackColor = System.Drawing.Color.Gray;
            this.lbl0807.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0807.ForeColor = System.Drawing.Color.White;
            this.lbl0807.Location = new System.Drawing.Point(338, 395);
            this.lbl0807.Multiline = true;
            this.lbl0807.Name = "lbl0807";
            this.lbl0807.Size = new System.Drawing.Size(44, 40);
            this.lbl0807.TabIndex = 936;
            this.lbl0807.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0806
            // 
            this.lbl0806.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0806.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0806.ForeColor = System.Drawing.Color.White;
            this.lbl0806.Location = new System.Drawing.Point(288, 395);
            this.lbl0806.Multiline = true;
            this.lbl0806.Name = "lbl0806";
            this.lbl0806.Size = new System.Drawing.Size(44, 40);
            this.lbl0806.TabIndex = 935;
            this.lbl0806.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0805
            // 
            this.lbl0805.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0805.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0805.ForeColor = System.Drawing.Color.White;
            this.lbl0805.Location = new System.Drawing.Point(238, 395);
            this.lbl0805.Multiline = true;
            this.lbl0805.Name = "lbl0805";
            this.lbl0805.Size = new System.Drawing.Size(44, 40);
            this.lbl0805.TabIndex = 934;
            this.lbl0805.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0708
            // 
            this.lbl0708.BackColor = System.Drawing.Color.Gray;
            this.lbl0708.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0708.ForeColor = System.Drawing.Color.White;
            this.lbl0708.Location = new System.Drawing.Point(388, 349);
            this.lbl0708.Multiline = true;
            this.lbl0708.Name = "lbl0708";
            this.lbl0708.Size = new System.Drawing.Size(44, 40);
            this.lbl0708.TabIndex = 933;
            this.lbl0708.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0707
            // 
            this.lbl0707.BackColor = System.Drawing.Color.Gray;
            this.lbl0707.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0707.ForeColor = System.Drawing.Color.White;
            this.lbl0707.Location = new System.Drawing.Point(338, 349);
            this.lbl0707.Multiline = true;
            this.lbl0707.Name = "lbl0707";
            this.lbl0707.Size = new System.Drawing.Size(44, 40);
            this.lbl0707.TabIndex = 932;
            this.lbl0707.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0706
            // 
            this.lbl0706.BackColor = System.Drawing.Color.Gray;
            this.lbl0706.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0706.ForeColor = System.Drawing.Color.White;
            this.lbl0706.Location = new System.Drawing.Point(288, 349);
            this.lbl0706.Multiline = true;
            this.lbl0706.Name = "lbl0706";
            this.lbl0706.Size = new System.Drawing.Size(44, 40);
            this.lbl0706.TabIndex = 931;
            this.lbl0706.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0705
            // 
            this.lbl0705.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0705.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0705.ForeColor = System.Drawing.Color.White;
            this.lbl0705.Location = new System.Drawing.Point(238, 349);
            this.lbl0705.Multiline = true;
            this.lbl0705.Name = "lbl0705";
            this.lbl0705.Size = new System.Drawing.Size(44, 40);
            this.lbl0705.TabIndex = 930;
            this.lbl0705.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0804
            // 
            this.lbl0804.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0804.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0804.ForeColor = System.Drawing.Color.White;
            this.lbl0804.Location = new System.Drawing.Point(188, 395);
            this.lbl0804.Multiline = true;
            this.lbl0804.Name = "lbl0804";
            this.lbl0804.Size = new System.Drawing.Size(44, 40);
            this.lbl0804.TabIndex = 929;
            this.lbl0804.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0803
            // 
            this.lbl0803.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0803.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0803.ForeColor = System.Drawing.Color.White;
            this.lbl0803.Location = new System.Drawing.Point(138, 395);
            this.lbl0803.Multiline = true;
            this.lbl0803.Name = "lbl0803";
            this.lbl0803.Size = new System.Drawing.Size(44, 40);
            this.lbl0803.TabIndex = 928;
            this.lbl0803.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0802
            // 
            this.lbl0802.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0802.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0802.ForeColor = System.Drawing.Color.White;
            this.lbl0802.Location = new System.Drawing.Point(88, 395);
            this.lbl0802.Multiline = true;
            this.lbl0802.Name = "lbl0802";
            this.lbl0802.Size = new System.Drawing.Size(44, 40);
            this.lbl0802.TabIndex = 927;
            this.lbl0802.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0801
            // 
            this.lbl0801.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0801.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0801.ForeColor = System.Drawing.Color.White;
            this.lbl0801.Location = new System.Drawing.Point(38, 395);
            this.lbl0801.Multiline = true;
            this.lbl0801.Name = "lbl0801";
            this.lbl0801.Size = new System.Drawing.Size(44, 40);
            this.lbl0801.TabIndex = 926;
            this.lbl0801.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0704
            // 
            this.lbl0704.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0704.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0704.ForeColor = System.Drawing.Color.White;
            this.lbl0704.Location = new System.Drawing.Point(188, 349);
            this.lbl0704.Multiline = true;
            this.lbl0704.Name = "lbl0704";
            this.lbl0704.Size = new System.Drawing.Size(44, 40);
            this.lbl0704.TabIndex = 925;
            this.lbl0704.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0703
            // 
            this.lbl0703.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0703.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0703.ForeColor = System.Drawing.Color.White;
            this.lbl0703.Location = new System.Drawing.Point(138, 349);
            this.lbl0703.Multiline = true;
            this.lbl0703.Name = "lbl0703";
            this.lbl0703.Size = new System.Drawing.Size(44, 40);
            this.lbl0703.TabIndex = 924;
            this.lbl0703.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0702
            // 
            this.lbl0702.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0702.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0702.ForeColor = System.Drawing.Color.White;
            this.lbl0702.Location = new System.Drawing.Point(88, 349);
            this.lbl0702.Multiline = true;
            this.lbl0702.Name = "lbl0702";
            this.lbl0702.Size = new System.Drawing.Size(44, 40);
            this.lbl0702.TabIndex = 923;
            this.lbl0702.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0701
            // 
            this.lbl0701.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0701.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0701.ForeColor = System.Drawing.Color.White;
            this.lbl0701.Location = new System.Drawing.Point(38, 349);
            this.lbl0701.Multiline = true;
            this.lbl0701.Name = "lbl0701";
            this.lbl0701.Size = new System.Drawing.Size(44, 40);
            this.lbl0701.TabIndex = 922;
            this.lbl0701.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0608
            // 
            this.lbl0608.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0608.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0608.ForeColor = System.Drawing.Color.White;
            this.lbl0608.Location = new System.Drawing.Point(388, 303);
            this.lbl0608.Multiline = true;
            this.lbl0608.Name = "lbl0608";
            this.lbl0608.Size = new System.Drawing.Size(44, 40);
            this.lbl0608.TabIndex = 921;
            this.lbl0608.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0607
            // 
            this.lbl0607.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0607.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0607.ForeColor = System.Drawing.Color.White;
            this.lbl0607.Location = new System.Drawing.Point(338, 303);
            this.lbl0607.Multiline = true;
            this.lbl0607.Name = "lbl0607";
            this.lbl0607.Size = new System.Drawing.Size(44, 40);
            this.lbl0607.TabIndex = 920;
            this.lbl0607.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0606
            // 
            this.lbl0606.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0606.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0606.ForeColor = System.Drawing.Color.White;
            this.lbl0606.Location = new System.Drawing.Point(288, 303);
            this.lbl0606.Multiline = true;
            this.lbl0606.Name = "lbl0606";
            this.lbl0606.Size = new System.Drawing.Size(44, 40);
            this.lbl0606.TabIndex = 919;
            this.lbl0606.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0605
            // 
            this.lbl0605.BackColor = System.Drawing.Color.Gray;
            this.lbl0605.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0605.ForeColor = System.Drawing.Color.White;
            this.lbl0605.Location = new System.Drawing.Point(238, 303);
            this.lbl0605.Multiline = true;
            this.lbl0605.Name = "lbl0605";
            this.lbl0605.Size = new System.Drawing.Size(44, 40);
            this.lbl0605.TabIndex = 918;
            this.lbl0605.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0508
            // 
            this.lbl0508.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0508.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0508.ForeColor = System.Drawing.Color.White;
            this.lbl0508.Location = new System.Drawing.Point(388, 257);
            this.lbl0508.Multiline = true;
            this.lbl0508.Name = "lbl0508";
            this.lbl0508.Size = new System.Drawing.Size(44, 40);
            this.lbl0508.TabIndex = 917;
            this.lbl0508.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0507
            // 
            this.lbl0507.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0507.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0507.ForeColor = System.Drawing.Color.White;
            this.lbl0507.Location = new System.Drawing.Point(338, 257);
            this.lbl0507.Multiline = true;
            this.lbl0507.Name = "lbl0507";
            this.lbl0507.Size = new System.Drawing.Size(44, 40);
            this.lbl0507.TabIndex = 916;
            this.lbl0507.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0506
            // 
            this.lbl0506.BackColor = System.Drawing.Color.Gray;
            this.lbl0506.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0506.ForeColor = System.Drawing.Color.White;
            this.lbl0506.Location = new System.Drawing.Point(288, 257);
            this.lbl0506.Multiline = true;
            this.lbl0506.Name = "lbl0506";
            this.lbl0506.Size = new System.Drawing.Size(44, 40);
            this.lbl0506.TabIndex = 915;
            this.lbl0506.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0505
            // 
            this.lbl0505.BackColor = System.Drawing.Color.Gray;
            this.lbl0505.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0505.ForeColor = System.Drawing.Color.White;
            this.lbl0505.Location = new System.Drawing.Point(238, 257);
            this.lbl0505.Multiline = true;
            this.lbl0505.Name = "lbl0505";
            this.lbl0505.Size = new System.Drawing.Size(44, 40);
            this.lbl0505.TabIndex = 914;
            this.lbl0505.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0408
            // 
            this.lbl0408.BackColor = System.Drawing.Color.Gray;
            this.lbl0408.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0408.ForeColor = System.Drawing.Color.White;
            this.lbl0408.Location = new System.Drawing.Point(388, 211);
            this.lbl0408.Multiline = true;
            this.lbl0408.Name = "lbl0408";
            this.lbl0408.Size = new System.Drawing.Size(44, 40);
            this.lbl0408.TabIndex = 913;
            this.lbl0408.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0407
            // 
            this.lbl0407.BackColor = System.Drawing.Color.Gray;
            this.lbl0407.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0407.ForeColor = System.Drawing.Color.White;
            this.lbl0407.Location = new System.Drawing.Point(338, 211);
            this.lbl0407.Multiline = true;
            this.lbl0407.Name = "lbl0407";
            this.lbl0407.Size = new System.Drawing.Size(44, 40);
            this.lbl0407.TabIndex = 912;
            this.lbl0407.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0406
            // 
            this.lbl0406.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0406.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0406.ForeColor = System.Drawing.Color.White;
            this.lbl0406.Location = new System.Drawing.Point(288, 211);
            this.lbl0406.Multiline = true;
            this.lbl0406.Name = "lbl0406";
            this.lbl0406.Size = new System.Drawing.Size(44, 40);
            this.lbl0406.TabIndex = 911;
            this.lbl0406.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0405
            // 
            this.lbl0405.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0405.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0405.ForeColor = System.Drawing.Color.White;
            this.lbl0405.Location = new System.Drawing.Point(238, 211);
            this.lbl0405.Multiline = true;
            this.lbl0405.Name = "lbl0405";
            this.lbl0405.Size = new System.Drawing.Size(44, 40);
            this.lbl0405.TabIndex = 910;
            this.lbl0405.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0308
            // 
            this.lbl0308.BackColor = System.Drawing.Color.Gray;
            this.lbl0308.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0308.ForeColor = System.Drawing.Color.White;
            this.lbl0308.Location = new System.Drawing.Point(388, 165);
            this.lbl0308.Multiline = true;
            this.lbl0308.Name = "lbl0308";
            this.lbl0308.Size = new System.Drawing.Size(44, 40);
            this.lbl0308.TabIndex = 909;
            this.lbl0308.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0307
            // 
            this.lbl0307.BackColor = System.Drawing.Color.Gray;
            this.lbl0307.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0307.ForeColor = System.Drawing.Color.White;
            this.lbl0307.Location = new System.Drawing.Point(338, 165);
            this.lbl0307.Multiline = true;
            this.lbl0307.Name = "lbl0307";
            this.lbl0307.Size = new System.Drawing.Size(44, 40);
            this.lbl0307.TabIndex = 908;
            this.lbl0307.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0306
            // 
            this.lbl0306.BackColor = System.Drawing.Color.Gray;
            this.lbl0306.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0306.ForeColor = System.Drawing.Color.White;
            this.lbl0306.Location = new System.Drawing.Point(288, 165);
            this.lbl0306.Multiline = true;
            this.lbl0306.Name = "lbl0306";
            this.lbl0306.Size = new System.Drawing.Size(44, 40);
            this.lbl0306.TabIndex = 907;
            this.lbl0306.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0305
            // 
            this.lbl0305.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0305.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0305.ForeColor = System.Drawing.Color.White;
            this.lbl0305.Location = new System.Drawing.Point(238, 165);
            this.lbl0305.Multiline = true;
            this.lbl0305.Name = "lbl0305";
            this.lbl0305.Size = new System.Drawing.Size(44, 40);
            this.lbl0305.TabIndex = 906;
            this.lbl0305.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0208
            // 
            this.lbl0208.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0208.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0208.ForeColor = System.Drawing.Color.White;
            this.lbl0208.Location = new System.Drawing.Point(388, 119);
            this.lbl0208.Multiline = true;
            this.lbl0208.Name = "lbl0208";
            this.lbl0208.Size = new System.Drawing.Size(44, 40);
            this.lbl0208.TabIndex = 905;
            this.lbl0208.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0207
            // 
            this.lbl0207.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0207.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0207.ForeColor = System.Drawing.Color.White;
            this.lbl0207.Location = new System.Drawing.Point(338, 119);
            this.lbl0207.Multiline = true;
            this.lbl0207.Name = "lbl0207";
            this.lbl0207.Size = new System.Drawing.Size(44, 40);
            this.lbl0207.TabIndex = 904;
            this.lbl0207.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0206
            // 
            this.lbl0206.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0206.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0206.ForeColor = System.Drawing.Color.White;
            this.lbl0206.Location = new System.Drawing.Point(288, 119);
            this.lbl0206.Multiline = true;
            this.lbl0206.Name = "lbl0206";
            this.lbl0206.Size = new System.Drawing.Size(44, 40);
            this.lbl0206.TabIndex = 903;
            this.lbl0206.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0205
            // 
            this.lbl0205.BackColor = System.Drawing.Color.Gray;
            this.lbl0205.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0205.ForeColor = System.Drawing.Color.White;
            this.lbl0205.Location = new System.Drawing.Point(238, 119);
            this.lbl0205.Multiline = true;
            this.lbl0205.Name = "lbl0205";
            this.lbl0205.Size = new System.Drawing.Size(44, 40);
            this.lbl0205.TabIndex = 902;
            this.lbl0205.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0108
            // 
            this.lbl0108.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0108.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0108.ForeColor = System.Drawing.Color.White;
            this.lbl0108.Location = new System.Drawing.Point(388, 73);
            this.lbl0108.Multiline = true;
            this.lbl0108.Name = "lbl0108";
            this.lbl0108.Size = new System.Drawing.Size(44, 40);
            this.lbl0108.TabIndex = 901;
            this.lbl0108.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0107
            // 
            this.lbl0107.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0107.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0107.ForeColor = System.Drawing.Color.White;
            this.lbl0107.Location = new System.Drawing.Point(338, 73);
            this.lbl0107.Multiline = true;
            this.lbl0107.Name = "lbl0107";
            this.lbl0107.Size = new System.Drawing.Size(44, 40);
            this.lbl0107.TabIndex = 900;
            this.lbl0107.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0106
            // 
            this.lbl0106.BackColor = System.Drawing.Color.Gray;
            this.lbl0106.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0106.ForeColor = System.Drawing.Color.White;
            this.lbl0106.Location = new System.Drawing.Point(288, 73);
            this.lbl0106.Multiline = true;
            this.lbl0106.Name = "lbl0106";
            this.lbl0106.Size = new System.Drawing.Size(44, 40);
            this.lbl0106.TabIndex = 899;
            this.lbl0106.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0105
            // 
            this.lbl0105.BackColor = System.Drawing.Color.Gray;
            this.lbl0105.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0105.ForeColor = System.Drawing.Color.White;
            this.lbl0105.Location = new System.Drawing.Point(238, 73);
            this.lbl0105.Multiline = true;
            this.lbl0105.Name = "lbl0105";
            this.lbl0105.Size = new System.Drawing.Size(44, 40);
            this.lbl0105.TabIndex = 898;
            this.lbl0105.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0604
            // 
            this.lbl0604.BackColor = System.Drawing.Color.Gray;
            this.lbl0604.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0604.ForeColor = System.Drawing.Color.White;
            this.lbl0604.Location = new System.Drawing.Point(188, 303);
            this.lbl0604.Multiline = true;
            this.lbl0604.Name = "lbl0604";
            this.lbl0604.Size = new System.Drawing.Size(44, 40);
            this.lbl0604.TabIndex = 897;
            this.lbl0604.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0603
            // 
            this.lbl0603.BackColor = System.Drawing.Color.Gray;
            this.lbl0603.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0603.ForeColor = System.Drawing.Color.White;
            this.lbl0603.Location = new System.Drawing.Point(138, 303);
            this.lbl0603.Multiline = true;
            this.lbl0603.Name = "lbl0603";
            this.lbl0603.Size = new System.Drawing.Size(44, 40);
            this.lbl0603.TabIndex = 896;
            this.lbl0603.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0602
            // 
            this.lbl0602.BackColor = System.Drawing.Color.Gray;
            this.lbl0602.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0602.ForeColor = System.Drawing.Color.White;
            this.lbl0602.Location = new System.Drawing.Point(88, 303);
            this.lbl0602.Multiline = true;
            this.lbl0602.Name = "lbl0602";
            this.lbl0602.Size = new System.Drawing.Size(44, 40);
            this.lbl0602.TabIndex = 895;
            this.lbl0602.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0601
            // 
            this.lbl0601.BackColor = System.Drawing.Color.Gray;
            this.lbl0601.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0601.ForeColor = System.Drawing.Color.White;
            this.lbl0601.Location = new System.Drawing.Point(38, 303);
            this.lbl0601.Multiline = true;
            this.lbl0601.Name = "lbl0601";
            this.lbl0601.Size = new System.Drawing.Size(44, 40);
            this.lbl0601.TabIndex = 894;
            this.lbl0601.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0504
            // 
            this.lbl0504.BackColor = System.Drawing.Color.Gray;
            this.lbl0504.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0504.ForeColor = System.Drawing.Color.White;
            this.lbl0504.Location = new System.Drawing.Point(188, 257);
            this.lbl0504.Multiline = true;
            this.lbl0504.Name = "lbl0504";
            this.lbl0504.Size = new System.Drawing.Size(44, 40);
            this.lbl0504.TabIndex = 893;
            this.lbl0504.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0503
            // 
            this.lbl0503.BackColor = System.Drawing.Color.Gray;
            this.lbl0503.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0503.ForeColor = System.Drawing.Color.White;
            this.lbl0503.Location = new System.Drawing.Point(138, 257);
            this.lbl0503.Multiline = true;
            this.lbl0503.Name = "lbl0503";
            this.lbl0503.Size = new System.Drawing.Size(44, 40);
            this.lbl0503.TabIndex = 892;
            this.lbl0503.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0502
            // 
            this.lbl0502.BackColor = System.Drawing.Color.Gray;
            this.lbl0502.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0502.ForeColor = System.Drawing.Color.White;
            this.lbl0502.Location = new System.Drawing.Point(88, 257);
            this.lbl0502.Multiline = true;
            this.lbl0502.Name = "lbl0502";
            this.lbl0502.Size = new System.Drawing.Size(44, 40);
            this.lbl0502.TabIndex = 891;
            this.lbl0502.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0501
            // 
            this.lbl0501.BackColor = System.Drawing.Color.Gray;
            this.lbl0501.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0501.ForeColor = System.Drawing.Color.White;
            this.lbl0501.Location = new System.Drawing.Point(38, 257);
            this.lbl0501.Multiline = true;
            this.lbl0501.Name = "lbl0501";
            this.lbl0501.Size = new System.Drawing.Size(44, 40);
            this.lbl0501.TabIndex = 890;
            this.lbl0501.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0404
            // 
            this.lbl0404.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0404.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0404.ForeColor = System.Drawing.Color.White;
            this.lbl0404.Location = new System.Drawing.Point(188, 211);
            this.lbl0404.Multiline = true;
            this.lbl0404.Name = "lbl0404";
            this.lbl0404.Size = new System.Drawing.Size(44, 40);
            this.lbl0404.TabIndex = 889;
            this.lbl0404.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0403
            // 
            this.lbl0403.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0403.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0403.ForeColor = System.Drawing.Color.White;
            this.lbl0403.Location = new System.Drawing.Point(138, 211);
            this.lbl0403.Multiline = true;
            this.lbl0403.Name = "lbl0403";
            this.lbl0403.Size = new System.Drawing.Size(44, 40);
            this.lbl0403.TabIndex = 888;
            this.lbl0403.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0402
            // 
            this.lbl0402.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0402.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0402.ForeColor = System.Drawing.Color.White;
            this.lbl0402.Location = new System.Drawing.Point(88, 211);
            this.lbl0402.Multiline = true;
            this.lbl0402.Name = "lbl0402";
            this.lbl0402.Size = new System.Drawing.Size(44, 40);
            this.lbl0402.TabIndex = 887;
            this.lbl0402.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0401
            // 
            this.lbl0401.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0401.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0401.ForeColor = System.Drawing.Color.White;
            this.lbl0401.Location = new System.Drawing.Point(38, 211);
            this.lbl0401.Multiline = true;
            this.lbl0401.Name = "lbl0401";
            this.lbl0401.Size = new System.Drawing.Size(44, 40);
            this.lbl0401.TabIndex = 886;
            this.lbl0401.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0304
            // 
            this.lbl0304.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0304.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0304.ForeColor = System.Drawing.Color.White;
            this.lbl0304.Location = new System.Drawing.Point(188, 165);
            this.lbl0304.Multiline = true;
            this.lbl0304.Name = "lbl0304";
            this.lbl0304.Size = new System.Drawing.Size(44, 40);
            this.lbl0304.TabIndex = 885;
            this.lbl0304.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0303
            // 
            this.lbl0303.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0303.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0303.ForeColor = System.Drawing.Color.White;
            this.lbl0303.Location = new System.Drawing.Point(138, 165);
            this.lbl0303.Multiline = true;
            this.lbl0303.Name = "lbl0303";
            this.lbl0303.Size = new System.Drawing.Size(44, 40);
            this.lbl0303.TabIndex = 884;
            this.lbl0303.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0302
            // 
            this.lbl0302.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0302.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0302.ForeColor = System.Drawing.Color.White;
            this.lbl0302.Location = new System.Drawing.Point(88, 165);
            this.lbl0302.Multiline = true;
            this.lbl0302.Name = "lbl0302";
            this.lbl0302.Size = new System.Drawing.Size(44, 40);
            this.lbl0302.TabIndex = 883;
            this.lbl0302.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0301
            // 
            this.lbl0301.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl0301.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0301.ForeColor = System.Drawing.Color.White;
            this.lbl0301.Location = new System.Drawing.Point(38, 165);
            this.lbl0301.Multiline = true;
            this.lbl0301.Name = "lbl0301";
            this.lbl0301.Size = new System.Drawing.Size(44, 40);
            this.lbl0301.TabIndex = 882;
            this.lbl0301.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0204
            // 
            this.lbl0204.BackColor = System.Drawing.Color.Gray;
            this.lbl0204.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0204.ForeColor = System.Drawing.Color.White;
            this.lbl0204.Location = new System.Drawing.Point(188, 119);
            this.lbl0204.Multiline = true;
            this.lbl0204.Name = "lbl0204";
            this.lbl0204.Size = new System.Drawing.Size(44, 40);
            this.lbl0204.TabIndex = 881;
            this.lbl0204.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0203
            // 
            this.lbl0203.BackColor = System.Drawing.Color.Gray;
            this.lbl0203.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0203.ForeColor = System.Drawing.Color.White;
            this.lbl0203.Location = new System.Drawing.Point(138, 119);
            this.lbl0203.Multiline = true;
            this.lbl0203.Name = "lbl0203";
            this.lbl0203.Size = new System.Drawing.Size(44, 40);
            this.lbl0203.TabIndex = 880;
            this.lbl0203.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0202
            // 
            this.lbl0202.BackColor = System.Drawing.Color.Gray;
            this.lbl0202.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0202.ForeColor = System.Drawing.Color.White;
            this.lbl0202.Location = new System.Drawing.Point(88, 119);
            this.lbl0202.Multiline = true;
            this.lbl0202.Name = "lbl0202";
            this.lbl0202.Size = new System.Drawing.Size(44, 40);
            this.lbl0202.TabIndex = 879;
            this.lbl0202.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0201
            // 
            this.lbl0201.BackColor = System.Drawing.Color.Gray;
            this.lbl0201.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0201.ForeColor = System.Drawing.Color.White;
            this.lbl0201.Location = new System.Drawing.Point(38, 119);
            this.lbl0201.Multiline = true;
            this.lbl0201.Name = "lbl0201";
            this.lbl0201.Size = new System.Drawing.Size(44, 40);
            this.lbl0201.TabIndex = 878;
            this.lbl0201.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0104
            // 
            this.lbl0104.BackColor = System.Drawing.Color.Gray;
            this.lbl0104.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0104.ForeColor = System.Drawing.Color.White;
            this.lbl0104.Location = new System.Drawing.Point(188, 73);
            this.lbl0104.Multiline = true;
            this.lbl0104.Name = "lbl0104";
            this.lbl0104.Size = new System.Drawing.Size(44, 40);
            this.lbl0104.TabIndex = 877;
            this.lbl0104.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0103
            // 
            this.lbl0103.BackColor = System.Drawing.Color.Gray;
            this.lbl0103.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0103.ForeColor = System.Drawing.Color.White;
            this.lbl0103.Location = new System.Drawing.Point(138, 73);
            this.lbl0103.Multiline = true;
            this.lbl0103.Name = "lbl0103";
            this.lbl0103.Size = new System.Drawing.Size(44, 40);
            this.lbl0103.TabIndex = 876;
            this.lbl0103.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0102
            // 
            this.lbl0102.BackColor = System.Drawing.Color.Gray;
            this.lbl0102.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0102.ForeColor = System.Drawing.Color.White;
            this.lbl0102.Location = new System.Drawing.Point(88, 73);
            this.lbl0102.Multiline = true;
            this.lbl0102.Name = "lbl0102";
            this.lbl0102.Size = new System.Drawing.Size(44, 40);
            this.lbl0102.TabIndex = 875;
            this.lbl0102.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl0101
            // 
            this.lbl0101.BackColor = System.Drawing.Color.Gray;
            this.lbl0101.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0101.ForeColor = System.Drawing.Color.White;
            this.lbl0101.Location = new System.Drawing.Point(38, 73);
            this.lbl0101.Multiline = true;
            this.lbl0101.Name = "lbl0101";
            this.lbl0101.Size = new System.Drawing.Size(44, 40);
            this.lbl0101.TabIndex = 874;
            this.lbl0101.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // N11a
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(619, 638);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnGo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lbl1111);
            this.Controls.Add(this.lbl1011);
            this.Controls.Add(this.lbl0911);
            this.Controls.Add(this.lbl0811);
            this.Controls.Add(this.lbl0711);
            this.Controls.Add(this.lbl0611);
            this.Controls.Add(this.lbl0511);
            this.Controls.Add(this.lbl0411);
            this.Controls.Add(this.lbl0311);
            this.Controls.Add(this.lbl0211);
            this.Controls.Add(this.lbl0111);
            this.Controls.Add(this.lbl1110);
            this.Controls.Add(this.lbl1109);
            this.Controls.Add(this.lbl1108);
            this.Controls.Add(this.lbl1107);
            this.Controls.Add(this.lbl1106);
            this.Controls.Add(this.lbl1105);
            this.Controls.Add(this.lbl1104);
            this.Controls.Add(this.lbl1103);
            this.Controls.Add(this.lbl1102);
            this.Controls.Add(this.lbl1101);
            this.Controls.Add(this.lbl1010);
            this.Controls.Add(this.lbl1009);
            this.Controls.Add(this.lbl1008);
            this.Controls.Add(this.lbl1007);
            this.Controls.Add(this.lbl1006);
            this.Controls.Add(this.lbl1005);
            this.Controls.Add(this.lbl1004);
            this.Controls.Add(this.lbl1003);
            this.Controls.Add(this.lbl1002);
            this.Controls.Add(this.lbl1001);
            this.Controls.Add(this.lbl0910);
            this.Controls.Add(this.lbl0909);
            this.Controls.Add(this.lbl0908);
            this.Controls.Add(this.lbl0907);
            this.Controls.Add(this.lbl0906);
            this.Controls.Add(this.lbl0905);
            this.Controls.Add(this.lbl0904);
            this.Controls.Add(this.lbl0903);
            this.Controls.Add(this.lbl0902);
            this.Controls.Add(this.lbl0901);
            this.Controls.Add(this.lbl0810);
            this.Controls.Add(this.lbl0710);
            this.Controls.Add(this.lbl0610);
            this.Controls.Add(this.lbl0510);
            this.Controls.Add(this.lbl0410);
            this.Controls.Add(this.lbl0310);
            this.Controls.Add(this.lbl0210);
            this.Controls.Add(this.lbl0110);
            this.Controls.Add(this.lbl0809);
            this.Controls.Add(this.lbl0709);
            this.Controls.Add(this.lbl0609);
            this.Controls.Add(this.lbl0509);
            this.Controls.Add(this.lbl0409);
            this.Controls.Add(this.lbl0309);
            this.Controls.Add(this.lbl0209);
            this.Controls.Add(this.lbl0109);
            this.Controls.Add(this.lbl0808);
            this.Controls.Add(this.lbl0807);
            this.Controls.Add(this.lbl0806);
            this.Controls.Add(this.lbl0805);
            this.Controls.Add(this.lbl0708);
            this.Controls.Add(this.lbl0707);
            this.Controls.Add(this.lbl0706);
            this.Controls.Add(this.lbl0705);
            this.Controls.Add(this.lbl0804);
            this.Controls.Add(this.lbl0803);
            this.Controls.Add(this.lbl0802);
            this.Controls.Add(this.lbl0801);
            this.Controls.Add(this.lbl0704);
            this.Controls.Add(this.lbl0703);
            this.Controls.Add(this.lbl0702);
            this.Controls.Add(this.lbl0701);
            this.Controls.Add(this.lbl0608);
            this.Controls.Add(this.lbl0607);
            this.Controls.Add(this.lbl0606);
            this.Controls.Add(this.lbl0605);
            this.Controls.Add(this.lbl0508);
            this.Controls.Add(this.lbl0507);
            this.Controls.Add(this.lbl0506);
            this.Controls.Add(this.lbl0505);
            this.Controls.Add(this.lbl0408);
            this.Controls.Add(this.lbl0407);
            this.Controls.Add(this.lbl0406);
            this.Controls.Add(this.lbl0405);
            this.Controls.Add(this.lbl0308);
            this.Controls.Add(this.lbl0307);
            this.Controls.Add(this.lbl0306);
            this.Controls.Add(this.lbl0305);
            this.Controls.Add(this.lbl0208);
            this.Controls.Add(this.lbl0207);
            this.Controls.Add(this.lbl0206);
            this.Controls.Add(this.lbl0205);
            this.Controls.Add(this.lbl0108);
            this.Controls.Add(this.lbl0107);
            this.Controls.Add(this.lbl0106);
            this.Controls.Add(this.lbl0105);
            this.Controls.Add(this.lbl0604);
            this.Controls.Add(this.lbl0603);
            this.Controls.Add(this.lbl0602);
            this.Controls.Add(this.lbl0601);
            this.Controls.Add(this.lbl0504);
            this.Controls.Add(this.lbl0503);
            this.Controls.Add(this.lbl0502);
            this.Controls.Add(this.lbl0501);
            this.Controls.Add(this.lbl0404);
            this.Controls.Add(this.lbl0403);
            this.Controls.Add(this.lbl0402);
            this.Controls.Add(this.lbl0401);
            this.Controls.Add(this.lbl0304);
            this.Controls.Add(this.lbl0303);
            this.Controls.Add(this.lbl0302);
            this.Controls.Add(this.lbl0301);
            this.Controls.Add(this.lbl0204);
            this.Controls.Add(this.lbl0203);
            this.Controls.Add(this.lbl0202);
            this.Controls.Add(this.lbl0201);
            this.Controls.Add(this.lbl0104);
            this.Controls.Add(this.lbl0103);
            this.Controls.Add(this.lbl0102);
            this.Controls.Add(this.lbl0101);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "N11a";
            this.Text = "N11a";
            this.Load += new System.EventHandler(this.N11a_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox lbl1111;
        private System.Windows.Forms.TextBox lbl1011;
        private System.Windows.Forms.TextBox lbl0911;
        private System.Windows.Forms.TextBox lbl0811;
        private System.Windows.Forms.TextBox lbl0711;
        private System.Windows.Forms.TextBox lbl0611;
        private System.Windows.Forms.TextBox lbl0511;
        private System.Windows.Forms.TextBox lbl0411;
        private System.Windows.Forms.TextBox lbl0311;
        private System.Windows.Forms.TextBox lbl0211;
        private System.Windows.Forms.TextBox lbl0111;
        private System.Windows.Forms.TextBox lbl1110;
        private System.Windows.Forms.TextBox lbl1109;
        private System.Windows.Forms.TextBox lbl1108;
        private System.Windows.Forms.TextBox lbl1107;
        private System.Windows.Forms.TextBox lbl1106;
        private System.Windows.Forms.TextBox lbl1105;
        private System.Windows.Forms.TextBox lbl1104;
        private System.Windows.Forms.TextBox lbl1103;
        private System.Windows.Forms.TextBox lbl1102;
        private System.Windows.Forms.TextBox lbl1101;
        private System.Windows.Forms.TextBox lbl1010;
        private System.Windows.Forms.TextBox lbl1009;
        private System.Windows.Forms.TextBox lbl1008;
        private System.Windows.Forms.TextBox lbl1007;
        private System.Windows.Forms.TextBox lbl1006;
        private System.Windows.Forms.TextBox lbl1005;
        private System.Windows.Forms.TextBox lbl1004;
        private System.Windows.Forms.TextBox lbl1003;
        private System.Windows.Forms.TextBox lbl1002;
        private System.Windows.Forms.TextBox lbl1001;
        private System.Windows.Forms.TextBox lbl0910;
        private System.Windows.Forms.TextBox lbl0909;
        private System.Windows.Forms.TextBox lbl0908;
        private System.Windows.Forms.TextBox lbl0907;
        private System.Windows.Forms.TextBox lbl0906;
        private System.Windows.Forms.TextBox lbl0905;
        private System.Windows.Forms.TextBox lbl0904;
        private System.Windows.Forms.TextBox lbl0903;
        private System.Windows.Forms.TextBox lbl0902;
        private System.Windows.Forms.TextBox lbl0901;
        private System.Windows.Forms.TextBox lbl0810;
        private System.Windows.Forms.TextBox lbl0710;
        private System.Windows.Forms.TextBox lbl0610;
        private System.Windows.Forms.TextBox lbl0510;
        private System.Windows.Forms.TextBox lbl0410;
        private System.Windows.Forms.TextBox lbl0310;
        private System.Windows.Forms.TextBox lbl0210;
        private System.Windows.Forms.TextBox lbl0110;
        private System.Windows.Forms.TextBox lbl0809;
        private System.Windows.Forms.TextBox lbl0709;
        private System.Windows.Forms.TextBox lbl0609;
        private System.Windows.Forms.TextBox lbl0509;
        private System.Windows.Forms.TextBox lbl0409;
        private System.Windows.Forms.TextBox lbl0309;
        private System.Windows.Forms.TextBox lbl0209;
        private System.Windows.Forms.TextBox lbl0109;
        private System.Windows.Forms.TextBox lbl0808;
        private System.Windows.Forms.TextBox lbl0807;
        private System.Windows.Forms.TextBox lbl0806;
        private System.Windows.Forms.TextBox lbl0805;
        private System.Windows.Forms.TextBox lbl0708;
        private System.Windows.Forms.TextBox lbl0707;
        private System.Windows.Forms.TextBox lbl0706;
        private System.Windows.Forms.TextBox lbl0705;
        private System.Windows.Forms.TextBox lbl0804;
        private System.Windows.Forms.TextBox lbl0803;
        private System.Windows.Forms.TextBox lbl0802;
        private System.Windows.Forms.TextBox lbl0801;
        private System.Windows.Forms.TextBox lbl0704;
        private System.Windows.Forms.TextBox lbl0703;
        private System.Windows.Forms.TextBox lbl0702;
        private System.Windows.Forms.TextBox lbl0701;
        private System.Windows.Forms.TextBox lbl0608;
        private System.Windows.Forms.TextBox lbl0607;
        private System.Windows.Forms.TextBox lbl0606;
        private System.Windows.Forms.TextBox lbl0605;
        private System.Windows.Forms.TextBox lbl0508;
        private System.Windows.Forms.TextBox lbl0507;
        private System.Windows.Forms.TextBox lbl0506;
        private System.Windows.Forms.TextBox lbl0505;
        private System.Windows.Forms.TextBox lbl0408;
        private System.Windows.Forms.TextBox lbl0407;
        private System.Windows.Forms.TextBox lbl0406;
        private System.Windows.Forms.TextBox lbl0405;
        private System.Windows.Forms.TextBox lbl0308;
        private System.Windows.Forms.TextBox lbl0307;
        private System.Windows.Forms.TextBox lbl0306;
        private System.Windows.Forms.TextBox lbl0305;
        private System.Windows.Forms.TextBox lbl0208;
        private System.Windows.Forms.TextBox lbl0207;
        private System.Windows.Forms.TextBox lbl0206;
        private System.Windows.Forms.TextBox lbl0205;
        private System.Windows.Forms.TextBox lbl0108;
        private System.Windows.Forms.TextBox lbl0107;
        private System.Windows.Forms.TextBox lbl0106;
        private System.Windows.Forms.TextBox lbl0105;
        private System.Windows.Forms.TextBox lbl0604;
        private System.Windows.Forms.TextBox lbl0603;
        private System.Windows.Forms.TextBox lbl0602;
        private System.Windows.Forms.TextBox lbl0601;
        private System.Windows.Forms.TextBox lbl0504;
        private System.Windows.Forms.TextBox lbl0503;
        private System.Windows.Forms.TextBox lbl0502;
        private System.Windows.Forms.TextBox lbl0501;
        private System.Windows.Forms.TextBox lbl0404;
        private System.Windows.Forms.TextBox lbl0403;
        private System.Windows.Forms.TextBox lbl0402;
        private System.Windows.Forms.TextBox lbl0401;
        private System.Windows.Forms.TextBox lbl0304;
        private System.Windows.Forms.TextBox lbl0303;
        private System.Windows.Forms.TextBox lbl0302;
        private System.Windows.Forms.TextBox lbl0301;
        private System.Windows.Forms.TextBox lbl0204;
        private System.Windows.Forms.TextBox lbl0203;
        private System.Windows.Forms.TextBox lbl0202;
        private System.Windows.Forms.TextBox lbl0201;
        private System.Windows.Forms.TextBox lbl0104;
        private System.Windows.Forms.TextBox lbl0103;
        private System.Windows.Forms.TextBox lbl0102;
        private System.Windows.Forms.TextBox lbl0101;
    }
}