﻿namespace SudokuN.View
{
    partial class N6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl66 = new System.Windows.Forms.TextBox();
            this.lbl65 = new System.Windows.Forms.TextBox();
            this.lbl56 = new System.Windows.Forms.TextBox();
            this.lbl55 = new System.Windows.Forms.TextBox();
            this.lbl46 = new System.Windows.Forms.TextBox();
            this.lbl45 = new System.Windows.Forms.TextBox();
            this.lbl36 = new System.Windows.Forms.TextBox();
            this.lbl35 = new System.Windows.Forms.TextBox();
            this.lbl26 = new System.Windows.Forms.TextBox();
            this.lbl25 = new System.Windows.Forms.TextBox();
            this.lbl16 = new System.Windows.Forms.TextBox();
            this.lbl15 = new System.Windows.Forms.TextBox();
            this.lbl64 = new System.Windows.Forms.TextBox();
            this.lbl63 = new System.Windows.Forms.TextBox();
            this.lbl62 = new System.Windows.Forms.TextBox();
            this.lbl61 = new System.Windows.Forms.TextBox();
            this.lbl54 = new System.Windows.Forms.TextBox();
            this.lbl53 = new System.Windows.Forms.TextBox();
            this.lbl52 = new System.Windows.Forms.TextBox();
            this.lbl51 = new System.Windows.Forms.TextBox();
            this.lbl44 = new System.Windows.Forms.TextBox();
            this.lbl43 = new System.Windows.Forms.TextBox();
            this.lbl42 = new System.Windows.Forms.TextBox();
            this.lbl41 = new System.Windows.Forms.TextBox();
            this.lbl34 = new System.Windows.Forms.TextBox();
            this.lbl33 = new System.Windows.Forms.TextBox();
            this.lbl32 = new System.Windows.Forms.TextBox();
            this.lbl31 = new System.Windows.Forms.TextBox();
            this.lbl24 = new System.Windows.Forms.TextBox();
            this.lbl23 = new System.Windows.Forms.TextBox();
            this.lbl22 = new System.Windows.Forms.TextBox();
            this.lbl21 = new System.Windows.Forms.TextBox();
            this.lbl14 = new System.Windows.Forms.TextBox();
            this.lbl13 = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.TextBox();
            this.lbl11 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblClear = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblBack = new System.Windows.Forms.Label();
            this.Check = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl66
            // 
            this.lbl66.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl66.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl66.ForeColor = System.Drawing.Color.White;
            this.lbl66.Location = new System.Drawing.Point(491, 288);
            this.lbl66.Multiline = true;
            this.lbl66.Name = "lbl66";
            this.lbl66.Size = new System.Drawing.Size(44, 40);
            this.lbl66.TabIndex = 422;
            this.lbl66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl65
            // 
            this.lbl65.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl65.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl65.ForeColor = System.Drawing.Color.White;
            this.lbl65.Location = new System.Drawing.Point(441, 288);
            this.lbl65.Multiline = true;
            this.lbl65.Name = "lbl65";
            this.lbl65.Size = new System.Drawing.Size(44, 40);
            this.lbl65.TabIndex = 421;
            this.lbl65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl56
            // 
            this.lbl56.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl56.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl56.ForeColor = System.Drawing.Color.White;
            this.lbl56.Location = new System.Drawing.Point(491, 242);
            this.lbl56.Multiline = true;
            this.lbl56.Name = "lbl56";
            this.lbl56.Size = new System.Drawing.Size(44, 40);
            this.lbl56.TabIndex = 419;
            this.lbl56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl55
            // 
            this.lbl55.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl55.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl55.ForeColor = System.Drawing.Color.White;
            this.lbl55.Location = new System.Drawing.Point(441, 242);
            this.lbl55.Multiline = true;
            this.lbl55.Name = "lbl55";
            this.lbl55.Size = new System.Drawing.Size(44, 40);
            this.lbl55.TabIndex = 418;
            this.lbl55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl46
            // 
            this.lbl46.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl46.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl46.ForeColor = System.Drawing.Color.White;
            this.lbl46.Location = new System.Drawing.Point(491, 196);
            this.lbl46.Multiline = true;
            this.lbl46.Name = "lbl46";
            this.lbl46.Size = new System.Drawing.Size(44, 40);
            this.lbl46.TabIndex = 416;
            this.lbl46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl45
            // 
            this.lbl45.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl45.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl45.ForeColor = System.Drawing.Color.White;
            this.lbl45.Location = new System.Drawing.Point(441, 196);
            this.lbl45.Multiline = true;
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(44, 40);
            this.lbl45.TabIndex = 415;
            this.lbl45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl36
            // 
            this.lbl36.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl36.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl36.ForeColor = System.Drawing.Color.White;
            this.lbl36.Location = new System.Drawing.Point(491, 150);
            this.lbl36.Multiline = true;
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(44, 40);
            this.lbl36.TabIndex = 413;
            this.lbl36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl35
            // 
            this.lbl35.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl35.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl35.ForeColor = System.Drawing.Color.White;
            this.lbl35.Location = new System.Drawing.Point(441, 150);
            this.lbl35.Multiline = true;
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(44, 40);
            this.lbl35.TabIndex = 412;
            this.lbl35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl26
            // 
            this.lbl26.BackColor = System.Drawing.Color.Teal;
            this.lbl26.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26.ForeColor = System.Drawing.Color.White;
            this.lbl26.Location = new System.Drawing.Point(491, 104);
            this.lbl26.Multiline = true;
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(44, 40);
            this.lbl26.TabIndex = 410;
            this.lbl26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl25
            // 
            this.lbl25.BackColor = System.Drawing.Color.Teal;
            this.lbl25.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.ForeColor = System.Drawing.Color.White;
            this.lbl25.Location = new System.Drawing.Point(441, 104);
            this.lbl25.Multiline = true;
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(44, 40);
            this.lbl25.TabIndex = 409;
            this.lbl25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl16
            // 
            this.lbl16.BackColor = System.Drawing.Color.Teal;
            this.lbl16.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl16.ForeColor = System.Drawing.Color.White;
            this.lbl16.Location = new System.Drawing.Point(491, 58);
            this.lbl16.Multiline = true;
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(44, 40);
            this.lbl16.TabIndex = 407;
            this.lbl16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl15
            // 
            this.lbl15.BackColor = System.Drawing.Color.Teal;
            this.lbl15.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.ForeColor = System.Drawing.Color.White;
            this.lbl15.Location = new System.Drawing.Point(441, 58);
            this.lbl15.Multiline = true;
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(44, 40);
            this.lbl15.TabIndex = 406;
            this.lbl15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl64
            // 
            this.lbl64.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl64.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl64.ForeColor = System.Drawing.Color.White;
            this.lbl64.Location = new System.Drawing.Point(391, 288);
            this.lbl64.Multiline = true;
            this.lbl64.Name = "lbl64";
            this.lbl64.Size = new System.Drawing.Size(44, 40);
            this.lbl64.TabIndex = 405;
            this.lbl64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl63
            // 
            this.lbl63.BackColor = System.Drawing.Color.Crimson;
            this.lbl63.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl63.ForeColor = System.Drawing.Color.White;
            this.lbl63.Location = new System.Drawing.Point(341, 288);
            this.lbl63.Multiline = true;
            this.lbl63.Name = "lbl63";
            this.lbl63.Size = new System.Drawing.Size(44, 40);
            this.lbl63.TabIndex = 404;
            this.lbl63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl62
            // 
            this.lbl62.BackColor = System.Drawing.Color.Crimson;
            this.lbl62.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl62.ForeColor = System.Drawing.Color.White;
            this.lbl62.Location = new System.Drawing.Point(291, 288);
            this.lbl62.Multiline = true;
            this.lbl62.Name = "lbl62";
            this.lbl62.Size = new System.Drawing.Size(44, 40);
            this.lbl62.TabIndex = 403;
            this.lbl62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl61
            // 
            this.lbl61.BackColor = System.Drawing.Color.Crimson;
            this.lbl61.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl61.ForeColor = System.Drawing.Color.White;
            this.lbl61.Location = new System.Drawing.Point(241, 288);
            this.lbl61.Multiline = true;
            this.lbl61.Name = "lbl61";
            this.lbl61.Size = new System.Drawing.Size(44, 40);
            this.lbl61.TabIndex = 402;
            this.lbl61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl54
            // 
            this.lbl54.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl54.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl54.ForeColor = System.Drawing.Color.White;
            this.lbl54.Location = new System.Drawing.Point(391, 242);
            this.lbl54.Multiline = true;
            this.lbl54.Name = "lbl54";
            this.lbl54.Size = new System.Drawing.Size(44, 40);
            this.lbl54.TabIndex = 401;
            this.lbl54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl53
            // 
            this.lbl53.BackColor = System.Drawing.Color.Crimson;
            this.lbl53.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl53.ForeColor = System.Drawing.Color.White;
            this.lbl53.Location = new System.Drawing.Point(341, 242);
            this.lbl53.Multiline = true;
            this.lbl53.Name = "lbl53";
            this.lbl53.Size = new System.Drawing.Size(44, 40);
            this.lbl53.TabIndex = 400;
            this.lbl53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl52
            // 
            this.lbl52.BackColor = System.Drawing.Color.Crimson;
            this.lbl52.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl52.ForeColor = System.Drawing.Color.White;
            this.lbl52.Location = new System.Drawing.Point(291, 242);
            this.lbl52.Multiline = true;
            this.lbl52.Name = "lbl52";
            this.lbl52.Size = new System.Drawing.Size(44, 40);
            this.lbl52.TabIndex = 399;
            this.lbl52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl51
            // 
            this.lbl51.BackColor = System.Drawing.Color.Crimson;
            this.lbl51.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl51.ForeColor = System.Drawing.Color.White;
            this.lbl51.Location = new System.Drawing.Point(241, 242);
            this.lbl51.Multiline = true;
            this.lbl51.Name = "lbl51";
            this.lbl51.Size = new System.Drawing.Size(44, 40);
            this.lbl51.TabIndex = 398;
            this.lbl51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl44
            // 
            this.lbl44.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl44.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl44.ForeColor = System.Drawing.Color.White;
            this.lbl44.Location = new System.Drawing.Point(391, 196);
            this.lbl44.Multiline = true;
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(44, 40);
            this.lbl44.TabIndex = 397;
            this.lbl44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl43
            // 
            this.lbl43.BackColor = System.Drawing.Color.DimGray;
            this.lbl43.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl43.ForeColor = System.Drawing.Color.White;
            this.lbl43.Location = new System.Drawing.Point(341, 196);
            this.lbl43.Multiline = true;
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(44, 40);
            this.lbl43.TabIndex = 396;
            this.lbl43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl42
            // 
            this.lbl42.BackColor = System.Drawing.Color.DimGray;
            this.lbl42.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl42.ForeColor = System.Drawing.Color.White;
            this.lbl42.Location = new System.Drawing.Point(291, 196);
            this.lbl42.Multiline = true;
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(44, 40);
            this.lbl42.TabIndex = 395;
            this.lbl42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl41
            // 
            this.lbl41.BackColor = System.Drawing.Color.DimGray;
            this.lbl41.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl41.ForeColor = System.Drawing.Color.White;
            this.lbl41.Location = new System.Drawing.Point(241, 196);
            this.lbl41.Multiline = true;
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(44, 40);
            this.lbl41.TabIndex = 394;
            this.lbl41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl34
            // 
            this.lbl34.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl34.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl34.ForeColor = System.Drawing.Color.White;
            this.lbl34.Location = new System.Drawing.Point(391, 150);
            this.lbl34.Multiline = true;
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(44, 40);
            this.lbl34.TabIndex = 393;
            this.lbl34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl33
            // 
            this.lbl33.BackColor = System.Drawing.Color.DimGray;
            this.lbl33.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.ForeColor = System.Drawing.Color.White;
            this.lbl33.Location = new System.Drawing.Point(341, 150);
            this.lbl33.Multiline = true;
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(44, 40);
            this.lbl33.TabIndex = 392;
            this.lbl33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl32
            // 
            this.lbl32.BackColor = System.Drawing.Color.DimGray;
            this.lbl32.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.ForeColor = System.Drawing.Color.White;
            this.lbl32.Location = new System.Drawing.Point(291, 150);
            this.lbl32.Multiline = true;
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(44, 40);
            this.lbl32.TabIndex = 391;
            this.lbl32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl31
            // 
            this.lbl31.BackColor = System.Drawing.Color.DimGray;
            this.lbl31.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.ForeColor = System.Drawing.Color.White;
            this.lbl31.Location = new System.Drawing.Point(241, 150);
            this.lbl31.Multiline = true;
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(44, 40);
            this.lbl31.TabIndex = 390;
            this.lbl31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl24
            // 
            this.lbl24.BackColor = System.Drawing.Color.Teal;
            this.lbl24.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.ForeColor = System.Drawing.Color.White;
            this.lbl24.Location = new System.Drawing.Point(391, 104);
            this.lbl24.Multiline = true;
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(44, 40);
            this.lbl24.TabIndex = 389;
            this.lbl24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl23
            // 
            this.lbl23.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl23.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.ForeColor = System.Drawing.Color.White;
            this.lbl23.Location = new System.Drawing.Point(341, 104);
            this.lbl23.Multiline = true;
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(44, 40);
            this.lbl23.TabIndex = 388;
            this.lbl23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl22
            // 
            this.lbl22.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl22.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.ForeColor = System.Drawing.Color.White;
            this.lbl22.Location = new System.Drawing.Point(291, 104);
            this.lbl22.Multiline = true;
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(44, 40);
            this.lbl22.TabIndex = 387;
            this.lbl22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl21
            // 
            this.lbl21.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl21.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.ForeColor = System.Drawing.Color.White;
            this.lbl21.Location = new System.Drawing.Point(241, 104);
            this.lbl21.Multiline = true;
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(44, 40);
            this.lbl21.TabIndex = 386;
            this.lbl21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl14
            // 
            this.lbl14.BackColor = System.Drawing.Color.Teal;
            this.lbl14.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl14.ForeColor = System.Drawing.Color.White;
            this.lbl14.Location = new System.Drawing.Point(391, 58);
            this.lbl14.Multiline = true;
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(44, 40);
            this.lbl14.TabIndex = 385;
            this.lbl14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl13
            // 
            this.lbl13.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl13.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.ForeColor = System.Drawing.Color.White;
            this.lbl13.Location = new System.Drawing.Point(341, 58);
            this.lbl13.Multiline = true;
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(44, 40);
            this.lbl13.TabIndex = 384;
            this.lbl13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl12.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.ForeColor = System.Drawing.Color.White;
            this.lbl12.Location = new System.Drawing.Point(291, 58);
            this.lbl12.Multiline = true;
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(44, 40);
            this.lbl12.TabIndex = 383;
            this.lbl12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.SeaGreen;
            this.lbl11.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.ForeColor = System.Drawing.Color.White;
            this.lbl11.Location = new System.Drawing.Point(241, 58);
            this.lbl11.Multiline = true;
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(44, 40);
            this.lbl11.TabIndex = 382;
            this.lbl11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 54F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(537, 331);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 89);
            this.label1.TabIndex = 863;
            this.label1.Text = "6x6";
            // 
            // lblClear
            // 
            this.lblClear.AutoSize = true;
            this.lblClear.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblClear.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClear.ForeColor = System.Drawing.Color.Crimson;
            this.lblClear.Location = new System.Drawing.Point(523, 442);
            this.lblClear.Name = "lblClear";
            this.lblClear.Size = new System.Drawing.Size(64, 23);
            this.lblClear.TabIndex = 891;
            this.lblClear.Text = "Clear";
            this.lblClear.Click += new System.EventHandler(this.btnClear_Click);
            this.lblClear.MouseLeave += new System.EventHandler(this.lblClear_MouseLeave);
            this.lblClear.MouseHover += new System.EventHandler(this.lblClear_MouseHover);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResult.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.ForeColor = System.Drawing.Color.Crimson;
            this.lblResult.Location = new System.Drawing.Point(349, 442);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(74, 23);
            this.lblResult.TabIndex = 890;
            this.lblResult.Text = "Result";
            this.lblResult.Click += new System.EventHandler(this.btnGo_Click);
            this.lblResult.MouseLeave += new System.EventHandler(this.lblResult_MouseLeave);
            this.lblResult.MouseHover += new System.EventHandler(this.lblResult_MouseHover);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(150, 454);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(487, 13);
            this.label5.TabIndex = 889;
            this.label5.Text = "________________________________________________________________________________";
            // 
            // lblBack
            // 
            this.lblBack.AutoSize = true;
            this.lblBack.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBack.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBack.ForeColor = System.Drawing.Color.Crimson;
            this.lblBack.Location = new System.Drawing.Point(35, 3);
            this.lblBack.Name = "lblBack";
            this.lblBack.Size = new System.Drawing.Size(120, 23);
            this.lblBack.TabIndex = 888;
            this.lblBack.Text = "Back Menu";
            this.lblBack.Click += new System.EventHandler(this.btnBack_Click);
            this.lblBack.MouseLeave += new System.EventHandler(this.lblBack_MouseLeave);
            this.lblBack.MouseHover += new System.EventHandler(this.lblBack_MouseHover);
            // 
            // Check
            // 
            this.Check.AutoSize = true;
            this.Check.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Check.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check.ForeColor = System.Drawing.Color.Crimson;
            this.Check.Location = new System.Drawing.Point(194, 442);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(70, 23);
            this.Check.TabIndex = 892;
            this.Check.Text = "Check";
            this.Check.Click += new System.EventHandler(this.Check_Click);
            // 
            // N6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::SudokuN.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(829, 510);
            this.Controls.Add(this.Check);
            this.Controls.Add(this.lblClear);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl66);
            this.Controls.Add(this.lbl65);
            this.Controls.Add(this.lbl56);
            this.Controls.Add(this.lbl55);
            this.Controls.Add(this.lbl46);
            this.Controls.Add(this.lbl45);
            this.Controls.Add(this.lbl36);
            this.Controls.Add(this.lbl35);
            this.Controls.Add(this.lbl26);
            this.Controls.Add(this.lbl25);
            this.Controls.Add(this.lbl16);
            this.Controls.Add(this.lbl15);
            this.Controls.Add(this.lbl64);
            this.Controls.Add(this.lbl63);
            this.Controls.Add(this.lbl62);
            this.Controls.Add(this.lbl61);
            this.Controls.Add(this.lbl54);
            this.Controls.Add(this.lbl53);
            this.Controls.Add(this.lbl52);
            this.Controls.Add(this.lbl51);
            this.Controls.Add(this.lbl44);
            this.Controls.Add(this.lbl43);
            this.Controls.Add(this.lbl42);
            this.Controls.Add(this.lbl41);
            this.Controls.Add(this.lbl34);
            this.Controls.Add(this.lbl33);
            this.Controls.Add(this.lbl32);
            this.Controls.Add(this.lbl31);
            this.Controls.Add(this.lbl24);
            this.Controls.Add(this.lbl23);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl14);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximumSize = new System.Drawing.Size(845, 549);
            this.MinimumSize = new System.Drawing.Size(845, 549);
            this.Name = "N6";
            this.Text = "N6";
            this.Load += new System.EventHandler(this.N6_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox lbl66;
        private System.Windows.Forms.TextBox lbl65;
        private System.Windows.Forms.TextBox lbl56;
        private System.Windows.Forms.TextBox lbl55;
        private System.Windows.Forms.TextBox lbl46;
        private System.Windows.Forms.TextBox lbl45;
        private System.Windows.Forms.TextBox lbl36;
        private System.Windows.Forms.TextBox lbl35;
        private System.Windows.Forms.TextBox lbl26;
        private System.Windows.Forms.TextBox lbl25;
        private System.Windows.Forms.TextBox lbl16;
        private System.Windows.Forms.TextBox lbl15;
        private System.Windows.Forms.TextBox lbl64;
        private System.Windows.Forms.TextBox lbl63;
        private System.Windows.Forms.TextBox lbl62;
        private System.Windows.Forms.TextBox lbl61;
        private System.Windows.Forms.TextBox lbl54;
        private System.Windows.Forms.TextBox lbl53;
        private System.Windows.Forms.TextBox lbl52;
        private System.Windows.Forms.TextBox lbl51;
        private System.Windows.Forms.TextBox lbl44;
        private System.Windows.Forms.TextBox lbl43;
        private System.Windows.Forms.TextBox lbl42;
        private System.Windows.Forms.TextBox lbl41;
        private System.Windows.Forms.TextBox lbl34;
        private System.Windows.Forms.TextBox lbl33;
        private System.Windows.Forms.TextBox lbl32;
        private System.Windows.Forms.TextBox lbl31;
        private System.Windows.Forms.TextBox lbl24;
        private System.Windows.Forms.TextBox lbl23;
        private System.Windows.Forms.TextBox lbl22;
        private System.Windows.Forms.TextBox lbl21;
        private System.Windows.Forms.TextBox lbl14;
        private System.Windows.Forms.TextBox lbl13;
        private System.Windows.Forms.TextBox lbl12;
        private System.Windows.Forms.TextBox lbl11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblClear;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblBack;
        private System.Windows.Forms.Label Check;
    }
}