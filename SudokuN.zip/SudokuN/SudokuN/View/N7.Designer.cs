﻿namespace SudokuN.View
{
    partial class N7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl77 = new System.Windows.Forms.TextBox();
            this.lbl76 = new System.Windows.Forms.TextBox();
            this.lbl75 = new System.Windows.Forms.TextBox();
            this.lbl74 = new System.Windows.Forms.TextBox();
            this.lbl73 = new System.Windows.Forms.TextBox();
            this.lbl72 = new System.Windows.Forms.TextBox();
            this.lbl71 = new System.Windows.Forms.TextBox();
            this.lbl67 = new System.Windows.Forms.TextBox();
            this.lbl66 = new System.Windows.Forms.TextBox();
            this.lbl65 = new System.Windows.Forms.TextBox();
            this.lbl57 = new System.Windows.Forms.TextBox();
            this.lbl56 = new System.Windows.Forms.TextBox();
            this.lbl55 = new System.Windows.Forms.TextBox();
            this.lbl47 = new System.Windows.Forms.TextBox();
            this.lbl46 = new System.Windows.Forms.TextBox();
            this.lbl45 = new System.Windows.Forms.TextBox();
            this.lbl37 = new System.Windows.Forms.TextBox();
            this.lbl36 = new System.Windows.Forms.TextBox();
            this.lbl35 = new System.Windows.Forms.TextBox();
            this.lbl27 = new System.Windows.Forms.TextBox();
            this.lbl26 = new System.Windows.Forms.TextBox();
            this.lbl25 = new System.Windows.Forms.TextBox();
            this.lbl17 = new System.Windows.Forms.TextBox();
            this.lbl16 = new System.Windows.Forms.TextBox();
            this.lbl15 = new System.Windows.Forms.TextBox();
            this.lbl64 = new System.Windows.Forms.TextBox();
            this.lbl63 = new System.Windows.Forms.TextBox();
            this.lbl62 = new System.Windows.Forms.TextBox();
            this.lbl61 = new System.Windows.Forms.TextBox();
            this.lbl54 = new System.Windows.Forms.TextBox();
            this.lbl53 = new System.Windows.Forms.TextBox();
            this.lbl52 = new System.Windows.Forms.TextBox();
            this.lbl51 = new System.Windows.Forms.TextBox();
            this.lbl44 = new System.Windows.Forms.TextBox();
            this.lbl43 = new System.Windows.Forms.TextBox();
            this.lbl42 = new System.Windows.Forms.TextBox();
            this.lbl41 = new System.Windows.Forms.TextBox();
            this.lbl34 = new System.Windows.Forms.TextBox();
            this.lbl33 = new System.Windows.Forms.TextBox();
            this.lbl32 = new System.Windows.Forms.TextBox();
            this.lbl31 = new System.Windows.Forms.TextBox();
            this.lbl24 = new System.Windows.Forms.TextBox();
            this.lbl23 = new System.Windows.Forms.TextBox();
            this.lbl22 = new System.Windows.Forms.TextBox();
            this.lbl21 = new System.Windows.Forms.TextBox();
            this.lbl14 = new System.Windows.Forms.TextBox();
            this.lbl13 = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.TextBox();
            this.lbl11 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblClear = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblBack = new System.Windows.Forms.Label();
            this.Check = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl77
            // 
            this.lbl77.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl77.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl77.ForeColor = System.Drawing.Color.White;
            this.lbl77.Location = new System.Drawing.Point(561, 311);
            this.lbl77.Multiline = true;
            this.lbl77.Name = "lbl77";
            this.lbl77.Size = new System.Drawing.Size(44, 40);
            this.lbl77.TabIndex = 378;
            this.lbl77.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl76
            // 
            this.lbl76.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl76.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl76.ForeColor = System.Drawing.Color.White;
            this.lbl76.Location = new System.Drawing.Point(511, 311);
            this.lbl76.Multiline = true;
            this.lbl76.Name = "lbl76";
            this.lbl76.Size = new System.Drawing.Size(44, 40);
            this.lbl76.TabIndex = 377;
            this.lbl76.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl75
            // 
            this.lbl75.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl75.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl75.ForeColor = System.Drawing.Color.White;
            this.lbl75.Location = new System.Drawing.Point(461, 311);
            this.lbl75.Multiline = true;
            this.lbl75.Name = "lbl75";
            this.lbl75.Size = new System.Drawing.Size(44, 40);
            this.lbl75.TabIndex = 376;
            this.lbl75.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl74
            // 
            this.lbl74.BackColor = System.Drawing.Color.Crimson;
            this.lbl74.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl74.ForeColor = System.Drawing.Color.White;
            this.lbl74.Location = new System.Drawing.Point(411, 311);
            this.lbl74.Multiline = true;
            this.lbl74.Name = "lbl74";
            this.lbl74.Size = new System.Drawing.Size(44, 40);
            this.lbl74.TabIndex = 375;
            this.lbl74.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl73
            // 
            this.lbl73.BackColor = System.Drawing.Color.Crimson;
            this.lbl73.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl73.ForeColor = System.Drawing.Color.White;
            this.lbl73.Location = new System.Drawing.Point(361, 311);
            this.lbl73.Multiline = true;
            this.lbl73.Name = "lbl73";
            this.lbl73.Size = new System.Drawing.Size(44, 40);
            this.lbl73.TabIndex = 374;
            this.lbl73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl72
            // 
            this.lbl72.BackColor = System.Drawing.Color.Crimson;
            this.lbl72.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl72.ForeColor = System.Drawing.Color.White;
            this.lbl72.Location = new System.Drawing.Point(311, 311);
            this.lbl72.Multiline = true;
            this.lbl72.Name = "lbl72";
            this.lbl72.Size = new System.Drawing.Size(44, 40);
            this.lbl72.TabIndex = 373;
            this.lbl72.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl71
            // 
            this.lbl71.BackColor = System.Drawing.Color.Crimson;
            this.lbl71.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl71.ForeColor = System.Drawing.Color.White;
            this.lbl71.Location = new System.Drawing.Point(261, 311);
            this.lbl71.Multiline = true;
            this.lbl71.Name = "lbl71";
            this.lbl71.Size = new System.Drawing.Size(44, 40);
            this.lbl71.TabIndex = 372;
            this.lbl71.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl67
            // 
            this.lbl67.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl67.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl67.ForeColor = System.Drawing.Color.White;
            this.lbl67.Location = new System.Drawing.Point(561, 265);
            this.lbl67.Multiline = true;
            this.lbl67.Name = "lbl67";
            this.lbl67.Size = new System.Drawing.Size(44, 40);
            this.lbl67.TabIndex = 371;
            this.lbl67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl66
            // 
            this.lbl66.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl66.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl66.ForeColor = System.Drawing.Color.White;
            this.lbl66.Location = new System.Drawing.Point(511, 265);
            this.lbl66.Multiline = true;
            this.lbl66.Name = "lbl66";
            this.lbl66.Size = new System.Drawing.Size(44, 40);
            this.lbl66.TabIndex = 370;
            this.lbl66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl65
            // 
            this.lbl65.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl65.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl65.ForeColor = System.Drawing.Color.White;
            this.lbl65.Location = new System.Drawing.Point(461, 265);
            this.lbl65.Multiline = true;
            this.lbl65.Name = "lbl65";
            this.lbl65.Size = new System.Drawing.Size(44, 40);
            this.lbl65.TabIndex = 369;
            this.lbl65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl57
            // 
            this.lbl57.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl57.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl57.ForeColor = System.Drawing.Color.White;
            this.lbl57.Location = new System.Drawing.Point(561, 219);
            this.lbl57.Multiline = true;
            this.lbl57.Name = "lbl57";
            this.lbl57.Size = new System.Drawing.Size(44, 40);
            this.lbl57.TabIndex = 368;
            this.lbl57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl56
            // 
            this.lbl56.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl56.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl56.ForeColor = System.Drawing.Color.White;
            this.lbl56.Location = new System.Drawing.Point(511, 219);
            this.lbl56.Multiline = true;
            this.lbl56.Name = "lbl56";
            this.lbl56.Size = new System.Drawing.Size(44, 40);
            this.lbl56.TabIndex = 367;
            this.lbl56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl55
            // 
            this.lbl55.BackColor = System.Drawing.Color.GreenYellow;
            this.lbl55.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl55.ForeColor = System.Drawing.Color.White;
            this.lbl55.Location = new System.Drawing.Point(461, 219);
            this.lbl55.Multiline = true;
            this.lbl55.Name = "lbl55";
            this.lbl55.Size = new System.Drawing.Size(44, 40);
            this.lbl55.TabIndex = 366;
            this.lbl55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl47
            // 
            this.lbl47.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl47.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl47.ForeColor = System.Drawing.Color.White;
            this.lbl47.Location = new System.Drawing.Point(561, 173);
            this.lbl47.Multiline = true;
            this.lbl47.Name = "lbl47";
            this.lbl47.Size = new System.Drawing.Size(44, 40);
            this.lbl47.TabIndex = 365;
            this.lbl47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl46
            // 
            this.lbl46.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl46.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl46.ForeColor = System.Drawing.Color.White;
            this.lbl46.Location = new System.Drawing.Point(511, 173);
            this.lbl46.Multiline = true;
            this.lbl46.Name = "lbl46";
            this.lbl46.Size = new System.Drawing.Size(44, 40);
            this.lbl46.TabIndex = 364;
            this.lbl46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl45
            // 
            this.lbl45.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl45.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl45.ForeColor = System.Drawing.Color.White;
            this.lbl45.Location = new System.Drawing.Point(461, 173);
            this.lbl45.Multiline = true;
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(44, 40);
            this.lbl45.TabIndex = 363;
            this.lbl45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl37
            // 
            this.lbl37.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl37.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl37.ForeColor = System.Drawing.Color.White;
            this.lbl37.Location = new System.Drawing.Point(561, 127);
            this.lbl37.Multiline = true;
            this.lbl37.Name = "lbl37";
            this.lbl37.Size = new System.Drawing.Size(44, 40);
            this.lbl37.TabIndex = 362;
            this.lbl37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl36
            // 
            this.lbl36.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl36.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl36.ForeColor = System.Drawing.Color.White;
            this.lbl36.Location = new System.Drawing.Point(511, 127);
            this.lbl36.Multiline = true;
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(44, 40);
            this.lbl36.TabIndex = 361;
            this.lbl36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl35
            // 
            this.lbl35.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl35.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl35.ForeColor = System.Drawing.Color.White;
            this.lbl35.Location = new System.Drawing.Point(461, 127);
            this.lbl35.Multiline = true;
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(44, 40);
            this.lbl35.TabIndex = 360;
            this.lbl35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl27
            // 
            this.lbl27.BackColor = System.Drawing.Color.Goldenrod;
            this.lbl27.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27.ForeColor = System.Drawing.Color.White;
            this.lbl27.Location = new System.Drawing.Point(561, 81);
            this.lbl27.Multiline = true;
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(44, 40);
            this.lbl27.TabIndex = 359;
            this.lbl27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl26
            // 
            this.lbl26.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lbl26.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26.ForeColor = System.Drawing.Color.White;
            this.lbl26.Location = new System.Drawing.Point(511, 81);
            this.lbl26.Multiline = true;
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(44, 40);
            this.lbl26.TabIndex = 358;
            this.lbl26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl25
            // 
            this.lbl25.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lbl25.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.ForeColor = System.Drawing.Color.White;
            this.lbl25.Location = new System.Drawing.Point(461, 81);
            this.lbl25.Multiline = true;
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(44, 40);
            this.lbl25.TabIndex = 357;
            this.lbl25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl17
            // 
            this.lbl17.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lbl17.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17.ForeColor = System.Drawing.Color.White;
            this.lbl17.Location = new System.Drawing.Point(561, 35);
            this.lbl17.Multiline = true;
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(44, 40);
            this.lbl17.TabIndex = 356;
            this.lbl17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl16
            // 
            this.lbl16.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lbl16.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl16.ForeColor = System.Drawing.Color.White;
            this.lbl16.Location = new System.Drawing.Point(511, 35);
            this.lbl16.Multiline = true;
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(44, 40);
            this.lbl16.TabIndex = 355;
            this.lbl16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl15
            // 
            this.lbl15.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lbl15.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.ForeColor = System.Drawing.Color.White;
            this.lbl15.Location = new System.Drawing.Point(461, 35);
            this.lbl15.Multiline = true;
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(44, 40);
            this.lbl15.TabIndex = 354;
            this.lbl15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl64
            // 
            this.lbl64.BackColor = System.Drawing.Color.Crimson;
            this.lbl64.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl64.ForeColor = System.Drawing.Color.White;
            this.lbl64.Location = new System.Drawing.Point(411, 265);
            this.lbl64.Multiline = true;
            this.lbl64.Name = "lbl64";
            this.lbl64.Size = new System.Drawing.Size(44, 40);
            this.lbl64.TabIndex = 353;
            this.lbl64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl63
            // 
            this.lbl63.BackColor = System.Drawing.Color.Crimson;
            this.lbl63.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl63.ForeColor = System.Drawing.Color.White;
            this.lbl63.Location = new System.Drawing.Point(361, 265);
            this.lbl63.Multiline = true;
            this.lbl63.Name = "lbl63";
            this.lbl63.Size = new System.Drawing.Size(44, 40);
            this.lbl63.TabIndex = 352;
            this.lbl63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl62
            // 
            this.lbl62.BackColor = System.Drawing.Color.Crimson;
            this.lbl62.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl62.ForeColor = System.Drawing.Color.White;
            this.lbl62.Location = new System.Drawing.Point(311, 265);
            this.lbl62.Multiline = true;
            this.lbl62.Name = "lbl62";
            this.lbl62.Size = new System.Drawing.Size(44, 40);
            this.lbl62.TabIndex = 351;
            this.lbl62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl61
            // 
            this.lbl61.BackColor = System.Drawing.Color.DarkViolet;
            this.lbl61.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl61.ForeColor = System.Drawing.Color.White;
            this.lbl61.Location = new System.Drawing.Point(261, 265);
            this.lbl61.Multiline = true;
            this.lbl61.Name = "lbl61";
            this.lbl61.Size = new System.Drawing.Size(44, 40);
            this.lbl61.TabIndex = 350;
            this.lbl61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl54
            // 
            this.lbl54.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl54.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl54.ForeColor = System.Drawing.Color.White;
            this.lbl54.Location = new System.Drawing.Point(411, 219);
            this.lbl54.Multiline = true;
            this.lbl54.Name = "lbl54";
            this.lbl54.Size = new System.Drawing.Size(44, 40);
            this.lbl54.TabIndex = 349;
            this.lbl54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl53
            // 
            this.lbl53.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl53.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl53.ForeColor = System.Drawing.Color.White;
            this.lbl53.Location = new System.Drawing.Point(361, 219);
            this.lbl53.Multiline = true;
            this.lbl53.Name = "lbl53";
            this.lbl53.Size = new System.Drawing.Size(44, 40);
            this.lbl53.TabIndex = 348;
            this.lbl53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl52
            // 
            this.lbl52.BackColor = System.Drawing.Color.DarkViolet;
            this.lbl52.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl52.ForeColor = System.Drawing.Color.White;
            this.lbl52.Location = new System.Drawing.Point(311, 219);
            this.lbl52.Multiline = true;
            this.lbl52.Name = "lbl52";
            this.lbl52.Size = new System.Drawing.Size(44, 40);
            this.lbl52.TabIndex = 347;
            this.lbl52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl51
            // 
            this.lbl51.BackColor = System.Drawing.Color.DarkViolet;
            this.lbl51.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl51.ForeColor = System.Drawing.Color.White;
            this.lbl51.Location = new System.Drawing.Point(261, 219);
            this.lbl51.Multiline = true;
            this.lbl51.Name = "lbl51";
            this.lbl51.Size = new System.Drawing.Size(44, 40);
            this.lbl51.TabIndex = 346;
            this.lbl51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl44
            // 
            this.lbl44.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl44.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl44.ForeColor = System.Drawing.Color.White;
            this.lbl44.Location = new System.Drawing.Point(411, 173);
            this.lbl44.Multiline = true;
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(44, 40);
            this.lbl44.TabIndex = 345;
            this.lbl44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl43
            // 
            this.lbl43.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl43.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl43.ForeColor = System.Drawing.Color.White;
            this.lbl43.Location = new System.Drawing.Point(361, 173);
            this.lbl43.Multiline = true;
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(44, 40);
            this.lbl43.TabIndex = 344;
            this.lbl43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl42
            // 
            this.lbl42.BackColor = System.Drawing.Color.DarkViolet;
            this.lbl42.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl42.ForeColor = System.Drawing.Color.White;
            this.lbl42.Location = new System.Drawing.Point(311, 173);
            this.lbl42.Multiline = true;
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(44, 40);
            this.lbl42.TabIndex = 343;
            this.lbl42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl41
            // 
            this.lbl41.BackColor = System.Drawing.Color.DarkViolet;
            this.lbl41.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl41.ForeColor = System.Drawing.Color.White;
            this.lbl41.Location = new System.Drawing.Point(261, 173);
            this.lbl41.Multiline = true;
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(44, 40);
            this.lbl41.TabIndex = 342;
            this.lbl41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl34
            // 
            this.lbl34.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbl34.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl34.ForeColor = System.Drawing.Color.White;
            this.lbl34.Location = new System.Drawing.Point(411, 127);
            this.lbl34.Multiline = true;
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(44, 40);
            this.lbl34.TabIndex = 341;
            this.lbl34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl33
            // 
            this.lbl33.BackColor = System.Drawing.Color.DeepPink;
            this.lbl33.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.ForeColor = System.Drawing.Color.White;
            this.lbl33.Location = new System.Drawing.Point(361, 127);
            this.lbl33.Multiline = true;
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(44, 40);
            this.lbl33.TabIndex = 340;
            this.lbl33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl32
            // 
            this.lbl32.BackColor = System.Drawing.Color.DarkViolet;
            this.lbl32.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.ForeColor = System.Drawing.Color.White;
            this.lbl32.Location = new System.Drawing.Point(311, 127);
            this.lbl32.Multiline = true;
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(44, 40);
            this.lbl32.TabIndex = 339;
            this.lbl32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl31
            // 
            this.lbl31.BackColor = System.Drawing.Color.DarkViolet;
            this.lbl31.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.ForeColor = System.Drawing.Color.White;
            this.lbl31.Location = new System.Drawing.Point(261, 127);
            this.lbl31.Multiline = true;
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(44, 40);
            this.lbl31.TabIndex = 338;
            this.lbl31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl24
            // 
            this.lbl24.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lbl24.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.ForeColor = System.Drawing.Color.White;
            this.lbl24.Location = new System.Drawing.Point(411, 81);
            this.lbl24.Multiline = true;
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(44, 40);
            this.lbl24.TabIndex = 337;
            this.lbl24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl23
            // 
            this.lbl23.BackColor = System.Drawing.Color.DeepPink;
            this.lbl23.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.ForeColor = System.Drawing.Color.White;
            this.lbl23.Location = new System.Drawing.Point(361, 81);
            this.lbl23.Multiline = true;
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(44, 40);
            this.lbl23.TabIndex = 336;
            this.lbl23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl22
            // 
            this.lbl22.BackColor = System.Drawing.Color.DeepPink;
            this.lbl22.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.ForeColor = System.Drawing.Color.White;
            this.lbl22.Location = new System.Drawing.Point(311, 81);
            this.lbl22.Multiline = true;
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(44, 40);
            this.lbl22.TabIndex = 335;
            this.lbl22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl21
            // 
            this.lbl21.BackColor = System.Drawing.Color.DeepPink;
            this.lbl21.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.ForeColor = System.Drawing.Color.White;
            this.lbl21.Location = new System.Drawing.Point(261, 81);
            this.lbl21.Multiline = true;
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(44, 40);
            this.lbl21.TabIndex = 334;
            this.lbl21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl14
            // 
            this.lbl14.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lbl14.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl14.ForeColor = System.Drawing.Color.White;
            this.lbl14.Location = new System.Drawing.Point(411, 35);
            this.lbl14.Multiline = true;
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(44, 40);
            this.lbl14.TabIndex = 333;
            this.lbl14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl13
            // 
            this.lbl13.BackColor = System.Drawing.Color.DeepPink;
            this.lbl13.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.ForeColor = System.Drawing.Color.White;
            this.lbl13.Location = new System.Drawing.Point(361, 35);
            this.lbl13.Multiline = true;
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(44, 40);
            this.lbl13.TabIndex = 332;
            this.lbl13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.DeepPink;
            this.lbl12.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.ForeColor = System.Drawing.Color.White;
            this.lbl12.Location = new System.Drawing.Point(311, 35);
            this.lbl12.Multiline = true;
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(44, 40);
            this.lbl12.TabIndex = 331;
            this.lbl12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.DeepPink;
            this.lbl11.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.ForeColor = System.Drawing.Color.White;
            this.lbl11.Location = new System.Drawing.Point(261, 35);
            this.lbl11.Multiline = true;
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(44, 40);
            this.lbl11.TabIndex = 330;
            this.lbl11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 56.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(597, 358);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 93);
            this.label1.TabIndex = 867;
            this.label1.Text = "7x7";
            // 
            // lblClear
            // 
            this.lblClear.AutoSize = true;
            this.lblClear.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblClear.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClear.ForeColor = System.Drawing.Color.Crimson;
            this.lblClear.Location = new System.Drawing.Point(571, 479);
            this.lblClear.Name = "lblClear";
            this.lblClear.Size = new System.Drawing.Size(64, 23);
            this.lblClear.TabIndex = 895;
            this.lblClear.Text = "Clear";
            this.lblClear.Click += new System.EventHandler(this.btnClear_Click);
            this.lblClear.MouseLeave += new System.EventHandler(this.lblClear_MouseLeave);
            this.lblClear.MouseHover += new System.EventHandler(this.lblClear_MouseHover);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResult.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.ForeColor = System.Drawing.Color.Crimson;
            this.lblResult.Location = new System.Drawing.Point(397, 479);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(74, 23);
            this.lblResult.TabIndex = 894;
            this.lblResult.Text = "Result";
            this.lblResult.Click += new System.EventHandler(this.btnGo_Click);
            this.lblResult.MouseLeave += new System.EventHandler(this.lblResult_MouseLeave);
            this.lblResult.MouseHover += new System.EventHandler(this.lblResult_MouseHover);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(202, 491);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(487, 13);
            this.label5.TabIndex = 893;
            this.label5.Text = "________________________________________________________________________________";
            // 
            // lblBack
            // 
            this.lblBack.AutoSize = true;
            this.lblBack.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBack.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBack.ForeColor = System.Drawing.Color.Crimson;
            this.lblBack.Location = new System.Drawing.Point(36, 1);
            this.lblBack.Name = "lblBack";
            this.lblBack.Size = new System.Drawing.Size(120, 23);
            this.lblBack.TabIndex = 892;
            this.lblBack.Text = "Back Menu";
            this.lblBack.Click += new System.EventHandler(this.btnBack_Click);
            this.lblBack.MouseLeave += new System.EventHandler(this.lblBack_MouseLeave);
            this.lblBack.MouseHover += new System.EventHandler(this.lblBack_MouseHover);
            // 
            // Check
            // 
            this.Check.AutoSize = true;
            this.Check.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Check.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check.ForeColor = System.Drawing.Color.Crimson;
            this.Check.Location = new System.Drawing.Point(227, 479);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(70, 23);
            this.Check.TabIndex = 896;
            this.Check.Text = "Check";
            this.Check.Click += new System.EventHandler(this.Check_Click);
            // 
            // N7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::SudokuN.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(915, 548);
            this.Controls.Add(this.Check);
            this.Controls.Add(this.lblClear);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl77);
            this.Controls.Add(this.lbl76);
            this.Controls.Add(this.lbl75);
            this.Controls.Add(this.lbl74);
            this.Controls.Add(this.lbl73);
            this.Controls.Add(this.lbl72);
            this.Controls.Add(this.lbl71);
            this.Controls.Add(this.lbl67);
            this.Controls.Add(this.lbl66);
            this.Controls.Add(this.lbl65);
            this.Controls.Add(this.lbl57);
            this.Controls.Add(this.lbl56);
            this.Controls.Add(this.lbl55);
            this.Controls.Add(this.lbl47);
            this.Controls.Add(this.lbl46);
            this.Controls.Add(this.lbl45);
            this.Controls.Add(this.lbl37);
            this.Controls.Add(this.lbl36);
            this.Controls.Add(this.lbl35);
            this.Controls.Add(this.lbl27);
            this.Controls.Add(this.lbl26);
            this.Controls.Add(this.lbl25);
            this.Controls.Add(this.lbl17);
            this.Controls.Add(this.lbl16);
            this.Controls.Add(this.lbl15);
            this.Controls.Add(this.lbl64);
            this.Controls.Add(this.lbl63);
            this.Controls.Add(this.lbl62);
            this.Controls.Add(this.lbl61);
            this.Controls.Add(this.lbl54);
            this.Controls.Add(this.lbl53);
            this.Controls.Add(this.lbl52);
            this.Controls.Add(this.lbl51);
            this.Controls.Add(this.lbl44);
            this.Controls.Add(this.lbl43);
            this.Controls.Add(this.lbl42);
            this.Controls.Add(this.lbl41);
            this.Controls.Add(this.lbl34);
            this.Controls.Add(this.lbl33);
            this.Controls.Add(this.lbl32);
            this.Controls.Add(this.lbl31);
            this.Controls.Add(this.lbl24);
            this.Controls.Add(this.lbl23);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl14);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximumSize = new System.Drawing.Size(931, 587);
            this.MinimumSize = new System.Drawing.Size(931, 587);
            this.Name = "N7";
            this.Text = "N7";
            this.Load += new System.EventHandler(this.N7_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox lbl77;
        private System.Windows.Forms.TextBox lbl76;
        private System.Windows.Forms.TextBox lbl75;
        private System.Windows.Forms.TextBox lbl74;
        private System.Windows.Forms.TextBox lbl73;
        private System.Windows.Forms.TextBox lbl72;
        private System.Windows.Forms.TextBox lbl71;
        private System.Windows.Forms.TextBox lbl67;
        private System.Windows.Forms.TextBox lbl66;
        private System.Windows.Forms.TextBox lbl65;
        private System.Windows.Forms.TextBox lbl57;
        private System.Windows.Forms.TextBox lbl56;
        private System.Windows.Forms.TextBox lbl55;
        private System.Windows.Forms.TextBox lbl47;
        private System.Windows.Forms.TextBox lbl46;
        private System.Windows.Forms.TextBox lbl45;
        private System.Windows.Forms.TextBox lbl37;
        private System.Windows.Forms.TextBox lbl36;
        private System.Windows.Forms.TextBox lbl35;
        private System.Windows.Forms.TextBox lbl27;
        private System.Windows.Forms.TextBox lbl26;
        private System.Windows.Forms.TextBox lbl25;
        private System.Windows.Forms.TextBox lbl17;
        private System.Windows.Forms.TextBox lbl16;
        private System.Windows.Forms.TextBox lbl15;
        private System.Windows.Forms.TextBox lbl64;
        private System.Windows.Forms.TextBox lbl63;
        private System.Windows.Forms.TextBox lbl62;
        private System.Windows.Forms.TextBox lbl61;
        private System.Windows.Forms.TextBox lbl54;
        private System.Windows.Forms.TextBox lbl53;
        private System.Windows.Forms.TextBox lbl52;
        private System.Windows.Forms.TextBox lbl51;
        private System.Windows.Forms.TextBox lbl44;
        private System.Windows.Forms.TextBox lbl43;
        private System.Windows.Forms.TextBox lbl42;
        private System.Windows.Forms.TextBox lbl41;
        private System.Windows.Forms.TextBox lbl34;
        private System.Windows.Forms.TextBox lbl33;
        private System.Windows.Forms.TextBox lbl32;
        private System.Windows.Forms.TextBox lbl31;
        private System.Windows.Forms.TextBox lbl24;
        private System.Windows.Forms.TextBox lbl23;
        private System.Windows.Forms.TextBox lbl22;
        private System.Windows.Forms.TextBox lbl21;
        private System.Windows.Forms.TextBox lbl14;
        private System.Windows.Forms.TextBox lbl13;
        private System.Windows.Forms.TextBox lbl12;
        private System.Windows.Forms.TextBox lbl11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblClear;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblBack;
        private System.Windows.Forms.Label Check;
    }
}